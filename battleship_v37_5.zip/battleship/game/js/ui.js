/* ════════════════════════════════════════════════════════
   ui.js — сервис: экраны, уведомления, переходы
   Этап 1: showScreen(), showToast()
   ════════════════════════════════════════════════════════ */

window.UI = (() => {

  const SCREEN_IDS = ['screen-lobby', 'screen-placing', 'screen-game', 'screen-over'];

  /**
   * Показать экран по id, скрыть остальные.
   * @param {string} id - один из SCREEN_IDS
   */
  function showScreen(id) {
    if (!SCREEN_IDS.includes(id)) {
      console.error('UI.showScreen: неизвестный экран "' + id + '"');
      return;
    }
    SCREEN_IDS.forEach(sid => {
      const el = document.getElementById(sid);
      if (!el) return;
      el.classList.toggle('d-none', sid !== id);
    });
  }

  /**
   * Показать всплывающее уведомление.
   * @param {string} text
   * @param {number} duration - мс, по умолчанию 2200
   */
  function showToast(text, duration = 2200) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toastEl = document.createElement('div');
    toastEl.className = 'toast align-items-center border-0 show';
    toastEl.setAttribute('role', 'alert');

    // Текст тоста вставляется через textContent, а не innerHTML: text
    // может содержать имя игрока (пришедшее с сервера от соперника),
    // а имя — это ввод пользователя, которому нельзя доверять как HTML.
    const flex = document.createElement('div');
    flex.className = 'd-flex';

    const body = document.createElement('div');
    body.className = 'toast-body';
    body.style.cssText = 'font-size:13px;font-weight:500;color:#334455';
    body.textContent = text;

    const closeBtn = document.createElement('button');
    closeBtn.type = 'button';
    closeBtn.className = 'btn-close me-2 m-auto';
    closeBtn.setAttribute('aria-label', 'Закрыть');
    closeBtn.addEventListener('click', () => toastEl.remove());

    flex.append(body, closeBtn);
    toastEl.append(flex);
    container.appendChild(toastEl);

    setTimeout(() => toastEl.remove(), duration);
  }

  return { showScreen, showToast };

})();
