<?php
/**
 * place_ships.php — приём расстановки кораблей от игрока.
 *
 * POST { "gameId": "abc123", "playerId": "p1", "ships": [ {id, name, size, coords, dir}, ... ] }
 * Ответ: { "ok": true, "status": "placing" | "playing" }
 *   status: "playing" — оба игрока готовы, игра началась (turn выставлен)
 *
 * Формат ships — тот же, что в Game.state.players[i].ships (см. game.js):
 * каждый корабль { id, name, size, coords: [[x,y],...], dir: 'H'|'V' }.
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond_error('invalid_request', 400);
}

$gameId   = trim((string)($input['gameId'] ?? ''));
$playerId = trim((string)($input['playerId'] ?? ''));
$ships    = $input['ships'] ?? null;

if ($gameId === '' || $playerId === '' || !is_array($ships)) {
    respond_error('invalid_request', 400);
}

// Базовая проверка структуры — не доверяем клиенту полностью.
// ВАЖНО: раньше здесь была только защита от структурно некорректных
// данных, а проверка непересечения кораблей оставалась на клиенте.
// Клиенту в принципе нельзя доверять (запрос к этому эндпоинту можно
// отправить и в обход board.js), поэтому ниже добавлены:
//   - проверка, что клетки каждого корабля образуют непрерывную прямую
//     линию (без неё можно было прислать "корабль" из несмежных клеток);
//   - проверка непересечения и недопустимости касания кораблей даже по
//     диагонали (тот же алгоритм, что уже есть в board.js на клиенте).
// Обе проверки — только структурные ("это вообще валидная расстановка
// по правилам игры?"), они ничего не знают о ходах/боевой логике и не
// меняют формат ответа/ошибок для уже существующих валидных запросов.
$totalCells = 0;
foreach ($ships as $ship) {
    if (!isset($ship['id'], $ship['size'], $ship['coords']) || !is_array($ship['coords'])) {
        respond_error('invalid_ships_format', 400);
    }
    if (count($ship['coords']) !== (int)$ship['size']) {
        respond_error('invalid_ships_format', 400);
    }
    foreach ($ship['coords'] as $coord) {
        if (!is_array($coord) || count($coord) !== 2) {
            respond_error('invalid_ships_format', 400);
        }
        [$x, $y] = $coord;
        if (!is_int($x) || !is_int($y) || $x < 0 || $x > 9 || $y < 0 || $y > 9) {
            respond_error('invalid_ships_format', 400);
        }
    }
    $totalCells += (int)$ship['size'];

    // Клетки корабля должны идти подряд по одной прямой (горизонтали
    // или вертикали) — как их строит board.js. Однопалубный корабль
    // (size=1) проверять не на чем, пропускаем.
    if ((int)$ship['size'] > 1) {
        $coords = $ship['coords'];
        $sameRow = true;
        $sameCol = true;
        for ($i = 1; $i < count($coords); $i++) {
            if ($coords[$i][1] !== $coords[0][1]) $sameRow = false;
            if ($coords[$i][0] !== $coords[0][0]) $sameCol = false;
        }
        if (!$sameRow && !$sameCol) {
            respond_error('invalid_ships_format', 400);
        }
        // Непрерывность: отсортированные координаты вдоль оси должны
        // идти подряд, без пропусков и повторов.
        $axisValues = array_map(fn($c) => $sameRow ? $c[0] : $c[1], $coords);
        sort($axisValues);
        for ($i = 1; $i < count($axisValues); $i++) {
            if ($axisValues[$i] !== $axisValues[$i - 1] + 1) {
                respond_error('invalid_ships_format', 400);
            }
        }
    }
}
if (count($ships) !== 10 || $totalCells !== 20) {
    respond_error('invalid_ships_count', 400);
}

// Непересечение и запрет касания кораблей (в т.ч. по диагонали) —
// стандартное правило морского боя. $occupied накапливается ПОСЛЕ
// проверки каждого корабля (не до), иначе корабль "пересекался" бы
// сам с собой на первой же итерации.
$occupied = []; // 'x,y' -> true: клетки уже проверенных кораблей + буфер в 1 клетку вокруг них
foreach ($ships as $ship) {
    foreach ($ship['coords'] as $coord) {
        $key = $coord[0] . ',' . $coord[1];
        if (isset($occupied[$key])) {
            respond_error('ships_overlap', 400);
        }
    }
    foreach ($ship['coords'] as $coord) {
        [$sx, $sy] = $coord;
        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dy = -1; $dy <= 1; $dy++) {
                $occupied[($sx + $dx) . ',' . ($sy + $dy)] = true;
            }
        }
    }
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id, game_id, ready FROM players WHERE id = ? AND game_id = ? FOR UPDATE');
    $stmt->execute([$playerId, $gameId]);
    $player = $stmt->fetch();

    if (!$player) {
        $pdo->rollBack();
        respond_error('player_not_found', 404);
    }

    $stmt = $pdo->prepare('SELECT status FROM games WHERE id = ? FOR UPDATE');
    $stmt->execute([$gameId]);
    $game = $stmt->fetch();

    if (!$game || !in_array($game['status'], ['placing', 'waiting'], true)) {
        $pdo->rollBack();
        respond_error('game_not_in_placing_phase', 409);
    }

    $pdo->prepare('UPDATE players SET ships = ?, ready = 1, last_seen = NOW() WHERE id = ?')
        ->execute([json_encode($ships), $playerId]);

    // Проверить, готовы ли теперь оба игрока этой партии.
    $stmt = $pdo->prepare('SELECT id, ready FROM players WHERE game_id = ?');
    $stmt->execute([$gameId]);
    $players = $stmt->fetchAll();

    $bothReady = count($players) === 2 && array_reduce(
        $players,
        fn($carry, $p) => $carry && (int)$p['ready'] === 1,
        true
    );

    $status = 'placing';
    if ($bothReady) {
        $status = 'playing';
        // Первый ход — случайно выбранный из двух игроков.
        $firstTurn = $players[array_rand($players)]['id'];
        $pdo->prepare('UPDATE games SET status = ?, turn = ? WHERE id = ?')
            ->execute(['playing', $firstTurn, $gameId]);

        // Известить обоих, что игра началась и чей первый ход.
        foreach ($players as $p) {
            $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
                ->execute([$gameId, $p['id'], 'game_started', json_encode(['turn' => $firstTurn])]);
        }
    } else {
        // Известить соперника, что этот игрок готов (если соперник уже подключился).
        foreach ($players as $p) {
            if ($p['id'] !== $playerId) {
                $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
                    ->execute([$gameId, $p['id'], 'opponent_ready', null]);
            }
        }
    }

    $pdo->commit();
    $response = ['ok' => true, 'status' => $status];
    if ($status === 'playing') {
        $response['turn'] = $firstTurn;
    }
    echo json_encode($response);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('place_ships.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
