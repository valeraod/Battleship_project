<?php
/**
 * rematch.php — начать повторную партию с тем же соперником в РАМКАХ
 * ТОЙ ЖЕ игры (тот же gameId), без создания новой ссылки.
 *
 * Раньше "Играть снова" в онлайне была заглушкой (см. HANDOFF.md/чат
 * с игроком) — только тост "не реализовано" и возврат в лобби. Кнопка
 * "В лобби" при этом не чистила Game.state на клиенте, из-за чего
 * старые ships/shotsFired/shotsReceived утекали в следующую партию
 * (см. фикс в lobby.js onCreateGameClick/onJoinByLinkClick).
 *
 * POST { "gameId": "abc123", "playerId": "p1" }
 * Ответ: { "ok": true }
 *
 * Требования: game.status === 'finished', оба игрока всё ещё привязаны
 * к этой записи games (players не удаляются, пока сама игра не станет
 * 'finished' И кто-то не создаст новую игру — см. join.php).
 *
 * Эффект: ships/ready обоих игроков сбрасываются, ходы (moves) партии
 * очищаются, games.status -> 'placing', games.turn -> NULL. Игрок,
 * НЕ вызвавший этот эндпоинт, получает событие 'rematch_started' —
 * его клиент слушает это событие, пока сидит на экране результата
 * (см. lobby.js, startRematchWatchPoll), и сам переходит к расстановке.
 * Вызвавший эндпоинт переходит к расстановке сразу, без ожидания
 * своего же события.
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond_error('invalid_request', 400);
}

$gameId   = trim((string)($input['gameId'] ?? ''));
$playerId = trim((string)($input['playerId'] ?? ''));

if ($gameId === '' || $playerId === '') {
    respond_error('invalid_request', 400);
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id, status FROM games WHERE id = ? FOR UPDATE');
    $stmt->execute([$gameId]);
    $game = $stmt->fetch();

    if (!$game) {
        $pdo->rollBack();
        respond_error('game_not_found', 404);
    }
    if ($game['status'] !== 'finished') {
        // Партия ещё не завершена (например, второй запрос-дубликат от
        // того же клика) либо уже переведена в 'placing' предыдущим
        // вызовом rematch — в обоих случаях второй запрос ничего не
        // должен ломать, просто сообщаем, что сейчас не время.
        $pdo->rollBack();
        respond_error('game_not_finished', 409);
    }

    $stmt = $pdo->prepare('SELECT id FROM players WHERE id = ? AND game_id = ?');
    $stmt->execute([$playerId, $gameId]);
    if (!$stmt->fetch()) {
        $pdo->rollBack();
        respond_error('player_not_found', 404);
    }

    $stmt = $pdo->prepare('SELECT id FROM players WHERE game_id = ?');
    $stmt->execute([$gameId]);
    $playerIds = $stmt->fetchAll(PDO::FETCH_COLUMN);

    if (count($playerIds) !== 2) {
        // Теоретически недостижимо (players этой игры не удаляются, пока
        // игру не подчистит join.php при создании НОВОЙ игры кем-либо) —
        // проверка на всякий случай, чтобы не создать битую партию на двоих.
        $pdo->rollBack();
        respond_error('opponent_gone', 409);
    }

    $pdo->prepare('UPDATE players SET ships = NULL, ready = 0 WHERE game_id = ?')
        ->execute([$gameId]);
    $pdo->prepare('DELETE FROM moves WHERE game_id = ?')->execute([$gameId]);
    $pdo->prepare("UPDATE games SET status = 'placing', turn = NULL WHERE id = ?")
        ->execute([$gameId]);

    foreach ($playerIds as $pid) {
        if ($pid !== $playerId) {
            $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
                ->execute([$gameId, $pid, 'rematch_started', null]);
        }
    }

    $pdo->commit();
    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('rematch.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
