/* ════════════════════════════════════════════════════════
   online.js — сервис: транспортный слой для онлайн-режима
   Этап 7.1: чистая обёртка над fetch() для api/*.php.
   Никакой игровой логики здесь — только отправка запроса и
   разбор ответа. Решения "что делать с ответом" принимают
   lobby.js/board.js/game.js (Этапы 7.2+).

   Все функции возвращают Promise, который:
   - резолвится с разобранным JSON при HTTP 2xx
   - реджектится с Error, где .code — строка ошибки сервера
     (например 'not_your_turn', 'game_full') если она известна,
     иначе 'network_error' (сеть недоступна) или 'server_error'
     (ответ не JSON / непредвиденный статус без понятного code).
   ════════════════════════════════════════════════════════ */

window.Online = (() => {

  const API_BASE = '../api/';

  // Сколько ждать ответа сервера, прежде чем считать запрос зависшим.
  // П.2 из review_v25.md: без этого таймаута fetch мог висеть вечно при
  // обрыве TCP-соединения (сервер принял запрос, но не ответил) — кнопка
  // "Подключаемся..." блокировалась навсегда, catch не срабатывал.
  const REQUEST_TIMEOUT_MS = 10000;

  /**
   * Низкоуровневый помощник: выполнить запрос к api/<endpoint>,
   * разобрать JSON-ответ, единообразно обработать ошибки.
   * @param {string} endpoint - имя файла, например 'join.php'
   * @param {object} options - параметры fetch (method, body и т.п.)
   * @returns {Promise<object>}
   */
  async function call(endpoint, options) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    let response;
    try {
      response = await fetch(API_BASE + endpoint, { ...options, signal: controller.signal });
    } catch (networkError) {
      // AbortError (наш собственный таймаут) и обычная сетевая ошибка
      // (DNS не резолвится, offline и т.п.) обрабатываются одинаково —
      // с точки зрения вызывающего кода это всё "сеть недоступна",
      // отдельный code для таймаута не нужен: lobby.js уже показывает
      // понятный текст через describeError() для network_error.
      const err = new Error(
        networkError.name === 'AbortError'
          ? `Сервер не ответил за ${REQUEST_TIMEOUT_MS / 1000} секунд`
          : 'Сеть недоступна: ' + networkError.message
      );
      err.code = 'network_error';
      throw err;
    } finally {
      clearTimeout(timer);
    }

    let data;
    try {
      data = await response.json();
    } catch (parseError) {
      const err = new Error('Сервер вернул не-JSON ответ');
      err.code = 'server_error';
      throw err;
    }

    if (!response.ok) {
      const err = new Error('Ошибка сервера: ' + (data.error || response.status));
      err.code = data.error || 'server_error';
      throw err;
    }

    return data;
  }

  function postJSON(endpoint, body) {
    return call(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
  }

  /**
   * Создать новую игру или подключиться к существующей по gameId.
   * @param {string} name - имя игрока
   * @param {string|null} gameId - код игры; null/опущено -> создать новую
   * @returns {Promise<{gameId, playerId, status}>}
   */
  function join(name, gameId = null) {
    const body = { name };
    if (gameId) body.gameId = gameId;
    return postJSON('join.php', body);
  }

  /**
   * Отправить расстановку кораблей.
   * @param {string} gameId
   * @param {string} playerId
   * @param {Array} ships - формат как Game.state.players[i].ships
   * @returns {Promise<{ok, status}>} status: 'placing' | 'playing'
   */
  function placeShips(gameId, playerId, ships) {
    return postJSON('place_ships.php', { gameId, playerId, ships });
  }

  /**
   * Сделать выстрел по клетке (x, y).
   * @param {string} gameId
   * @param {string} playerId
   * @param {number} x
   * @param {number} y
   * @returns {Promise<object>} см. шапку api/attack.php для формы ответа
   */
  function attack(gameId, playerId, x, y) {
    return postJSON('attack.php', { gameId, playerId, x, y });
  }

  /**
   * Запросить новые события начиная с lastEventId.
   * @param {string} gameId
   * @param {string} playerId
   * @param {number} lastEventId - id последнего уже обработанного события (0 — все)
   * @returns {Promise<{events: Array}>}
   */
  function poll(gameId, playerId, lastEventId = 0) {
    const params = new URLSearchParams({ gameId, playerId, lastEventId });
    return call('poll.php?' + params.toString(), { method: 'GET' });
  }

  /**
   * Принудительно завершить все незавершённые игры на сервере.
   * Вызывается когда пользователь подтверждает создание новой игры
   * при наличии незавершённой партии (server_busy).
   * @returns {Promise<{ok, abandoned}>}
   */
  function abandon() {
    return postJSON('abandon.php', {});
  }

  /**
   * Начать реванш с тем же соперником в той же игре (gameId не меняется).
   * @param {string} gameId
   * @param {string} playerId
   * @returns {Promise<{ok}>}
   */
  function rematch(gameId, playerId) {
    return postJSON('rematch.php', { gameId, playerId });
  }

  return { join, placeShips, attack, poll, abandon, rematch };

})();
