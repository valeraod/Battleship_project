<?php
/**
 * join.php — регистрация игрока, поиск/создание матча.
 *
 * POST { "name": "alice" }                      -> создать новую игру
 * POST { "name": "bob", "gameId": "abc123" }    -> подключиться к существующей
 *
 * Ответ при создании новой игры:
 *   { "gameId": "abc123", "playerId": "p1", "status": "waiting" }
 * Ответ при подключении вторым игроком:
 *   { "gameId": "abc123", "playerId": "p2", "status": "placing" }
 *
 * Ошибки: { "error": "..." } с соответствующим HTTP-кодом.
 *
 * Этап 8.9: ограничение числа одновременных незавершённых игр —
 * защита от случайного/злонамеренного накопления партий до того, как
 * сработает крон-задача (Этап 8.7, убирает только то, что старше суток).
 * Поменяй это число в одну строку, если лимит окажется тесным.
 */

const MAX_ACTIVE_GAMES = 1;

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond_error('invalid_request', 400);
}

$name = trim((string)($input['name'] ?? ''));
if ($name === '' || mb_strlen($name) > 50) {
    respond_error('invalid_name', 400);
}

$gameId = isset($input['gameId']) ? trim((string)$input['gameId']) : null;

try {
    if ($gameId === null || $gameId === '') {
        // ── Создать новую игру, стать первым игроком ──

        // Этап 8.9: не создавать новую игру, если лимит одновременных
        // незавершённых партий уже достигнут.
        $stmt = $pdo->prepare("SELECT COUNT(*) AS cnt FROM games WHERE status != 'finished'");
        $stmt->execute();
        if ((int)$stmt->fetch()['cnt'] >= MAX_ACTIVE_GAMES) {
            respond_error('server_busy', 503);
        }

        $gameId = bin2hex(random_bytes(6));
        $playerId = bin2hex(random_bytes(6));

        $pdo->beginTransaction();
        $pdo->prepare('INSERT INTO games (id, status, turn) VALUES (?, ?, ?)')
            ->execute([$gameId, 'waiting', null]);
        $pdo->prepare('INSERT INTO players (id, game_id, name) VALUES (?, ?, ?)')
            ->execute([$playerId, $gameId, $name]);
        $pdo->commit();

        echo json_encode(['gameId' => $gameId, 'playerId' => $playerId, 'status' => 'waiting']);
        exit;
    }

    // ── Подключиться как второй игрок к существующей игре ──
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT * FROM games WHERE id = ? FOR UPDATE');
    $stmt->execute([$gameId]);
    $game = $stmt->fetch();

    if (!$game) {
        $pdo->rollBack();
        respond_error('game_not_found', 404);
    }
    if ($game['status'] !== 'waiting') {
        $pdo->rollBack();
        respond_error('game_not_joinable', 409);
    }

    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM players WHERE game_id = ?');
    $stmt->execute([$gameId]);
    if ((int)$stmt->fetch()['cnt'] >= 2) {
        $pdo->rollBack();
        respond_error('game_full', 409);
    }

    $playerId = bin2hex(random_bytes(6));
    $pdo->prepare('INSERT INTO players (id, game_id, name) VALUES (?, ?, ?)')
        ->execute([$playerId, $gameId, $name]);
    $pdo->prepare('UPDATE games SET status = ? WHERE id = ?')
        ->execute(['placing', $gameId]);

    // Известить первого игрока, что соперник подключился — он узнает
    // об этом через poll.php вместо постоянного опроса games.status.
    $stmt = $pdo->prepare('SELECT id FROM players WHERE game_id = ? AND id != ?');
    $stmt->execute([$gameId, $playerId]);
    $otherPlayerId = $stmt->fetchColumn();
    if ($otherPlayerId) {
        $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
            ->execute([$gameId, $otherPlayerId, 'opponent_joined', json_encode(['name' => $name])]);
    }

    // Получить имя первого игрока, чтобы второй знал имя соперника
    $stmt = $pdo->prepare('SELECT name FROM players WHERE game_id = ? AND id != ?');
    $stmt->execute([$gameId, $playerId]);
    $opponentName = $stmt->fetchColumn() ?: 'Игрок 1';

    $pdo->commit();

    echo json_encode(['gameId' => $gameId, 'playerId' => $playerId, 'status' => 'placing', 'opponentName' => $opponentName]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('join.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
