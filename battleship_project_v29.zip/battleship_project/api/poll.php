<?php
/**
 * poll.php — отдаёт игроку новые события, накопленные с момента lastEventId.
 * Клиент опрашивает этот эндпоинт по таймеру (poll.js, Этап 7):
 * 3000 мс в фазах LOBBY/PLACING, 1500 мс в фазе PLAYING.
 *
 * GET api/poll.php?gameId=abc123&playerId=p1&lastEventId=0
 * Ответ: { "events": [ { "id": 5, "type": "enemy_attack", "x": 7, "y": 1, "hit": false }, ... ] }
 *
 * Каждое событие в ответе разворачивает payload прямо в объект события
 * (а не как вложенное поле) — события в одном плоском формате для клиента.
 *
 * Побочный эффект: обновляет players.last_seen для playerId — используется
 * для определения отключившегося игрока (см. заметки в battleship_spec.md).
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$gameId       = trim((string)($_GET['gameId'] ?? ''));
$playerId     = trim((string)($_GET['playerId'] ?? ''));
$lastEventId  = (int)($_GET['lastEventId'] ?? 0);

if ($gameId === '' || $playerId === '') {
    respond_error('invalid_request', 400);
}

try {
    $stmt = $pdo->prepare('SELECT id FROM players WHERE id = ? AND game_id = ?');
    $stmt->execute([$playerId, $gameId]);
    if (!$stmt->fetch()) {
        respond_error('player_not_found', 404);
    }

    $pdo->prepare('UPDATE players SET last_seen = NOW() WHERE id = ?')
        ->execute([$playerId]);

    $stmt = $pdo->prepare(
        'SELECT id, type, payload FROM events
         WHERE game_id = ? AND for_player = ? AND id > ?
         ORDER BY id ASC'
    );
    $stmt->execute([$gameId, $playerId, $lastEventId]);
    $rows = $stmt->fetchAll();

    $events = array_map(function ($row) {
        $event = [
            'id'   => (int)$row['id'],
            'type' => $row['type'],
        ];
        $payload = $row['payload'] ? json_decode($row['payload'], true) : [];
        if (is_array($payload)) {
            $event = array_merge($event, $payload);
        }
        return $event;
    }, $rows);

    echo json_encode(['events' => $events]);
} catch (Throwable $e) {
    error_log('poll.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
