-- ════════════════════════════════════════════════════════
-- Миграция 001 — начальная структура БД для Блока B (онлайн)
-- Источник структуры: docs/battleship_spec.md, раздел "База данных — Блок B"
-- Выполняется в phpMyAdmin (вкладка SQL) на базе `valer186_battleship`.
-- Статус: выполнена успешно (4 таблицы созданы без ошибок).
-- ════════════════════════════════════════════════════════

CREATE TABLE games (
  id         VARCHAR(12) PRIMARY KEY,
  status     ENUM('waiting','placing','playing','finished') NOT NULL,
  turn       VARCHAR(12),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE players (
  id         VARCHAR(12) PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  name       VARCHAR(50) NOT NULL,
  ships      JSON,
  ready      TINYINT(1) DEFAULT 0,
  last_seen  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id),
  INDEX idx_players_game (game_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE moves (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  player_id  VARCHAR(12) NOT NULL,
  x          TINYINT NOT NULL,
  y          TINYINT NOT NULL,
  hit        TINYINT(1) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id),
  INDEX idx_moves_game (game_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  for_player VARCHAR(12) NOT NULL,
  type       VARCHAR(30) NOT NULL,
  payload    JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id),
  INDEX idx_events_game_player (game_id, for_player)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
