<?php
/**
 * abandon.php — принудительно завершить все незавершённые игры.
 *
 * POST {} (тело не требуется)
 * Ответ: { "ok": true, "abandoned": 3 }  — число завершённых игр
 *
 * Используется клиентом когда сервер возвращает server_busy при
 * попытке создать новую игру — игрок подтверждает что хочет
 * завершить текущую незавершённую партию.
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

try {
    $stmt = $pdo->prepare("UPDATE games SET status = 'finished' WHERE status != 'finished'");
    $stmt->execute();
    $abandoned = $stmt->rowCount();

    echo json_encode(['ok' => true, 'abandoned' => $abandoned]);
} catch (Throwable $e) {
    error_log('abandon.php error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'server_error']);
}
