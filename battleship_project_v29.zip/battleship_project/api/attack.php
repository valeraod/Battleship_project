<?php
/**
 * attack.php — приём хода, проверка попадания, переключение очереди.
 * Логика повторяет Game.attack() из game.js (Этап 3): при попадании —
 * внеочередной ход (тот же игрок стреляет снова), очередь переходит
 * только при промахе.
 *
 * POST { "gameId": "abc123", "playerId": "p1", "x": 3, "y": 4 }
 *
 * Ответ (промах, очередь переходит):
 *   { "hit": false, "sunk": false, "nextTurn": "p2" }
 * Ответ (попадание, внеочередной ход):
 *   { "hit": true, "sunk": true, "shipCells": [[3,4],[3,5]], "nextTurn": "p1" }
 * Ответ (победа):
 *   { "hit": true, "sunk": true, "gameOver": true, "winner": "p1", "opponentShips": [...] }
 *
 * Валидация (см. docs/battleship_spec.md):
 * 1. playerId принадлежит матчу gameId
 * 2. games.turn === playerId — действительно его очередь
 * 3. Клетка (x, y) ещё не атаковалась этим игроком (нет в moves)
 * 4. Проверить попадание по players.ships противника
 * 5. Записать ход в moves
 * 6. Записать событие enemy_attack в events для противника
 * 7. Переключить games.turn (если промах)
 * 8. Если потоплены все корабли — game_over для обоих, статус finished
 * 9. Вернуть результат
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond_error('invalid_request', 400);
}

$gameId   = trim((string)($input['gameId'] ?? ''));
$playerId = trim((string)($input['playerId'] ?? ''));
$x = $input['x'] ?? null;
$y = $input['y'] ?? null;

if ($gameId === '' || $playerId === '' || !is_int($x) || !is_int($y) || $x < 0 || $x > 9 || $y < 0 || $y > 9) {
    respond_error('invalid_request', 400);
}

try {
    $pdo->beginTransaction();

    // 1. playerId принадлежит матчу gameId
    $stmt = $pdo->prepare('SELECT * FROM games WHERE id = ? FOR UPDATE');
    $stmt->execute([$gameId]);
    $game = $stmt->fetch();
    if (!$game) {
        $pdo->rollBack();
        respond_error('game_not_found', 404);
    }
    if ($game['status'] !== 'playing') {
        $pdo->rollBack();
        respond_error('game_not_playing', 409);
    }

    $stmt = $pdo->prepare('SELECT * FROM players WHERE game_id = ?');
    $stmt->execute([$gameId]);
    $players = $stmt->fetchAll();
    if (count($players) !== 2) {
        $pdo->rollBack();
        respond_error('game_not_ready', 409);
    }

    $attacker = null;
    $defender = null;
    foreach ($players as $p) {
        if ($p['id'] === $playerId) $attacker = $p;
        else $defender = $p;
    }
    if (!$attacker || !$defender) {
        $pdo->rollBack();
        respond_error('player_not_found', 404);
    }

    // 2. действительно его очередь
    if ($game['turn'] !== $playerId) {
        $pdo->rollBack();
        respond_error('not_your_turn', 409);
    }

    // 3. клетка ещё не атаковалась этим игроком
    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM moves WHERE game_id = ? AND player_id = ? AND x = ? AND y = ?');
    $stmt->execute([$gameId, $playerId, $x, $y]);
    if ((int)$stmt->fetch()['cnt'] > 0) {
        $pdo->rollBack();
        respond_error('cell_already_attacked', 409);
    }

    // 4. проверить попадание по players.ships противника
    $defenderShips = json_decode($defender['ships'], true) ?: [];
    $hitShip = null;
    foreach ($defenderShips as $ship) {
        foreach ($ship['coords'] as $coord) {
            if ($coord[0] === $x && $coord[1] === $y) {
                $hitShip = $ship;
                break 2;
            }
        }
    }
    $hit = $hitShip !== null;

    // Все предыдущие попадания этого атакующего по кораблям защитника —
    // нужно для определения, потоплен ли корабль целиком.
    $stmt = $pdo->prepare('SELECT x, y FROM moves WHERE game_id = ? AND player_id = ? AND hit = 1');
    $stmt->execute([$gameId, $playerId]);
    $priorHits = $stmt->fetchAll();
    $priorHitSet = [];
    foreach ($priorHits as $ph) {
        $priorHitSet[$ph['x'] . ',' . $ph['y']] = true;
    }

    $sunk = false;
    if ($hit) {
        $sunk = true;
        foreach ($hitShip['coords'] as $coord) {
            $key = $coord[0] . ',' . $coord[1];
            $isCurrentShot = ($coord[0] === $x && $coord[1] === $y);
            if (!$isCurrentShot && !isset($priorHitSet[$key])) {
                $sunk = false;
                break;
            }
        }
    }

    // 5. записать ход в moves
    $pdo->prepare('INSERT INTO moves (game_id, player_id, x, y, hit) VALUES (?, ?, ?, ?, ?)')
        ->execute([$gameId, $playerId, $x, $y, $hit ? 1 : 0]);

    // 6. записать событие enemy_attack в events для противника
    $attackEventPayload = ['x' => $x, 'y' => $y, 'hit' => $hit, 'sunk' => $sunk];
    if ($sunk) {
        $attackEventPayload['shipCells'] = $hitShip['coords'];
    }
    $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
        ->execute([$gameId, $defender['id'], 'enemy_attack', json_encode($attackEventPayload)]);

    // 8. проверить, потоплены ли все корабли защитника
    $allDefenderCells = 0;
    foreach ($defenderShips as $ship) {
        $allDefenderCells += count($ship['coords']);
    }
    $stmt = $pdo->prepare('SELECT COUNT(*) AS cnt FROM moves WHERE game_id = ? AND player_id = ? AND hit = 1');
    $stmt->execute([$gameId, $playerId]);
    $totalHitsByAttacker = (int)$stmt->fetch()['cnt'];

    $gameOver = $hit && $totalHitsByAttacker >= $allDefenderCells && $allDefenderCells > 0;

    $response = [
        'hit'  => $hit,
        'sunk' => $sunk,
    ];
    if ($sunk) {
        $response['shipCells'] = $hitShip['coords'];
    }

    if ($gameOver) {
        $pdo->prepare('UPDATE games SET status = ?, turn = NULL WHERE id = ?')
            ->execute(['finished', $gameId]);

        $attackerShips = json_decode($attacker['ships'], true) ?: [];

        $response['gameOver']      = true;
        $response['winner']        = $playerId;
        $response['opponentShips'] = $defenderShips;

        $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
            ->execute([$gameId, $playerId, 'game_over', json_encode(['winner' => $playerId, 'opponentShips' => $defenderShips])]);
        $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
            ->execute([$gameId, $defender['id'], 'game_over', json_encode(['winner' => $playerId, 'opponentShips' => $attackerShips])]);
    } else {
        // 7. переключить очередь — только при промахе; при попадании
        // атакующий стреляет ещё раз (то же правило, что в game.js).
        $nextTurn = $hit ? $playerId : $defender['id'];
        $pdo->prepare('UPDATE games SET turn = ? WHERE id = ?')
            ->execute([$nextTurn, $gameId]);
        $response['nextTurn'] = $nextTurn;
    }

    $pdo->commit();
    echo json_encode($response);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('attack.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
