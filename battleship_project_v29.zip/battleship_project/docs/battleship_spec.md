# Морской бой — техническая концепция проекта

## Обзор

Браузерная игра "Морской бой" для двух игроков.  
Полноэкранный веб-интерфейс, работающий на shared хостинге (cPanel, PHP + MySQL).

Реализуется в два блока:
- **Блок A** — локальная игра на одном устройстве (горячая замена ходов)
- **Блок B** — онлайн-режим поверх готовой игры (HTTP polling, PHP + MySQL)

Такой подход позволяет отладить всю игровую логику и интерфейс до появления сети.

---

## Стек технологий

| Слой | Технология |
|------|-----------|
| Клиент | HTML5 + CSS3 + Vanilla JS (ES6 модули) |
| Сервер | PHP 7.4+ (только Блок B) |
| База данных | MySQL 5.7+ (только Блок B) |
| Протокол | HTTP polling, GET/POST + JSON (только Блок B) |
| Хостинг | Shared hosting, cPanel |

---

## Структура файлов

```
public_html/
├── (WordPress — существующий сайт)
└── game/
    ├── index.html          # Точка входа, полноэкранное приложение
    ├── css/
    │   ├── game.css        # Общая раскладка, полноэкранный режим
    │   └── board.css       # Сетки игровых полей
    ├── js/
    │   ├── game.js         # Состояние игры, логика ходов и победы
    │   ├── board.js        # Отрисовка полей в DOM
    │   ├── ui.js           # Экраны, уведомления, переходы
    │   ├── api.js          # [Блок B] Все HTTP-запросы к серверу
    │   └── poll.js         # [Блок B] Таймер опроса сервера
    └── api/                # [Блок B]
        ├── db.php          # Подключение к БД
        ├── join.php        # Регистрация игрока, поиск матча
        ├── place_ships.php # Приём расстановки кораблей
        ├── attack.php      # Приём хода, проверка попадания
        └── poll.php        # Выдача новых событий по lastEventId
```

---

## Игровые фазы

```
1. LOBBY      — выбор режима (локально / онлайн), ввод имён
2. PLACING    — каждый игрок расставляет свои корабли (экран скрыт от другого)
3. PLAYING    — поочерёдные ходы до победы
4. FINISHED   — показ результата и кораблей противника
```

В локальном режиме между фазами PLACING и PLAYING — экран "передайте устройство".

---

## Состав кораблей (стандарт)

| Размер | Количество |
|--------|-----------|
| 4 клетки | 1 |
| 3 клетки | 2 |
| 2 клетки | 3 |
| 1 клетка | 4 |

Итого: 10 кораблей, 20 клеток из 100.

---

## JS-сервисы (клиент)

### `game.js` — ядро, не меняется при переходе в онлайн
Хранит полное состояние игры:
- `phase` — текущая фаза (lobby / placing / playing / finished)
- `players[0/1]` — имя, корабли, клетки под ударом
- `currentPlayer` — чья очередь (0 или 1)
- `mode` — `'local'` или `'online'`

Методы:
- `placeShips(playerIndex, ships)` — сохранить расстановку
- `attack(x, y)` — проверить попадание, обновить состояние, передать ход
- `checkWin()` — вернуть победителя или null
- `switchTurn()` — в локальном режиме просто меняет `currentPlayer`; в онлайн-режиме заменяется вызовом `api.attack()`

### `board.js`
Принимает состояние из `game.js`, рендерит два поля 10×10 в DOM.  
Вешает обработчики кликов по клеткам поля противника.  
Не содержит игровой логики — только отрисовка.

### `ui.js`
Управляет видимостью экранов: `#screen-lobby`, `#screen-placing`, `#screen-handoff`, `#screen-game`, `#screen-over`.  
Показывает toast-уведомления ("Попадание!", "Мимо!", "Ваш ход").  
В локальном режиме показывает экран "передайте устройство" между ходами.

### `api.js` — только Блок B
Единственный файл, знающий URL серверных скриптов.  
Экспортирует: `join(name)`, `placeShips(ships)`, `attack(x, y)`, `poll(lastEventId)`.  
Все остальные сервисы работают только через него.

### `poll.js` — только Блок B
Запускает `setInterval`: 3000 мс в фазах LOBBY/PLACING, 1500 мс в фазе PLAYING.  
При получении событий вызывает методы `game.js`.  
Останавливается при `phase === 'finished'`.

---

## Протокол обмена — Блок B (JSON over HTTP)

### Подключение
**POST** `api/join.php`
```json
Запрос:  { "name": "alice" }
Ответ:   { "gameId": "abc123", "playerId": "p1", "status": "waiting" }
```
Статус `waiting` — ждём второго игрока через polling.

### Расстановка
**POST** `api/place_ships.php`
```json
Запрос:  { "gameId": "abc123", "playerId": "p1", "ships": [ ... ] }
Ответ:   { "ok": true }
```

### Ход
**POST** `api/attack.php`

Правило очереди: при попадании атакующий стреляет ещё раз (внеочередной
ход), при промахе очередь переходит к противнику.

```json
Запрос:  { "gameId": "abc123", "playerId": "p1", "x": 3, "y": 4 }

Ответ (промах, очередь переходит):
{ "hit": false, "sunk": false, "nextTurn": "p2" }

Ответ (попадание, внеочередной ход — стреляет тот же игрок):
{ "hit": true,  "sunk": true,  "shipCells": [[3,4],[3,5]], "nextTurn": "p1" }

Ответ (победа):
{ "hit": true,  "sunk": true,  "gameOver": true, "winner": "p1", "opponentShips": [...] }
```

### Polling
**GET** `api/poll.php?gameId=abc123&playerId=p1&lastEventId=0`
```json
{ "events": [
    { "id": 5, "type": "enemy_attack",   "x": 7, "y": 1, "hit": false },
    { "id": 6, "type": "opponent_ready" },
    { "id": 7, "type": "game_over",      "winner": "p2", "opponentShips": [...] }
] }
```

---

## База данных — Блок B

```sql
CREATE TABLE games (
  id         VARCHAR(12) PRIMARY KEY,
  status     ENUM('waiting','placing','playing','finished') NOT NULL,
  turn       VARCHAR(12),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE players (
  id         VARCHAR(12) PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  name       VARCHAR(50) NOT NULL,
  ships      JSON,
  ready      TINYINT(1) DEFAULT 0,
  last_seen  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id)
);

CREATE TABLE moves (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  player_id  VARCHAR(12) NOT NULL,
  x          TINYINT NOT NULL,
  y          TINYINT NOT NULL,
  hit        TINYINT(1) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id)
);

CREATE TABLE events (
  id         INT AUTO_INCREMENT PRIMARY KEY,
  game_id    VARCHAR(12) NOT NULL,
  for_player VARCHAR(12) NOT NULL,
  type       VARCHAR(30) NOT NULL,
  payload    JSON,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (game_id) REFERENCES games(id)
);
```

---

## Валидация на сервере (attack.php)

1. `playerId` принадлежит матчу `gameId`
2. `games.turn === playerId` — действительно его очередь
3. Клетка `(x, y)` ещё не атаковалась (нет в таблице `moves`)
4. Проверить попадание по `players.ships` противника
5. Записать ход в `moves`
6. Записать событие `enemy_attack` в `events` для противника
7. Переключить `games.turn`
8. Если потоплены все корабли — записать `game_over` для обоих, перевести в `finished`
9. Вернуть результат

---

## Заметки по реализации

- `gameId` и `playerId` генерируются как `bin2hex(random_bytes(6))` на сервере
- `sessionStorage` хранит `gameId` и `playerId` — при перезагрузке страницы игра восстанавливается
- Если игрок не делал polling > 30 сек — считается отключившимся, противник получает событие `opponent_left`
- Старые матчи удаляются крон-задачей раз в сутки
