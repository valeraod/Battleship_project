/* ════════════════════════════════════════════════════════
   ai.js — сервис: компьютерный противник
   Этап 9.1: уровень Юнга (случайные выстрелы + добивание).
   Этап 9.3: уровень Капитан (вероятностная карта + добивание).
   Этап 9.3.1: Капитан + мёртвая зона вокруг потопленных кораблей
               (клетки рядом с потопленным кораблём заведомо пусты —
               Капитан их больше не простреливает и не учитывает
               в вероятностной карте; для Юнги не применяется).
   Этап 9.4: уровень Адмирал (шахматный паттерн + добивание) — не сделан.

   Публичный интерфейс:
     AI.reset()             — сбросить состояние перед новой партией
     AI.makeMove(difficulty) — вернуть {x, y} следующего выстрела

   Внутреннее состояние хранится здесь, не в Game.state.
   AI не делает выстрел сам — только возвращает координаты.
   Применение результата (Game.attack) и анимация — в lobby.js.
   ════════════════════════════════════════════════════════ */

window.AI = (() => {

  // ── Внутреннее состояние ──
  let shot = new Set();      // 'x,y' — все уже простреленные клетки
  let missCells = new Set(); // 'x,y' — клетки, где корабля точно нет:
                              // промахи + (для Капитана) мёртвая зона вокруг
                              // потопленных кораблей. Используется вероятностной
                              // картой уровня Капитан — такие клетки не могут
                              // содержать корабль, значит размещение через
                              // них невалидно.
  let sunkSizes = [];         // размеры уже потопленных кораблей этой партии
                               // (используется вероятностной картой, чтобы
                               // не учитывать в "оставшихся кораблях" типы,
                               // которые уже все потоплены)

  // Режим добивания: активен после первого попадания до потопления корабля
  let huntMode = false;
  let firstHit = null;       // {x, y} — первое попадание по текущему кораблю
  let hitAxis = null;         // null | 'H' | 'V' — ось, определённая после 2-го попадания
  let hitDirection = null;    // null | 1 | -1 — текущее направление добивания вдоль оси
  let lastHit = null;         // {x, y} — последнее попадание (для продолжения добивания)
  let pendingNeighbors = [];  // соседи firstHit, которые ещё не пробовали (до фиксации оси)

  // Запоминаем уровень сложности последнего makeMove(), чтобы registerResult()
  // знал, нужно ли применять бонусы конкретного уровня (например, мёртвую
  // зону Капитана) — без изменения внешнего контракта (lobby.js продолжает
  // вызывать makeMove(difficulty) и registerResult(x, y, result) как раньше).
  let currentDifficulty = null;

  // ── Публичный сброс состояния ──
  function reset() {
    shot = new Set();
    missCells = new Set();
    sunkSizes = [];
    huntMode = false;
    firstHit = null;
    hitAxis = null;
    hitDirection = null;
    lastHit = null;
    pendingNeighbors = [];
    currentDifficulty = null;
  }

  // ── Вспомогательные ──
  function key(x, y) { return x + ',' + y; }
  function inBounds(x, y) { return x >= 0 && x <= 9 && y >= 0 && y <= 9; }
  function notShot(x, y) { return inBounds(x, y) && !shot.has(key(x, y)); }

  function shuffle(arr) {
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }

  // Все 4 соседа клетки в случайном порядке
  function neighbors(x, y) {
    return shuffle([
      { x: x - 1, y },
      { x: x + 1, y },
      { x, y: y - 1 },
      { x, y: y + 1 },
    ]).filter(p => notShot(p.x, p.y));
  }

  // Случайная непростреленная клетка
  function randomCell() {
    const candidates = [];
    for (let x = 0; x < 10; x++)
      for (let y = 0; y < 10; y++)
        if (notShot(x, y)) candidates.push({ x, y });
    return candidates[Math.floor(Math.random() * candidates.length)] || null;
  }

  // ── Мёртвая зона вокруг потопленного корабля (только для Капитана) ──
  // По правилам игры корабли не могут касаться друг друга даже по диагонали,
  // поэтому все клетки вокруг только что потопленного корабля гарантированно
  // пусты. Помечаем их:
  //   - в missCells, чтобы вероятностная карта (canFitAt) не считала через
  //     них размещения оставшихся кораблей;
  //   - в shot, чтобы Капитан вообще не тратил на них реальный выстрел.
  // Юнга не вызывает эту функцию и продолжает играть как раньше.
  function markDeadZone(shipCoords) {
    shipCoords.forEach(([cx, cy]) => {
      for (let dx = -1; dx <= 1; dx++) {
        for (let dy = -1; dy <= 1; dy++) {
          if (dx === 0 && dy === 0) continue;
          const nx = cx + dx, ny = cy + dy;
          if (!inBounds(nx, ny)) continue;
          const k = key(nx, ny);
          missCells.add(k);
          shot.add(k);
        }
      }
    });
  }

  // ── Регистрация результата выстрела ──
  // Вызывается из lobby.js после Game.attack(), чтобы AI обновил
  // своё внутреннее состояние (режим добивания, ось, направление).
  function registerResult(x, y, result) {
    shot.add(key(x, y));

    if (!result) return;

    if (!result.hit) {
      missCells.add(key(x, y));
    }

    if (result.sunk) {
      // Корабль потоплен — запомнить его размер для вероятностной карты
      // и сбросить режим добивания.
      if (Array.isArray(result.shipCoords)) {
        sunkSizes.push(result.shipCoords.length);
        // Мёртвая зона — только для Капитана. Юнга не знает о ней и
        // продолжает играть случайным поиском как раньше.
        if (currentDifficulty === 'mid') {
          markDeadZone(result.shipCoords);
        }
      }
      huntMode = false;
      firstHit = null;
      hitAxis = null;
      hitDirection = null;
      lastHit = null;
      pendingNeighbors = [];
      return;
    }

    if (result.hit) {
      if (!huntMode) {
        // Первое попадание — входим в режим добивания
        huntMode = true;
        firstHit = { x, y };
        lastHit = { x, y };
        hitAxis = null;
        hitDirection = null;
        pendingNeighbors = neighbors(x, y);
      } else {
        // Второе+ попадание — фиксируем ось и направление
        lastHit = { x, y };
        if (hitAxis === null) {
          hitAxis = (x !== firstHit.x) ? 'H' : 'V';
          hitDirection = hitAxis === 'H' ? (x - firstHit.x) : (y - firstHit.y);
          hitDirection = hitDirection > 0 ? 1 : -1;
        }
      }
    } else {
      // Промах в режиме добивания — если ось уже зафиксирована,
      // разворачиваемся в противоположную сторону от firstHit
      if (huntMode && hitAxis !== null) {
        hitDirection = -hitDirection;
        lastHit = firstHit; // начинаем от первого попадания в другую сторону
      }
    }
  }

  // ── Следующий выстрел в режиме добивания ──
  function huntMove() {
    if (hitAxis === null) {
      // Ось ещё не определена — пробуем соседей firstHit по одному
      // (pendingNeighbors уже перемешаны в shuffle при заполнении)
      while (pendingNeighbors.length > 0) {
        const next = pendingNeighbors.shift();
        if (notShot(next.x, next.y)) return next;
      }
      // Все соседи простреляны (не должно случаться в нормальной игре)
      huntMode = false;
      return randomCell();
    }

    // Ось зафиксирована — продолжаем в направлении hitDirection
    const nx = lastHit.x + (hitAxis === 'H' ? hitDirection : 0);
    const ny = lastHit.y + (hitAxis === 'V' ? hitDirection : 0);

    if (notShot(nx, ny)) {
      return { x: nx, y: ny };
    }

    // Упёрлись в край или простреленную клетку — разворот от firstHit
    hitDirection = -hitDirection;
    lastHit = firstHit;
    const rx = lastHit.x + (hitAxis === 'H' ? hitDirection : 0);
    const ry = lastHit.y + (hitAxis === 'V' ? hitDirection : 0);
    if (notShot(rx, ry)) {
      return { x: rx, y: ry };
    }

    // Оба направления исчерпаны (редкий случай) — случайная клетка
    huntMode = false;
    return randomCell();
  }

  // ── Уровень Юнга: случайные выстрелы + добивание ──
  function makeMoveEasy() {
    if (huntMode) return huntMove();
    return randomCell();
  }

  /* ════════════════════════════════════════════════════════
     Этап 9.3 — уровень Капитан: вероятностная карта + добивание
     Режим добивания (huntMode) общий для всех уровней — см. huntMove()
     выше. Капитан отличается от Юнги только тем, КАК выбирается
     клетка, когда добивания нет: вместо случайной — клетка, через
     которую теоретически может проходить наибольшее число оставшихся
     (ещё не потопленных) кораблей.
     ════════════════════════════════════════════════════════ */

  /**
   * Сколько кораблей каждого размера ещё не потоплено в этой партии.
   * Считается от полного состава флота (Game.SHIP_TYPES) минус то,
   * что уже потоплено (sunkSizes) — без знания, где именно стоят
   * оставшиеся корабли, только их размеры.
   * @returns {number[]} например [4,3,3,2,2,2,1,1,1,1] для нового боя
   */
  function remainingShipSizes() {
    const allSizes = [];
    window.Game.SHIP_TYPES.forEach(type => {
      type.ids.forEach(() => allSizes.push(type.size));
    });
    const remaining = [...allSizes];
    sunkSizes.forEach(size => {
      const idx = remaining.indexOf(size);
      if (idx !== -1) remaining.splice(idx, 1);
    });
    return remaining;
  }

  /**
   * Можно ли разместить корабль длины size в клетке (x,y) вдоль
   * направления dir ('H' — по x, 'V' — по y)? Валидно, если все
   * клетки в границах поля и ни одна не отмечена как промах (клетки
   * с попаданием — можно, корабль логически продолжается через них).
   */
  function canFitAt(x, y, size, dir) {
    for (let i = 0; i < size; i++) {
      const cx = dir === 'H' ? x + i : x;
      const cy = dir === 'H' ? y : y + i;
      if (!inBounds(cx, cy)) return false;
      if (missCells.has(key(cx, cy))) return false;
    }
    return true;
  }

  /**
   * Построить карту весов: для каждой непростреленной клетки — сколько
   * валидных размещений оставшихся кораблей через неё проходит.
   * Чем больше вес, тем вероятнее там корабль.
   * @returns {Map<string, number>} key 'x,y' -> вес
   */
  function buildProbabilityMap() {
    const weights = new Map();
    const sizes = remainingShipSizes();

    sizes.forEach(size => {
      for (let y = 0; y < 10; y++) {
        for (let x = 0; x < 10; x++) {
          ['H', 'V'].forEach(dir => {
            if (!canFitAt(x, y, size, dir)) return;
            for (let i = 0; i < size; i++) {
              const cx = dir === 'H' ? x + i : x;
              const cy = dir === 'H' ? y : y + i;
              const k = key(cx, cy);
              weights.set(k, (weights.get(k) || 0) + 1);
            }
          });
        }
      }
    });

    return weights;
  }

  /**
   * Выбрать непростреленную клетку с максимальным весом по
   * вероятностной карте. При нескольких клетках с одинаковым
   * максимальным весом — случайный выбор среди них (чтобы ИИ не был
   * полностью детерминированным и предсказуемым для игрока).
   * Если карта пуста (не должно случаться в нормальной игре) —
   * откат на случайную клетку.
   */
  function makeMoveMid() {
    if (huntMode) return huntMove();

    const weights = buildProbabilityMap();
    let bestWeight = -1;
    let bestCells = [];

    for (let y = 0; y < 10; y++) {
      for (let x = 0; x < 10; x++) {
        if (!notShot(x, y)) continue;
        const w = weights.get(key(x, y)) || 0;
        if (w > bestWeight) {
          bestWeight = w;
          bestCells = [{ x, y }];
        } else if (w === bestWeight) {
          bestCells.push({ x, y });
        }
      }
    }

    if (bestCells.length === 0) return randomCell();
    return bestCells[Math.floor(Math.random() * bestCells.length)];
  }

  // ── Публичный метод ──
  function makeMove(difficulty) {
    currentDifficulty = difficulty;
    switch (difficulty) {
      case 'easy': return makeMoveEasy();
      case 'mid':  return makeMoveMid();
      // 'hard' — Этап 9.4
      default:     return makeMoveEasy();
    }
  }

  return { reset, makeMove, registerResult };

})();
