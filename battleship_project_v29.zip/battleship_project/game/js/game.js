/* ════════════════════════════════════════════════════════
   game.js — сервис: состояние игры и игровая логика
   Этап 1: состояние + setPhase().
   Этап 2: + SHIP_TYPES, placeShips(), bothPlaced().
   Этап 3: + attack(), switchTurn(), checkWin().
   Этап 4: + battleStartedAt (время боя), resetGame().
   ════════════════════════════════════════════════════════ */

window.Game = (() => {

  // Соответствие фаз игры экранам интерфейса
  const PHASE_SCREEN = {
    lobby:            'screen-lobby',
    placing:          'screen-placing',
    placing_waiting:  'screen-lobby',  // онлайн: я готов, жду расстановку соперника (Этап 7.4)
    playing:          'screen-game',
    finished:         'screen-over',
  };

  // Состав флота: 10 кораблей, 4 типа (см. battleship_spec.md)
  const SHIP_TYPES = [
    { name: 'Линкор',  size: 4, ids: [0] },
    { name: 'Крейсер', size: 3, ids: [1, 2] },
    { name: 'Эсминец', size: 2, ids: [3, 4, 5] },
    { name: 'Катер',   size: 1, ids: [6, 7, 8, 9] },
  ];

  // Плоский список кораблей, удобный для перебора по id
  const SHIP_LIST = [];
  SHIP_TYPES.forEach(g => g.ids.forEach(id => SHIP_LIST.push({ id, name: g.name, size: g.size })));

  const TOTAL_SHIP_CELLS = SHIP_LIST.reduce((sum, s) => sum + s.size, 0); // 20

  // Состояние игры — единый источник правды для всех сервисов
  const state = {
    phase: 'lobby',         // lobby | placing | playing | finished
    mode: 'local',          // local | ai | online
    currentPlayer: 0,       // 0 или 1 — чья очередь стрелять
    winner: null,           // null | 0 | 1 — после finished
    battleStartedAt: null,  // timestamp начала боя (момент входа в 'playing') — для экрана результата
    onlineGameId: null,     // код игры на сервере — заполняется Online.join() (Этап 7.2+)
    onlinePlayerId: null,   // id текущего игрока в этой онлайн-партии
    onlineGameTurn: null,   // playerId, чей сейчас ход — из game_started, далее обновляется после attack/enemy_attack (Этап 7.5)
    options: {
      showDeadZone: false,  // подсвечивать мёртвую зону вокруг потопленного корабля
      aiDifficulty: 'mid',  // easy | mid | hard — задел под режим "Против ИИ"
    },
    players: [
      newPlayer('Игрок 1'),
      newPlayer('Игрок 2'),
    ],
  };

  function newPlayer(name) {
    return {
      name,
      ships: [],            // [{id, name, size, coords:[[c,r],...], dir}]
      shotsFired: [],        // выстрелы, сделанные этим игроком: [{x,y,hit,sunk,shipId}]
      shotsReceived: [],      // выстрелы, полученные этим игроком: [{x,y,hit}]
    };
  }

  /**
   * Переключить фазу игры и соответствующий экран.
   * @param {string} phase - lobby | placing | playing | finished
   */
  function setPhase(phase) {
    if (!PHASE_SCREEN[phase]) {
      console.error('Game.setPhase: неизвестная фаза "' + phase + '"');
      return;
    }
    if (phase === 'playing' && state.phase !== 'playing') {
      state.battleStartedAt = Date.now();
    }
    state.phase = phase;
    UI.showScreen(PHASE_SCREEN[phase]);
  }

  /**
   * Сохранить расстановку кораблей игрока.
   * @param {number} playerIndex - 0 или 1
   * @param {Array}  ships       - [{id, name, size, coords:[[c,r],...], dir}, ...]
   */
  function placeShips(playerIndex, ships) {
    if (playerIndex !== 0 && playerIndex !== 1) {
      console.error('Game.placeShips: неверный playerIndex', playerIndex);
      return;
    }
    if (!Array.isArray(ships) || ships.length !== SHIP_LIST.length) {
      console.error('Game.placeShips: ожидается массив из ' + SHIP_LIST.length + ' кораблей');
      return;
    }
    state.players[playerIndex].ships = ships;
    state.players[playerIndex].shotsFired = [];
    state.players[playerIndex].shotsReceived = [];
  }

  /**
   * Расставлены ли корабли у обоих игроков.
   * @returns {boolean}
   */
  function bothPlaced() {
    return state.players[0].ships.length === SHIP_LIST.length &&
           state.players[1].ships.length === SHIP_LIST.length;
  }

  /**
   * Сбросить партию для новой игры, сохранив имена игроков и опции
   * (showDeadZone, aiDifficulty). Используется кнопкой "Играть снова".
   */
  function resetGame() {
    state.currentPlayer = 0;
    state.winner = null;
    state.battleStartedAt = null;
    state.players[0] = newPlayer(state.players[0].name);
    state.players[1] = newPlayer(state.players[1].name);
  }

  /**
   * Текущий игрок делает выстрел по клетке (x, y) на поле противника.
   * Правило очереди: при попадании игрок стреляет ещё раз (внеочередной
   * ход), очередь переходит к другому игроку только при промахе.
   *
   * @param {number} x
   * @param {number} y
   * @returns {object|null} результат выстрела или null если выстрел недопустим
   *   { hit, sunk, shipId, shipCoords, turnSwitched, gameOver, winner }
   */
  function attack(x, y) {
    if (state.phase !== 'playing') {
      console.error('Game.attack: игра не в фазе "playing"');
      return null;
    }

    const attackerIdx = state.currentPlayer;
    const defenderIdx = 1 - attackerIdx;
    const attacker = state.players[attackerIdx];
    const defender = state.players[defenderIdx];

    // нельзя стрелять в уже атакованную клетку
    if (attacker.shotsFired.some(s => s.x === x && s.y === y)) {
      return null;
    }

    const hitShip = defender.ships.find(sh => sh.coords.some(([cx, cy]) => cx === x && cy === y));
    const hit = !!hitShip;

    let sunk = false;
    if (hit) {
      sunk = hitShip.coords.every(([cx, cy]) =>
        (cx === x && cy === y) ||
        attacker.shotsFired.some(s => s.x === cx && s.y === cy && s.hit)
      );
    }

    attacker.shotsFired.push({ x, y, hit, sunk, shipId: hit ? hitShip.id : null });
    defender.shotsReceived.push({ x, y, hit });

    // Опция "мёртвая зона": после потопления автоматически отметить как
    // промах соседние клетки корабля — там по правилам не может быть
    // другого корабля, игроку не нужно тратить на них выстрел.
    // deadZoneCells собираются отдельно и кладутся в result, чтобы
    // вызывающий код (lobby.js) мог передать их в AI.registerResult(),
    // когда атакующий — ИИ без собственной markDeadZone (уровень "Юнга").
    // Без этой синхронизации внутреннее состояние ai.js (shot/missCells)
    // расходится с Game.state: AI.makeMove() может предложить клетку,
    // которая здесь уже отмечена авто-промахом — Game.attack() на такой
    // повторный вызов вернёт null (см. защиту на строке 141 выше), и если
    // вызывающий код не учтёт это, партия зависает (был реальный баг,
    // воспроизводился через showDeadZone=true против уровня "Юнга" —
    // см. HANDOFF.md).
    const deadZoneCells = [];
    if (sunk && state.options.showDeadZone) {
      const shipCellSet = new Set(hitShip.coords.map(([cx, cy]) => cx + ',' + cy));
      const alreadyShot = new Set(attacker.shotsFired.map(s => s.x + ',' + s.y));
      hitShip.coords.forEach(([cx, cy]) => {
        for (let dx = -1; dx <= 1; dx++) {
          for (let dy = -1; dy <= 1; dy++) {
            const nx = cx + dx, ny = cy + dy;
            if (nx < 0 || nx > 9 || ny < 0 || ny > 9) continue;
            const key = nx + ',' + ny;
            if (shipCellSet.has(key) || alreadyShot.has(key)) continue;
            attacker.shotsFired.push({ x: nx, y: ny, hit: false, sunk: false, shipId: null, auto: true });
            alreadyShot.add(key);
            deadZoneCells.push({ x: nx, y: ny });
          }
        }
      });
    }

    const result = {
      hit, sunk,
      shipId: hit ? hitShip.id : null,
      shipCoords: sunk ? hitShip.coords : null,
      deadZoneCells, // [] если showDeadZone выключена или корабль не потоплен
      turnSwitched: false,
      gameOver: false,
      winner: null,
    };

    if (checkWin(defenderIdx)) {
      state.phase = 'finished';
      state.winner = attackerIdx;
      result.gameOver = true;
      result.winner = attackerIdx;
    } else if (!hit) {
      // Очередь переходит только при промахе. При попадании — внеочередной ход.
      switchTurn();
      result.turnSwitched = true;
    }

    return result;
  }

  /**
   * Переключить очередь хода на другого игрока.
   */
  function switchTurn() {
    state.currentPlayer = 1 - state.currentPlayer;
  }

  /**
   * Проверить, потоплены ли все корабли указанного игрока.
   * @param {number} playerIndex
   * @returns {boolean}
   */
  function checkWin(playerIndex) {
    const player = state.players[playerIndex];
    const hitCells = player.shotsReceived.filter(s => s.hit).length;
    return hitCells >= TOTAL_SHIP_CELLS;
  }

  return {
    state, setPhase, placeShips, bothPlaced, resetGame,
    attack, switchTurn, checkWin,
    SHIP_TYPES, SHIP_LIST, TOTAL_SHIP_CELLS,
  };

})();
