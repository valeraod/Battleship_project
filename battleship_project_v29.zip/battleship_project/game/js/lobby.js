/* ════════════════════════════════════════════════════════
   lobby.js — сервис: экран лобби (режимы, имена, опции)
   Перенесено из prototypes/lobby.html, подключено к Game.state.
   ════════════════════════════════════════════════════════ */

window.Lobby = (() => {

  const STORAGE_KEY = 'bs_names';
  let names = [];
  let mode = 'local';     // local | ai | online
  let diff = 'mid';        // easy | mid | hard
  let onStart = null;      // callback() — запуск партии в режиме local

  function loadNames() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) { names = JSON.parse(raw); return; }
    } catch (e) { /* localStorage недоступен — работаем без истории */ }
    names = [];
  }

  function saveNames() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(names)); } catch (e) { /* ignore */ }
  }

  /**
   * Построить экран лобби и подготовить обработчики.
   * @param {Function} startLocalGameCallback - вызывается, когда игрок
   *   нажал "В бой" в режиме "Локально" с введёнными именами
   */
  function init(startLocalGameCallback) {
    onStart = startLocalGameCallback;
    loadNames();
    mode = 'local';
    diff = 'mid';

    const gameIdFromLink = new URLSearchParams(location.search).get('game');
    if (gameIdFromLink) {
      renderJoinForm(gameIdFromLink);
      return;
    }

    render();
  }

  /**
   * Мини-форма "Введите имя" для игрока, открывшего игру по ссылке
   * (?game=<gameId> в URL). Этап 7.3 — после успешного подключения
   * пока только тост-заглушка; переход к совместной расстановке
   * подключается в Этапе 7.4.
   * @param {string} gameId
   */
  function renderJoinForm(gameId) {
    const root = document.getElementById('screen-lobby');
    root.innerHTML = `
      <div class="container py-4" style="max-width:480px">
        <div class="card shadow-sm">
          <div class="card-header px-3 py-2">Подключение к игре</div>
          <div class="card-body p-3">
            <div class="text-muted mb-3" style="font-size:13px">
              Вас пригласили сыграть в Морской бой. Введите имя, чтобы
              подключиться:
            </div>
            <label class="form-label">Ваш позывной</label>
            <input type="text" class="form-control mb-3" id="lb-join-name" placeholder="Введите имя..." maxlength="20" autocomplete="off">
            <button class="btn btn-start btn-blue w-100" id="lb-join-btn" style="font-size:13px;font-weight:600;padding:10px">Подключиться →</button>
          </div>
        </div>
      </div>`;

    document.getElementById('lb-join-btn').addEventListener('click', () => onJoinByLinkClick(gameId));
    document.getElementById('lb-join-name').addEventListener('keydown', e => {
      if (e.key === 'Enter') onJoinByLinkClick(gameId);
    });
  }

  async function onJoinByLinkClick(gameId) {
    const name = document.getElementById('lb-join-name').value.trim() || 'Игрок 2';
    const btn = document.getElementById('lb-join-btn');
    btn.disabled = true;
    btn.textContent = 'Подключаемся...';

    try {
      const result = await Online.join(name, gameId);
      rememberName(name);
      Game.state.players[1].name = name;
      Game.state.players[0].name = result.opponentName || 'Игрок 1';
      Game.state.onlineGameId = result.gameId;
      Game.state.onlinePlayerId = result.playerId;
      startOnlinePlacing(1);
    } catch (err) {
      UI.showToast('Не удалось подключиться: ' + describeError(err), 3000);
      btn.disabled = false;
      btn.textContent = 'Подключиться →';
    }
  }

  function render() {
    const root = document.getElementById('screen-lobby');
    root.innerHTML = `
      <div class="container py-4" style="max-width:480px">
        <div class="card shadow-sm">
          <div class="card-header px-3 py-2">Новый бой</div>
          <div class="card-body p-3">

            <label class="form-label">Ваш позывной</label>
            <div class="name-wrap mb-3">
              <input type="text" class="form-control pe-4" id="lb-inp1" placeholder="Введите имя..." maxlength="20" autocomplete="off">
              <button class="input-clear" id="lb-clr1">×</button>
              <div class="name-dropdown" id="lb-dd1">
                <div class="dd-header"><span>История</span><button class="dd-clear" id="lb-clear-history-1">Очистить</button></div>
                <div id="lb-dd1-list"></div>
              </div>
            </div>

            <hr class="my-3">

            <div class="form-label mb-2">Режим игры</div>
            <div class="row g-2 mb-3">
              <div class="col-4">
                <div class="mode-btn active-blue" id="lb-m-local">
                  <div class="mode-icon">💻</div>
                  <span class="mode-name">Локально</span>
                  <span class="mode-desc">Два игрока</span>
                </div>
              </div>
              <div class="col-4 position-relative">
                <span class="badge-ai">ИИ</span>
                <div class="mode-btn" id="lb-m-ai">
                  <div class="mode-icon">🤖</div>
                  <span class="mode-name">Против ИИ</span>
                  <span class="mode-desc">Один игрок</span>
                </div>
              </div>
              <div class="col-4 position-relative">
                <div class="mode-btn" id="lb-m-online">
                  <div class="mode-icon">🌐</div>
                  <span class="mode-name">Онлайн</span>
                  <span class="mode-desc">Через сеть</span>
                </div>
              </div>
            </div>

            <div id="lb-block-p2" class="mb-3">
              <label class="form-label">Позывной игрока 2</label>
              <div class="name-wrap">
                <input type="text" class="form-control pe-4" id="lb-inp2" placeholder="Введите имя..." maxlength="20" autocomplete="off">
                <button class="input-clear" id="lb-clr2">×</button>
                <div class="name-dropdown" id="lb-dd2">
                  <div class="dd-header"><span>История</span><button class="dd-clear" id="lb-clear-history-2">Очистить</button></div>
                  <div id="lb-dd2-list"></div>
                </div>
              </div>
            </div>

            <div id="lb-block-online" class="mb-3" style="display:none">
              <div class="text-muted" style="font-size:12px">
                Создайте игру и отправьте ссылку другу — он подключится,
                открыв её на своём устройстве.
              </div>
            </div>

            <div id="lb-block-ai" class="mb-3" style="display:none">
              <label class="form-label">Сложность</label>
              <div class="row g-2">
                <div class="col-4"><div class="diff-btn" id="lb-d-easy">Юнга</div></div>
                <div class="col-4"><div class="diff-btn d-mid" id="lb-d-mid">Капитан</div></div>
                <div class="col-4"><div class="diff-btn diff-btn-disabled" id="lb-d-hard">Адмирал</div></div>
              </div>
            </div>

            <hr class="my-3">

            <div class="form-check mb-1">
              <input class="form-check-input" type="checkbox" id="lb-chk-deadzone">
              <label class="form-check-label" for="lb-chk-deadzone" style="font-size:13px">Показывать мёртвую зону</label>
            </div>
            <div class="text-muted mb-3" style="font-size:11px;padding-left:24px">После потопления корабля автоматически отмечать клетки вокруг него</div>

            <button class="btn btn-start btn-blue w-100" id="lb-start-btn" style="font-size:13px;font-weight:600;padding:10px">В бой →</button>
          </div>
        </div>

        <div class="card mt-3 shadow-sm">
          <div class="card-body py-2 px-3">
            <div class="row text-center">
              <div class="col-3"><div class="stat-val">10×10</div><div class="stat-lbl">Поле</div></div>
              <div class="col-3"><div class="stat-val">10</div><div class="stat-lbl">Кораблей</div></div>
              <div class="col-3"><div class="stat-val">20</div><div class="stat-lbl">Клеток</div></div>
              <div class="col-3"><div class="stat-val">100</div><div class="stat-lbl">Ударов</div></div>
            </div>
          </div>
        </div>
      </div>`;

    wireEvents();
    renderDropdown(1, '');
    renderDropdown(2, '');
    refreshStartBtn();
  }

  function wireEvents() {
    document.getElementById('lb-m-local').addEventListener('click', () => setMode('local'));
    document.getElementById('lb-m-ai').addEventListener('click', () => setMode('ai'));
    document.getElementById('lb-m-online').addEventListener('click', () => setMode('online'));

    document.getElementById('lb-d-easy').addEventListener('click', () => setDiff('easy'));
    document.getElementById('lb-d-mid').addEventListener('click', () => setDiff('mid'));
    // 'Адмирал' (hard) — кнопка неактивна, см. Этап 9.4 в README/HANDOFF:
    // оба исследованных варианта чётности не дали убедительного выигрыша
    // над уже сильным Капитаном (мёртвая зона), решено не выпускать
    // неотличимый/слабый уровень под видом "сильнее всех". Слушатель клика
    // не навешивается осознанно — кнопка задизейблена через CSS
    // (pointer-events: none, притушенный вид).

    document.getElementById('lb-start-btn').addEventListener('click', onStartClick);

    [1, 2].forEach(id => {
      const inp = document.getElementById('lb-inp' + id);
      const clr = document.getElementById('lb-clr' + id);
      if (!inp) return;
      inp.addEventListener('focus', () => openDropdown(id));
      inp.addEventListener('input', () => {
        renderDropdown(id, inp.value);
        clr.style.display = inp.value ? 'block' : 'none';
        refreshStartBtn();
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Escape') closeDropdown(id); });
      clr.addEventListener('click', () => { clearInput(id); refreshStartBtn(); });
      document.getElementById('lb-clear-history-' + id).addEventListener('click', e => clearHistory(e));
    });

    document.addEventListener('click', outsideClickHandler);
  }

  function outsideClickHandler(e) {
    [1, 2].forEach(id => {
      const inp = document.getElementById('lb-inp' + id);
      if (!inp) return;
      const wrap = inp.closest('.name-wrap');
      if (wrap && !wrap.contains(e.target)) closeDropdown(id);
    });
  }

  // ── Режимы ──
  function setMode(m) {
    mode = m;

    document.getElementById('lb-m-local').classList.toggle('active-blue', m === 'local');
    document.getElementById('lb-m-ai').classList.toggle('active-blue', m === 'ai');
    document.getElementById('lb-m-online').classList.toggle('active-blue', m === 'online');

    document.getElementById('lb-block-p2').style.display = m === 'local' ? 'block' : 'none';
    document.getElementById('lb-block-ai').style.display = m === 'ai' ? 'block' : 'none';
    document.getElementById('lb-block-online').style.display = m === 'online' ? 'block' : 'none';

    document.getElementById('lb-start-btn').textContent = m === 'online' ? 'Создать игру →' : 'В бой →';
    refreshStartBtn();
  }

  /**
   * Обновить доступность кнопки старта в зависимости от заполненности имён.
   * Локальный: оба имени обязательны.
   * ИИ и онлайн: только имя игрока 1.
   */
  function refreshStartBtn() {
    const btn = document.getElementById('lb-start-btn');
    if (!btn) return;
    const n1 = (document.getElementById('lb-inp1')?.value || '').trim();
    const n2 = (document.getElementById('lb-inp2')?.value || '').trim();
    const ok = mode === 'local' ? (n1 !== '' && n2 !== '') : n1 !== '';
    btn.disabled = !ok;
  }

  function setDiff(d) {
    diff = d;
    // 'hard' исключён из цикла сброса намеренно: кнопка lb-d-hard всегда
    // несёт класс diff-btn-disabled (см. wireEvents) — если включить её
    // сюда, любое переключение на 'easy'/'mid' стирало бы disabled-вид
    // и возвращало кликабельность отключённой кнопке.
    ['easy', 'mid'].forEach(x => { document.getElementById('lb-d-' + x).className = 'diff-btn'; });
    document.getElementById('lb-d-' + d).className = 'diff-btn d-' + d;
  }

  // ── История имён ──
  function renderDropdown(id, filter) {
    const list = document.getElementById('lb-dd' + id + '-list');
    if (!list) return;
    const filtered = filter ? names.filter(n => n.toLowerCase().includes(filter.toLowerCase())) : names;
    if (!filtered.length) {
      list.innerHTML = '<div class="dd-item text-muted" style="cursor:default">История пуста</div>';
      return;
    }
    list.innerHTML = filtered.map(n => `
      <div class="dd-item" data-name="${n}">
        <span>👤</span><span>${n}</span>
        <button class="dd-del" data-del="${n}">×</button>
      </div>`).join('');

    list.querySelectorAll('.dd-item').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.dd-del')) return;
        pickName(id, el.dataset.name);
      });
    });
    list.querySelectorAll('.dd-del').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); deleteName(id, el.dataset.del); });
    });
  }

  function openDropdown(id) { renderDropdown(id, document.getElementById('lb-inp' + id).value); document.getElementById('lb-dd' + id).classList.add('open'); }
  function closeDropdown(id) { document.getElementById('lb-dd' + id)?.classList.remove('open'); }
  function pickName(id, name) {
    document.getElementById('lb-inp' + id).value = name;
    document.getElementById('lb-clr' + id).style.display = 'block';
    closeDropdown(id);
    refreshStartBtn();
  }
  function clearInput(id) {
    document.getElementById('lb-inp' + id).value = '';
    document.getElementById('lb-clr' + id).style.display = 'none';
    document.getElementById('lb-inp' + id).focus();
  }
  function clearHistory(e) {
    e.stopPropagation();
    names = [];
    saveNames();
    renderDropdown(1, document.getElementById('lb-inp1')?.value || '');
    renderDropdown(2, document.getElementById('lb-inp2')?.value || '');
  }
  function deleteName(id, name) {
    names = names.filter(n => n !== name);
    saveNames();
    renderDropdown(1, document.getElementById('lb-inp1')?.value || '');
    renderDropdown(2, document.getElementById('lb-inp2')?.value || '');
  }
  function rememberName(name) {
    if (!name) return;
    names = names.filter(n => n !== name);
    names.unshift(name);
    if (names.length > 10) names.pop();
    saveNames();
  }

  // ── Старт партии ──
  function onStartClick() {
    if (mode === 'online') {
      onCreateGameClick();
      return;
    }

    const n1 = document.getElementById('lb-inp1').value.trim() || 'Игрок 1';
    const showDeadZone = document.getElementById('lb-chk-deadzone').checked;

    rememberName(document.getElementById('lb-inp1').value.trim());

    Game.state.players[0].name = n1;
    Game.state.options.showDeadZone = showDeadZone;
    Game.state.options.aiDifficulty = diff;
    Game.state.mode = mode;

    if (mode === 'ai') {
      Game.state.players[1].name = 'ИИ';
      startAIPlacing();
      return;
    }

    const n2 = document.getElementById('lb-inp2').value.trim() || 'Игрок 2';
    rememberName(document.getElementById('lb-inp2').value.trim());
    Game.state.players[1].name = n2;

    if (typeof onStart === 'function') onStart();
  }

  /* ════════════════════════════════════════════════════════
     Этап 9.2 — режим игры против ИИ
     ════════════════════════════════════════════════════════ */

  /**
   * Запустить расстановку для режима ИИ.
   * Человек расставляет корабли как обычно (playerIndex=0).
   * После нажатия «Готово» — авторасстановка за ИИ и старт боя.
   */
  function startAIPlacing() {
    Game.setPhase('placing');
    document.getElementById('placing-player-chip').style.display = 'inline-block';
    Board.initPlacing(0, null, (ships) => onAIShipsReady(ships));
  }

  /**
   * Колбэк готовности расстановки человека.
   * Сохраняем корабли человека, авторасставляем ИИ, запускаем бой.
   */
  function onAIShipsReady(ships) {
    Game.placeShips(0, ships);

    // Авторасстановка за ИИ — та же логика, что кнопка «Авторасстановка»
    // в board.js, но выполняется здесь без DOM
    const aiShips = autoPlaceShips();
    Game.placeShips(1, aiShips);

    document.getElementById('placing-player-chip').style.display = 'none';

    AI.reset();
    Game.setPhase('playing');
    Game.state.currentPlayer = 0; // человек всегда ходит первым

    const aiAdapter = buildAIAdapter();
    Board.initGame(onAIGameOver, aiAdapter);
  }

  /**
   * Авторасстановка кораблей (без DOM) — повторяет логику autoPlace()
   * из board.js, но возвращает массив ships для Game.placeShips().
   */
  function autoPlaceShips() {
    const SHIP_LIST = Game.SHIP_LIST;
    const board = Array.from({ length: 10 }, () => Array(10).fill(0));
    const placed = {};

    function coords4(c, r, size, d) {
      const res = [];
      for (let i = 0; i < size; i++) res.push(d === 'H' ? [c + i, r] : [c, r + i]);
      return res;
    }

    function nbrs(coords) {
      const set = new Set(coords.map(([c, r]) => c + ',' + r));
      const res = [];
      coords.forEach(([c, r]) => {
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          const nc = c + dc, nr = r + dr;
          if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && !set.has(nc + ',' + nr)) res.push([nc, nr]);
        }
      });
      return res;
    }

    function canPlace(coords) {
      return coords.every(([c, r]) => c >= 0 && c < 10 && r >= 0 && r < 10 && board[r][c] === 0) &&
        coords.every(([c, r]) => {
          for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
            if (!dr && !dc) continue;
            const nc = c + dc, nr = r + dr;
            if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && board[nr][nc] === 1) return false;
          }
          return true;
        });
    }

    SHIP_LIST.forEach(ship => {
      let ok = false;
      for (let i = 0; i < 500 && !ok; i++) {
        const d = Math.random() < 0.5 ? 'H' : 'V';
        const c = Math.floor(Math.random() * 10);
        const r = Math.floor(Math.random() * 10);
        const cs = coords4(c, r, ship.size, d);
        if (canPlace(cs)) {
          cs.forEach(([cc, rc]) => { board[rc][cc] = 1; });
          nbrs(cs).forEach(([cc, rc]) => { if (board[rc][cc] === 0) board[rc][cc] = 2; });
          placed[ship.id] = { coords: cs, dir: d };
          ok = true;
        }
      }
    });

    return SHIP_LIST.map(s => ({
      id: s.id, name: s.name, size: s.size,
      coords: placed[s.id].coords, dir: placed[s.id].dir,
    }));
  }

  /**
   * Собрать aiAdapter — тот же контракт, что onlineAdapter в Board.initGame().
   * myIndex: 0 (человек всегда игрок 0).
   * isMyTurn(): true когда currentPlayer === 0.
   * attack(x, y): выстрел человека → Game.attack() → если не конец и не
   *   попадание, через 800мс ИИ делает свой ход.
   */
  function buildAIAdapter() {
    const myIndex = 0;
    const aiIndex = 1;
    const difficulty = Game.state.options.aiDifficulty;

    return {
      myIndex,
      isMyTurn: () => Game.state.currentPlayer === myIndex,

      attack: (x, y) => new Promise((resolve) => {
        // Выстрел человека
        const result = Game.attack(x, y);
        if (!result) { resolve(null); return; }

        resolve({
          hit: result.hit,
          sunk: result.sunk,
          shipCoords: result.shipCoords,
          gameOver: result.gameOver,
          winner: result.gameOver ? myIndex : null,
        });

        if (result.gameOver) return;

        // Если промах — очередь переходит к ИИ
        if (!result.hit) {
          scheduleAIMove(myIndex, aiIndex, difficulty);
        }
        // Если попадание — человек стреляет снова (board.js покажет тост и обновит экран)
      }),
    };
  }

  /**
   * Запланировать ход ИИ через 800мс. После каждого хода ИИ:
   * - если попадание и не конец — ИИ снова ходит через 800мс
   * - если промах — очередь возвращается человеку (board.js обновит экран)
   * - если конец игры — вызываем onAIGameOver
   */
  function scheduleAIMove(myIndex, aiIndex, difficulty) {
    setTimeout(() => {
      const move = AI.makeMove(difficulty);
      if (!move) return;

      const result = Game.attack(move.x, move.y);
      if (!result) return;

      AI.registerResult(move.x, move.y, result);

      // Синхронизация с showDeadZone: если этот ход потопил корабль и
      // включена опция "Показывать мёртвую зону", Game.attack() уже
      // отметил соседние пустые клетки как авто-промахи в Game.state
      // (result.deadZoneCells). ai.js должен узнать об этих клетках тоже —
      // иначе его внутреннее состояние (shot/missCells) расходится с
      // Game.state, AI.makeMove() в следующий раз может предложить одну
      // из них снова, а Game.attack() на повторный выстрел в уже
      // простреленную клетку вернёт null (защита на уровне game.js) —
      // без этой синхронизации партия зависала молча (был реальный баг,
      // воспроизводился через showDeadZone=true против уровня "Юнга",
      // у которой нет собственной markDeadZone в отличие от Капитана).
      if (result.deadZoneCells && result.deadZoneCells.length > 0) {
        result.deadZoneCells.forEach(cell => {
          AI.registerResult(cell.x, cell.y, { hit: false, sunk: false });
        });
      }

      // Применяем входящий удар ИИ на поле человека через board.js
      Board.applyIncomingAttack(move.x, move.y, {
        hit: result.hit,
        sunk: result.sunk,
        gameOver: result.gameOver,
        winner: result.gameOver ? aiIndex : null,
      });

      if (result.gameOver) {
        Game.state.winner = aiIndex;
        setTimeout(() => onAIGameOver({ gameOver: true, winner: aiIndex }), 1200);
        return;
      }

      // Если попадание — ИИ ходит снова
      if (result.hit) {
        scheduleAIMove(myIndex, aiIndex, difficulty);
      }
      // Если промах — board.js покажет тост и вернёт ход человеку через refreshGameAll()
    }, 800);
  }

  function onAIGameOver(result) {
    Game.setPhase('finished');
    Board.initOver(
      () => {
        // «Играть снова» в режиме ИИ — та же пара, новая расстановка
        Game.resetGame();
        Game.state.mode = 'ai';
        startAIPlacing();
      },
      () => { Game.setPhase('lobby'); Lobby.init(onStart); }
    );
  }

  // ── Онлайн: создание новой игры ──
  let onlinePollTimer = null;
  let pollFailCount = 0; // подряд идущих неудач поллинга — общий счётчик,
                          // т.к. в любой момент активен только один из
                          // трёх поллингов (ожидание/расстановка/бой)

  /**
   * Вызывать в catch каждого поллинга. После 3 подряд неудач показывает
   * toast о проблемах с соединением — не на первую же неудачу (разовые
   * сетевые сбои бывают и сами восстанавливаются за один-два тика).
   * Дальше не спамит повторно на каждом тике, пока не пройдёт удачный
   * запрос (reportPollSuccess сбрасывает счётчик).
   */
  function reportPollFailure(context, err) {
    console.error('Online poll error (' + context + '):', err);
    pollFailCount++;
    if (pollFailCount === 3) {
      UI.showToast('Проблемы с подключением — проверьте интернет', 4000);
    }
  }

  function reportPollSuccess() {
    pollFailCount = 0;
  }

  async function onCreateGameClick() {
    const name = document.getElementById('lb-inp1').value.trim() || 'Игрок 1';
    rememberName(document.getElementById('lb-inp1').value.trim());

    const startBtn = document.getElementById('lb-start-btn');
    startBtn.disabled = true;
    startBtn.textContent = 'Создаём игру...';

    try {
      const result = await Online.join(name);
      Game.state.players[0].name = name;
      Game.state.onlineGameId = result.gameId;
      Game.state.onlinePlayerId = result.playerId;
      renderOnlineWaiting(result.gameId);
    } catch (err) {
      if (err.code === 'server_busy') {
        startBtn.disabled = false;
        startBtn.textContent = 'Создать игру →';
        const confirmed = confirm('Есть незавершённая игра. Завершить и создать новую?');
        if (!confirmed) return;
        try {
          startBtn.disabled = true;
          startBtn.textContent = 'Завершаем старую игру...';
          await Online.abandon();
          const result2 = await Online.join(name);
          Game.state.players[0].name = name;
          Game.state.onlineGameId = result2.gameId;
          Game.state.onlinePlayerId = result2.playerId;
          renderOnlineWaiting(result2.gameId);
        } catch (err2) {
          UI.showToast('Не удалось создать игру: ' + describeError(err2), 3000);
          startBtn.disabled = false;
          startBtn.textContent = 'Создать игру →';
        }
      } else {
        UI.showToast('Не удалось создать игру: ' + describeError(err), 3000);
        startBtn.disabled = false;
        startBtn.textContent = 'Создать игру →';
      }
    }
  }

  /**
   * Экран ожидания после создания игры: ссылка для друга + поллинг
   * события opponent_joined. Подэтап 7.2 — дальше (расстановка,
   * игра) подключается в 7.3+.
   * @param {string} gameId
   */
  function renderOnlineWaiting(gameId) {
    const link = buildInviteLink(gameId);
    const root = document.getElementById('screen-lobby');
    root.innerHTML = `
      <div class="container py-4" style="max-width:480px">
        <div class="card shadow-sm">
          <div class="card-header px-3 py-2">Ожидание соперника</div>
          <div class="card-body p-3">
            <div class="text-muted mb-2" style="font-size:13px">
              Отправьте эту ссылку другу — он подключится, открыв её:
            </div>
            <div class="input-group mb-3">
              <input type="text" class="form-control" id="lb-invite-link" value="${link}" readonly style="font-size:12px">
              <button class="btn btn-outline-secondary" id="lb-copy-link" type="button">Скопировать</button>
            </div>
            <div class="d-flex align-items-center gap-2 text-muted" style="font-size:13px">
              <span class="spinner-border spinner-border-sm" role="status"></span>
              Ждём подключения соперника...
            </div>
            <hr class="my-3">
            <button class="btn btn-act w-100" id="lb-cancel-online">← Назад в лобби</button>
          </div>
        </div>
      </div>`;

    document.getElementById('lb-copy-link').addEventListener('click', () => copyInviteLink(link));
    document.getElementById('lb-cancel-online').addEventListener('click', () => {
      stopOnlinePoll();
      render();
    });

    startOnlinePoll(gameId);
  }

  function buildInviteLink(gameId) {
    const url = new URL(location.href);
    url.search = '?game=' + encodeURIComponent(gameId);
    return url.toString();
  }

  function copyInviteLink(link) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(link)
        .then(() => UI.showToast('Ссылка скопирована'))
        .catch(() => UI.showToast('Не удалось скопировать — выделите ссылку вручную'));
    } else {
      UI.showToast('Скопируйте ссылку вручную (выделите поле)');
    }
  }

  function startOnlinePoll(gameId) {
    let lastEventId = 0;
    onlinePollTimer = setInterval(async () => {
      try {
        const { events } = await Online.poll(gameId, Game.state.onlinePlayerId, lastEventId);
        reportPollSuccess();
        for (const ev of events) {
          lastEventId = Math.max(lastEventId, ev.id);
          if (ev.type === 'opponent_joined') {
            stopOnlinePoll();
            Game.state.players[1].name = ev.name;
            UI.showToast('Соперник «' + ev.name + '» подключился!');
            startOnlinePlacing(0);
          }
        }
      } catch (err) {
        reportPollFailure('ожидание соперника', err);
      }
    }, 3000);
  }

  function stopOnlinePoll() {
    if (onlinePollTimer) {
      clearInterval(onlinePollTimer);
      onlinePollTimer = null;
    }
    pollFailCount = 0;
  }

  /* ════════════════════════════════════════════════════════
     Этап 7.4 — совместная расстановка в онлайне
     ════════════════════════════════════════════════════════ */

  /**
   * Запустить расстановку для онлайн-партии. Вызывается и создателем
   * игры (myIndex=0, после opponent_joined), и присоединившимся
   * (myIndex=1, сразу после успешного join) — в онлайне оба видят
   * расстановку сразу, без передачи устройства друг другу.
   * @param {number} myIndex - 0 или 1, какой из Game.state.players — я
   */
  function startOnlinePlacing(myIndex) {
    Game.setPhase('placing');
    Board.initPlacing(myIndex, null, (ships) => onOnlineShipsReady(myIndex, ships));
  }

  /**
   * Колбэк готовности расстановки (заменяет onReadyClick локального
   * режима — см. изменение в board.js). Отправляет ships на сервер
   * и показывает экран ожидания соперника.
   */
  async function onOnlineShipsReady(myIndex, ships) {
    const gameId = Game.state.onlineGameId;
    const playerId = Game.state.onlinePlayerId;

    try {
      const result = await Online.placeShips(gameId, playerId, ships);
      Game.state.players[myIndex].ships = ships; // для локального отображения своего поля
      if (result.status === 'playing') {
        // Соперник тоже уже готов (редкий, но возможный случай —
        // он мог расставить корабли быстрее нас).
        Game.state.onlineGameTurn = result.turn;
        startOnlineBattle(myIndex);
      } else {
        renderWaitingForOpponentPlacing(myIndex);
      }
    } catch (err) {
      UI.showToast('Не удалось отправить расстановку: ' + describeError(err), 3000);
    }
  }

  function renderWaitingForOpponentPlacing(myIndex) {
    Game.setPhase('placing_waiting');
    const root = document.getElementById('screen-lobby');
    root.innerHTML = `
      <div class="container py-4" style="max-width:480px">
        <div class="card shadow-sm">
          <div class="card-header px-3 py-2">Ваши корабли расставлены</div>
          <div class="card-body p-3">
            <div class="d-flex align-items-center gap-2 text-muted" style="font-size:13px">
              <span class="spinner-border spinner-border-sm" role="status"></span>
              Ждём, пока соперник расставит свои корабли...
            </div>
          </div>
        </div>
      </div>`;

    startGameStartedPoll(myIndex);
  }

  function startGameStartedPoll(myIndex) {
    let lastEventId = 0;
    onlinePollTimer = setInterval(async () => {
      try {
        const { events } = await Online.poll(Game.state.onlineGameId, Game.state.onlinePlayerId, lastEventId);
        reportPollSuccess();
        for (const ev of events) {
          lastEventId = Math.max(lastEventId, ev.id);
          if (ev.type === 'game_started') {
            stopOnlinePoll();
            Game.state.onlineGameTurn = ev.turn;
            startOnlineBattle(myIndex);
          }
        }
      } catch (err) {
        reportPollFailure('ожидание расстановки соперника', err);
      }
    }, 3000);
  }

  /**
   * Переход к игровому экрану онлайн-партии. Этап 7.5 подключит сюда
   * реальную логику боя через Online.attack/Online.poll — пока это
   * заглушка, чтобы Этап 7.4 можно было проверить от начала и до
   * этой точки целиком.
   */
  /**
   * Переход к игровому экрану онлайн-партии (Этап 7.5).
   * @param {number} myIndex - 0 или 1, какой из Game.state.players — я
   */
  function startOnlineBattle(myIndex) {
    Game.setPhase('playing');
    Game.state.currentPlayer = (Game.state.onlineGameTurn === Game.state.onlinePlayerId) ? myIndex : 1 - myIndex;

    const adapter = {
      myIndex,
      isMyTurn: () => Game.state.onlineGameTurn === Game.state.onlinePlayerId,
      attack: (x, y) => onlineAttack(myIndex, x, y),
    };

    Board.initGame(onOnlineGameOver, adapter);
    startBattlePoll(myIndex);
  }

  /**
   * Выполнить мой выстрел через сервер и привести ответ к формату,
   * который ожидает board.js (тот же, что у Game.attack() локально:
   * {hit, sunk, shipCoords, gameOver, winner}). Сама board.js логику
   * попадания не считает — здесь только перевод протокола attack.php
   * в формат, понятный остальному коду отрисовки, плюс ручное
   * обновление Game.state (т.к. Game.attack() в онлайне не вызывается —
   * результат знает только сервер).
   */
  async function onlineAttack(myIndex, x, y) {
    const gameId = Game.state.onlineGameId;
    const playerId = Game.state.onlinePlayerId;
    const oppIndex = 1 - myIndex;

    const serverResult = await Online.attack(gameId, playerId, x, y);

    // Обновляем Game.state так же, как это делал бы Game.attack() локально —
    // остальной код (refreshGameAll, buildFleetStatus, журнал ходов) читает
    // именно из state, а не из result.
    Game.state.players[myIndex].shotsFired.push({ x, y, hit: serverResult.hit, sunk: serverResult.sunk, shipCells: serverResult.sunk ? serverResult.shipCells : null });
    Game.state.players[oppIndex].shotsReceived.push({ x, y, hit: serverResult.hit });

    if (serverResult.gameOver) {
      stopOnlinePoll(); // остановить поллинг немедленно, чтобы событие game_over из poll не затёрло winner
      Game.state.phase = 'finished';
      Game.state.winner = myIndex;
      // opponentShips — раскрытый флот соперника для экрана результата.
      Game.state.players[oppIndex].ships = serverResult.opponentShips;
    } else {
      Game.state.onlineGameTurn = serverResult.nextTurn;
      Game.state.currentPlayer = (serverResult.nextTurn === playerId) ? myIndex : oppIndex;
    }

    return {
      hit: serverResult.hit,
      sunk: serverResult.sunk,
      shipCoords: serverResult.sunk ? serverResult.shipCells : null,
      gameOver: !!serverResult.gameOver,
      winner: serverResult.gameOver ? myIndex : null,
    };
  }

  /**
   * Поллинг во время боя (1500мс — короче, чем в lobby/placing, бой
   * требует более оперативного отклика на ход соперника). Слушает
   * enemy_attack (ход соперника по моему полю — проигрывается через
   * Board.applyIncomingAttack на МОЁМ поле) и game_over (если
   * соперник сделал победный выстрел).
   */
  function startBattlePoll(myIndex) {
    const oppIndex = 1 - myIndex;
    let lastEventId = 0;
    onlinePollTimer = setInterval(async () => {
      try {
        const { events } = await Online.poll(Game.state.onlineGameId, Game.state.onlinePlayerId, lastEventId);
        reportPollSuccess();
        for (const ev of events) {
          lastEventId = Math.max(lastEventId, ev.id);

          if (ev.type === 'enemy_attack') {
            Game.state.players[oppIndex].shotsFired.push({ x: ev.x, y: ev.y, hit: ev.hit, sunk: ev.sunk, shipCells: ev.sunk ? ev.shipCells : null });
            Game.state.players[myIndex].shotsReceived.push({ x: ev.x, y: ev.y, hit: ev.hit });
            if (!ev.hit) {
              Game.state.onlineGameTurn = Game.state.onlinePlayerId;
              Game.state.currentPlayer = myIndex;
            } else {
              Game.state.currentPlayer = oppIndex;
            }
            Board.applyIncomingAttack(ev.x, ev.y, {
              hit: ev.hit,
              sunk: ev.sunk,
              gameOver: false,
              winner: null,
            });
          }

          if (ev.type === 'game_over') {
            stopOnlinePoll();
            Game.state.phase = 'finished';
            Game.state.winner = oppIndex; // событие game_over от соперника значит он победил
            Game.state.players[oppIndex].ships = ev.opponentShips; // флот победителя (соперника), раскрытый мне для экрана результата
            UI.showToast('💥 Соперник потопил весь ваш флот!', 2500);
            setTimeout(() => onOnlineGameOver({ gameOver: true, winner: oppIndex }), 1500);
          }
        }
      } catch (err) {
        reportPollFailure('бой', err);
      }
    }, 1500);
  }

  function onOnlineGameOver(result) {
    stopOnlinePoll();
    Game.setPhase('finished');
    Board.initOver(
      () => { UI.showToast('Повторная партия онлайн пока не реализована — вернитесь в лобби', 3000); },
      () => { Game.setPhase('lobby'); Lobby.init(onStart); }
    );
  }

  function describeError(err) {
    const known = {
      network_error: 'нет соединения с сервером',
      server_error: 'ошибка на сервере',
      game_not_found: 'игра не найдена',
      game_full: 'в этой игре уже два игрока',
      game_not_joinable: 'к этой игре нельзя подключиться',
      server_busy: 'сейчас уже идёт другая игра, попробуйте позже',
    };
    return known[err.code] || err.message || 'неизвестная ошибка';
  }

  return { init };

})();
