'use strict';
/* ════════════════════════════════════════════════════════
   tools/ai_simulate.js — прогон N партий между двумя ИИ-стратегиями
   (бот против бота, вне DOM), используя НЕ переписанную, а буквально
   оригинальную логику из game/js/ai.js (подмена window/Game перед
   загрузкой кода через new Function).

   Запуск (из корня проекта):
     node tools/ai_simulate.js [N] [aiPathA] [aiPathB] [strategyA] [strategyB]

   По умолчанию: 200 партий, easy vs mid, оба используют
   game/js/ai.js. Полезно после любого изменения ai.js — сравнить
   "до/после" подменой второго аргумента на временную копию старого
   файла, как это делалось при разработке этапа 9.3.1 (см. HANDOFF.md).
   ════════════════════════════════════════════════════════ */

const fs = require('fs');
const path = require('path');

const SHIP_TYPES = [
  { name: 'Линкор',  size: 4, ids: [0] },
  { name: 'Крейсер', size: 3, ids: [1, 2] },
  { name: 'Эсминец', size: 2, ids: [3, 4, 5] },
  { name: 'Катер',   size: 1, ids: [6, 7, 8, 9] },
];
const SHIP_LIST = [];
SHIP_TYPES.forEach(g => g.ids.forEach(id => SHIP_LIST.push({ id, name: g.name, size: g.size })));

/**
 * Загружает ai.js в изолированном контексте с минимальным мок-окружением
 * (window.Game.SHIP_TYPES) и возвращает window.AI этого контекста.
 * Каждый бот получает СВОЙ экземпляр модуля (своё внутреннее состояние),
 * т.к. ai.js хранит state в closure модуля, а не в параметрах.
 */
function loadAIModule(aiFilePath) {
  const code = fs.readFileSync(aiFilePath, 'utf8');
  const sandboxWindow = { Game: { SHIP_TYPES } };
  const fn = new Function('window', code + '\nreturn window.AI;');
  return fn(sandboxWindow);
}

// ── Генерация случайной валидной расстановки (как autoPlaceShips в lobby.js) ──
function randomPlacement() {
  const board = Array.from({ length: 10 }, () => Array(10).fill(0));
  const placed = [];

  function coords4(c, r, size, d) {
    const res = [];
    for (let i = 0; i < size; i++) res.push(d === 'H' ? [c + i, r] : [c, r + i]);
    return res;
  }
  function canPlace(coords) {
    return coords.every(([c, r]) => c >= 0 && c < 10 && r >= 0 && r < 10 && board[r][c] === 0) &&
      coords.every(([c, r]) => {
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          if (!dr && !dc) continue;
          const nc = c + dc, nr = r + dr;
          if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && board[nr][nc] === 1) return false;
        }
        return true;
      });
  }

  SHIP_LIST.forEach(ship => {
    let ok = false;
    for (let i = 0; i < 500 && !ok; i++) {
      const d = Math.random() < 0.5 ? 'H' : 'V';
      const c = Math.floor(Math.random() * 10);
      const r = Math.floor(Math.random() * 10);
      const cs = coords4(c, r, ship.size, d);
      if (canPlace(cs)) {
        cs.forEach(([cc, rc]) => { board[rc][cc] = 1; });
        placed.push({ id: ship.id, name: ship.name, size: ship.size, coords: cs, dir: d });
        ok = true;
      }
    }
    if (!ok) throw new Error('Не удалось разместить корабль — повторим партию');
  });

  return placed; // [{id, name, size, coords:[[x,y],...], dir}]
}

/** Индекс клетки -> id корабля, которому она принадлежит (для поля одного игрока) */
function buildCellOwnerMap(ships) {
  const map = new Map(); // 'x,y' -> shipId
  ships.forEach(ship => {
    ship.coords.forEach(([x, y]) => map.set(x + ',' + y, ship.id));
  });
  return map;
}

/**
 * Выполняет выстрел по полю защищающегося игрока.
 * Возвращает { hit, sunk, shipCoords } — тот же контракт, что Game.attack().
 */
function makeAttackResolver(ships) {
  const cellOwner = buildCellOwnerMap(ships);
  const shipById = new Map(ships.map(s => [s.id, s]));
  const hitsById = new Map(ships.map(s => [s.id, new Set()]));

  return function attack(x, y) {
    const key = x + ',' + y;
    const shipId = cellOwner.get(key);
    if (shipId === undefined) {
      return { hit: false, sunk: false, shipCoords: null };
    }
    const hitsSet = hitsById.get(shipId);
    hitsSet.add(key);
    const ship = shipById.get(shipId);
    const sunk = hitsSet.size === ship.size;
    return {
      hit: true,
      sunk,
      shipCoords: sunk ? ship.coords : null, // [[cx,cy], ...] — как в Game.attack()
    };
  };
}

/**
 * Считает все клетки кораблей игрока (для проверки победы).
 */
function totalShipCells() {
  return SHIP_LIST.reduce((sum, s) => sum + s.size, 0); // 20
}

/**
 * Сыграть одну партию между ботом A (стратегия strategyA) и ботом B (strategyB).
 * Оба бота используют СВОЙ инстанс ai.js модуля (передаётся снаружи как фабрика),
 * чтобы избежать общего состояния (замыкания) между играми/ботами.
 * Правило хода: бот продолжает стрелять, пока попадает (как в lobby.js).
 * @returns {{winner: 'A'|'B', shotsA: number, shotsB: number, totalShots: number}}
 */
function playGame(aiModuleFactoryA, strategyA, aiModuleFactoryB, strategyB, firstMover) {
  const shipsA = randomPlacement(); // поле, которое атакует бот B
  const shipsB = randomPlacement(); // поле, которое атакует бот A

  const attackOnA = makeAttackResolver(shipsA);
  const attackOnB = makeAttackResolver(shipsB);

  const aiA = aiModuleFactoryA();
  const aiB = aiModuleFactoryB();
  aiA.reset();
  aiB.reset();

  const totalCells = totalShipCells();
  let sunkCellsOnA = 0; // сколько клеток кораблей A уже поражено (B атакует A)
  let sunkCellsOnB = 0;

  let shotsA = 0; // выстрелов сделал бот A (атакует поле B)
  let shotsB = 0; // выстрелов сделал бот B (атакует поле A)

  // Защита от теоретического зацикливания
  const MAX_SHOTS = 100000;
  let guard = 0;

  // Кто ходит первым — параметр (чтобы исключить системное преимущество)
  let current = firstMover === 'B' ? 'B' : 'A';

  while (true) {
    guard++;
    if (guard > MAX_SHOTS) {
      throw new Error('Превышен лимит выстрелов — подозрение на зацикливание');
    }

    if (current === 'A') {
      const move = aiA.makeMove(strategyA);
      if (!move) throw new Error('AI A вернул null ход');
      shotsA++;
      const result = attackOnB(move.x, move.y);
      aiA.registerResult(move.x, move.y, result);
      if (result.hit) sunkCellsOnB++;

      if (sunkCellsOnB === totalCells) {
        return { winner: 'A', shotsA, shotsB, totalShots: shotsA + shotsB };
      }
      if (!result.hit) current = 'B'; // промах — переход хода
      // попадание — A снова стреляет (current остаётся 'A')
    } else {
      const move = aiB.makeMove(strategyB);
      if (!move) throw new Error('AI B вернул null ход');
      shotsB++;
      const result = attackOnA(move.x, move.y);
      aiB.registerResult(move.x, move.y, result);
      if (result.hit) sunkCellsOnA++;

      if (sunkCellsOnA === totalCells) {
        return { winner: 'B', shotsA, shotsB, totalShots: shotsA + shotsB };
      }
      if (!result.hit) current = 'A';
    }
  }
}

/**
 * Прогнать N партий strategyA (используя aiPathA) vs strategyB (aiPathB).
 */
function runSeries(aiPathA, strategyA, aiPathB, strategyB, n) {
  const factoryA = () => loadAIModule(aiPathA);
  const factoryB = () => loadAIModule(aiPathB);

  let winsA = 0, winsB = 0;
  const allTotalShots = [];
  // "Собственная скорость" — сколько выстрелов сделал именно этот бот,
  // чтобы потопить ВЕСЬ вражеский флот (20 клеток), независимо от того,
  // кто в итоге победил по очереди ходов. Это честная метрика силы
  // алгоритма поиска, не зависящая от того, кто стрелял первым.
  const ownShotsToClearA = []; // shotsA в каждой партии (всегда считаем, не только при победе)
  const ownShotsToClearB = [];

  for (let i = 0; i < n; i++) {
    const firstMover = i % 2 === 0 ? 'A' : 'B'; // чередуем, чтобы не было системного перекоса
    const res = playGame(factoryA, strategyA, factoryB, strategyB, firstMover);
    allTotalShots.push(res.totalShots);
    ownShotsToClearA.push(res.shotsA);
    ownShotsToClearB.push(res.shotsB);
    if (res.winner === 'A') winsA++; else winsB++;
  }

  const avg = arr => arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : NaN;
  const median = arr => {
    if (!arr.length) return NaN;
    const s = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(s.length / 2);
    return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
  };
  const stddev = arr => {
    const m = avg(arr);
    return Math.sqrt(avg(arr.map(v => (v - m) ** 2)));
  };

  return {
    n, winsA, winsB,
    winRateA: winsA / n,
    winRateB: winsB / n,
    avgTotalShots: avg(allTotalShots),
    medianTotalShots: median(allTotalShots),
    // Сколько в среднем нужно выстрелов САМОМУ боту, чтобы зачистить чужой флот
    // (чем меньше — тем эффективнее алгоритм поиска целей)
    avgOwnShotsToClearA: avg(ownShotsToClearA),
    avgOwnShotsToClearB: avg(ownShotsToClearB),
    medianOwnShotsToClearA: median(ownShotsToClearA),
    medianOwnShotsToClearB: median(ownShotsToClearB),
    stddevOwnShotsToClearA: stddev(ownShotsToClearA),
    stddevOwnShotsToClearB: stddev(ownShotsToClearB),
  };
}

module.exports = { runSeries, loadAIModule, playGame };

// ── Запуск напрямую как скрипт ──
if (require.main === module) {
  const N = parseInt(process.argv[2] || '200', 10);
  const defaultAiPath = path.join(__dirname, '..', 'game', 'js', 'ai.js');
  const aiPathA = process.argv[3] ? path.resolve(process.argv[3]) : defaultAiPath;
  const aiPathB = process.argv[4] ? path.resolve(process.argv[4]) : aiPathA;
  const stratA = process.argv[5] || 'easy';
  const stratB = process.argv[6] || 'mid';

  console.log(`Симуляция: ${stratA} (${path.basename(aiPathA)}) vs ${stratB} (${path.basename(aiPathB)}), ${N} партий\n`);
  const result = runSeries(aiPathA, stratA, aiPathB, stratB, N);
  console.log(JSON.stringify(result, null, 2));
}
