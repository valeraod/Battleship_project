<?php
/**
 * poll.php — отдаёт игроку новые события, накопленные с момента lastEventId.
 * Клиент опрашивает этот эндпоинт по таймеру (poll.js, Этап 7):
 * 3000 мс в фазах LOBBY/PLACING, 1500 мс в фазе PLAYING.
 *
 * GET api/poll.php?gameId=abc123&playerId=p1&lastEventId=0
 * Ответ: { "events": [ { "id": 5, "type": "enemy_attack", "x": 7, "y": 1, "hit": false }, ... ] }
 *
 * Каждое событие в ответе разворачивает payload прямо в объект события
 * (а не как вложенное поле) — события в одном плоском формате для клиента.
 *
 * Побочный эффект 1: обновляет players.last_seen для playerId.
 * Побочный эффект 2 (Этап 8.4 / П.3 из review_v25.md): если СОПЕРНИК не
 * выходил на связь дольше OPPONENT_TIMEOUT_SECONDS, игра завершается
 * автоматически — текущий игрок (тот, кто сейчас опрашивает) объявляется
 * победителем, генерируются game_over события для обоих (формат как в
 * attack.php — winner + opponentShips). Без этого второй игрок навсегда
 * зависал в поллинге, если первый закрыл вкладку без abandon.php.
 */

require __DIR__ . '/db.php';

header('Content-Type: application/json; charset=utf-8');

// Если соперник не присылал ни одного poll/attack дольше этого времени,
// считаем его отключившимся и завершаем игру автоматически. 5 минут —
// решение пользователя; клиент опрашивает каждые 1.5-3 сек, так что
// реальная задержка обнаружения намного меньше потенциального тайм-аута.
const OPPONENT_TIMEOUT_SECONDS = 300;

function respond_error(string $code, int $httpStatus): void {
    http_response_code($httpStatus);
    echo json_encode(['error' => $code]);
    exit;
}

$gameId       = trim((string)($_GET['gameId'] ?? ''));
$playerId     = trim((string)($_GET['playerId'] ?? ''));
$lastEventId  = (int)($_GET['lastEventId'] ?? 0);

if ($gameId === '' || $playerId === '') {
    respond_error('invalid_request', 400);
}

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare('SELECT id FROM players WHERE id = ? AND game_id = ?');
    $stmt->execute([$playerId, $gameId]);
    if (!$stmt->fetch()) {
        $pdo->rollBack();
        respond_error('player_not_found', 404);
    }

    $pdo->prepare('UPDATE players SET last_seen = NOW() WHERE id = ?')
        ->execute([$playerId]);

    // ── Этап 8.4 / П.3: обнаружение отключившегося соперника ──
    // Только для игр, которые ещё идут (waiting/placing/playing) и где
    // у соперника уже было хотя бы одно подключение (last_seen не NULL
    // по умолчанию в схеме — DEFAULT CURRENT_TIMESTAMP, так что всегда
    // заполнено с момента INSERT, проверка тут просто для надёжности).
    $stmt = $pdo->prepare(
        "SELECT g.status, p.id AS opponent_id, p.ships AS opponent_ships,
                TIMESTAMPDIFF(SECOND, p.last_seen, NOW()) AS idle_seconds
         FROM games g
         JOIN players p ON p.game_id = g.id AND p.id != ?
         WHERE g.id = ?"
    );
    $stmt->execute([$playerId, $gameId]);
    $opponent = $stmt->fetch();

    if ($opponent && $opponent['status'] !== 'finished'
        && $opponent['idle_seconds'] !== null
        && $opponent['idle_seconds'] >= OPPONENT_TIMEOUT_SECONDS) {

        $pdo->prepare("UPDATE games SET status = 'finished', turn = NULL WHERE id = ?")
            ->execute([$gameId]);

        // Свой флот для опциального opponentShips соперника — берём ships
        // текущего игрока (то, что должен увидеть отключившийся соперник,
        // если когда-нибудь вернётся и допросит poll — на практике он уже
        // не получит это событие, для него игра просто кончилась молча,
        // но событие создаём для консистентности данных в events).
        $stmt = $pdo->prepare('SELECT ships FROM players WHERE id = ?');
        $stmt->execute([$playerId]);
        $myShips = $stmt->fetch()['ships'] ?? null;
        $myShips = $myShips ? (json_decode($myShips, true) ?: []) : [];
        $opponentShips = $opponent['opponent_ships'] ? (json_decode($opponent['opponent_ships'], true) ?: []) : [];

        $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
            ->execute([$gameId, $playerId, 'game_over', json_encode([
                'winner' => $playerId,
                'reason' => 'opponent_timeout',
                'opponentShips' => $opponentShips,
            ])]);
        $pdo->prepare('INSERT INTO events (game_id, for_player, type, payload) VALUES (?, ?, ?, ?)')
            ->execute([$gameId, $opponent['opponent_id'], 'game_over', json_encode([
                'winner' => $playerId,
                'reason' => 'opponent_timeout',
                'opponentShips' => $myShips,
            ])]);
    }

    $stmt = $pdo->prepare(
        'SELECT id, type, payload FROM events
         WHERE game_id = ? AND for_player = ? AND id > ?
         ORDER BY id ASC'
    );
    $stmt->execute([$gameId, $playerId, $lastEventId]);
    $rows = $stmt->fetchAll();

    $events = array_map(function ($row) {
        $event = [
            'id'   => (int)$row['id'],
            'type' => $row['type'],
        ];
        $payload = $row['payload'] ? json_decode($row['payload'], true) : [];
        if (is_array($payload)) {
            $event = array_merge($event, $payload);
        }
        return $event;
    }, $rows);

    $pdo->commit();

    echo json_encode(['events' => $events]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('poll.php error: ' . $e->getMessage());
    respond_error('server_error', 500);
}
