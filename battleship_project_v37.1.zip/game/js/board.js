/* ════════════════════════════════════════════════════════
   board.js — сервис: отрисовка полей и расстановка кораблей
   Этап 2: интерактивная расстановка на сетке 10×10.
   Логика отрисовки боя (renderGameBoards) добавится на Этапе 3.

   Расстановка (этап 2, версия 2 — drag + выделение + поворот кнопкой):
   - Установка нового корабля: клик по кораблю в списке → клик/тап по полю.
   - Выделение: клик/тап по уже стоящему кораблю на поле (просто подсветка,
     ничего больше).
   - Перемещение: зажать стоящий корабль и перетащить (drag) в новое место —
     мышью или тапом-и-удержанием на тач-устройствах.
   - Поворот: кнопка «⟳ Повернуть», активна только при выделенном корабле.
     Сначала пробует повернуть корабль НА МЕСТЕ (вокруг его первой клетки).
     Если место не позволяет — корабль "поднимается" с поля (становится
     "плавающим", floatingId) уже в НОВОЙ ориентации, и пользователь сам
     кликает/тащит его на новое место. Так решается классический кейс
     "повернуть здесь нельзя, а где хочется поставить — нельзя в старой
     ориентации": поворот и перемещение не требуют валидности друг через
     друга по отдельности, проверяется только финальный результат
     (клетка + ориентация) в момент размещения/отпускания.
   - Esc отменяет любое "подвешенное" состояние (новый из списка — просто
     не размещается; поднятый с поля — возвращается на исходное место и
     исходную ориентацию).
   ════════════════════════════════════════════════════════ */

window.Board = (() => {

  const COLS = 'АБВГДЕЖЗИК'.split('');
  const SHIP_LIST = Game.SHIP_LIST;
  const SHIP_TYPES = Game.SHIP_TYPES;

  // ── Локальное рабочее состояние текущей расстановки ──
  // (своё для каждого вызова initPlacing — два игрока расставляют
  // корабли по очереди на одном и том же экране)
  let board = [];          // 10×10: 0=пусто, 1=корабль, 2=мёртвая зона
  let placed = {};          // id -> {coords, dir} — то, что реально стоит на поле

  let selectedId = null;    // id корабля, выделенного на поле (просто подсветка)

  // "Плавающий" корабль — тот, что сейчас не привязан к полю и ждёт, куда
  // его поставят: новый из списка (floatingOrigin = null) ИЛИ снятый с поля
  // через drag/неудачный поворот (floatingOrigin = его прежние coords/dir,
  // чтобы было куда откатиться при отмене/неудачном размещении).
  let floatingId = null;
  let floatingDir = 'H';
  let floatingOrigin = null;

  let hover = null;         // [c, r] — клетка под курсором/пальцем, для превью
  let cells = [];

  let currentPlayerIndex = 0;
  let onAllPlaced = null;   // callback() — оба игрока расставили корабли (локальный режим)
  let onReady = null;       // callback(ships) — для онлайн/ИИ-режима, см. Этап 7.4/9.2

  // ── Drag-перемещение уже стоящего корабля ──
  const DRAG_THRESHOLD_PX = 4; // меньше — это клик/тап (выделение), больше — перетаскивание
  let dragState = null;        // {id, startX, startY, moved}

  // ── Публичный запуск расстановки для игрока ──
  // @param {Function} [onReadyCallback] - см. оригинальный комментарий ниже
  //   (Этап 7.4): используется онлайн- и ИИ-режимом вместо стандартного
  //   локального поведения "переключить на игрока 1 / вызвать onAllPlaced".
  function initPlacing(playerIndex, doneCallback, onReadyCallback) {
    currentPlayerIndex = playerIndex;
    onAllPlaced = doneCallback;
    onReady = onReadyCallback || null;

    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {};
    selectedId = null;
    floatingId = null;
    floatingDir = 'H';
    floatingOrigin = null;
    hover = null;
    dragState = null;

    renderShell();
    buildGrid();
    buildShipGroups();
    refreshActionButtons();
    updateProgress();
    updateHint();

    // Контекстная панель (⟳/✕ у выделенного корабля, мобайл) должна
    // пересчитывать позицию при скролле (в т.ч. внутри .grid-scroll) и
    // изменении размера окна. Слушатели — на одной и той же функции
    // (positionContextPanel), поэтому remove+add безопасны при повторном
    // вызове initPlacing (второй игрок, "Играть снова") — не копятся дубли.
    window.removeEventListener('scroll', positionContextPanel, true);
    window.removeEventListener('resize', positionContextPanel);
    window.addEventListener('scroll', positionContextPanel, true);
    window.addEventListener('resize', positionContextPanel);

    const player = Game.state.players[playerIndex];
    document.getElementById('placing-player-chip').textContent = '⚓ ' + (player.name || ('Игрок ' + (playerIndex + 1)));
  }

  // ── Разметка экрана (создаётся один раз за вызов initPlacing) ──
  function renderShell() {
    const root = document.getElementById('screen-placing');
    root.innerHTML = `
      <div class="container py-3 px-3" style="max-width:760px">
        <div class="card shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <div class="fw-semibold" style="font-size:13px;color:#000000">Расставьте корабли на поле</div>
              <div class="d-flex align-items-center gap-2">
                <div class="prog-wrap" style="width:80px"><div class="prog-bar" id="pb" style="width:0%"></div></div>
                <span style="font-size:11px;color:#000;white-space:nowrap" id="pl">0 / ${SHIP_LIST.length}</span>
              </div>
            </div>
            <div class="d-flex flex-column flex-sm-row gap-4 align-items-start">
              <div class="grid-scroll flex-shrink-0">
                <div class="col-labels" id="col-lbl"></div>
                <div id="grid"></div>
              </div>
              <div class="flex-grow-1" style="min-width:180px">
                <div style="font-size:11px;font-weight:600;color:#000000;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Корабли</div>
                <div id="ship-groups"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="card shadow-sm">
          <div class="card-body p-3">
            <div class="d-flex flex-wrap align-items-center gap-2">
              <div class="hint-box flex-grow-1" id="hint" style="min-width:140px"></div>
              <button class="btn btn-act" id="btn-rotate">⟳ Повернуть</button>
              <button class="btn btn-act" id="btn-del">✕ Удалить</button>
              <button class="btn btn-act" id="btn-auto">⚡ Авторасстановка</button>
              <button class="btn btn-act" id="btn-reset">↺ Сбросить</button>
              <button class="btn btn-primary" id="btn-ready" disabled>✓ Готово</button>
            </div>
          </div>
        </div>
      </div>
      <div class="ship-context-panel" id="ship-context-panel" style="display:none">
        <button class="ship-context-btn" id="ctx-rotate" title="Повернуть" aria-label="Повернуть">⟳</button>
        <button class="ship-context-btn ship-context-btn-danger" id="ctx-del" title="Удалить" aria-label="Удалить">✕</button>
      </div>`;

    document.getElementById('btn-del').addEventListener('click', deleteSelected);
    document.getElementById('btn-rotate').addEventListener('click', onRotateClick);
    document.getElementById('btn-auto').addEventListener('click', autoPlace);
    document.getElementById('btn-reset').addEventListener('click', resetAll);
    document.getElementById('btn-ready').addEventListener('click', onReadyClick);
    document.getElementById('ctx-rotate').addEventListener('click', onRotateClick);
    document.getElementById('ctx-del').addEventListener('click', deleteSelected);
  }

  // ── Сетка ──
  function buildGrid() {
    const cl = document.getElementById('col-lbl');
    COLS.forEach(c => { const d = document.createElement('div'); d.className = 'col-lbl'; d.textContent = c; cl.appendChild(d); });
    const g = document.getElementById('grid');
    cells = [];
    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      cells[r] = [];
      for (let c = 0; c < 10; c++) {
        const cell = document.createElement('div'); cell.className = 'cell';
        cell.dataset.x = c; cell.dataset.y = r;
        cell.addEventListener('mouseenter', () => { hover = [c, r]; redrawPreview(); });
        cell.addEventListener('mouseleave', () => { if (!dragState || !dragState.moved) { hover = null; drawBoard(); } });
        // Расстановка теперь полностью на pointer-событиях (mouse + touch
        // одним кодом): pointerdown решает, выделение это или начало drag,
        // pointerup — клик-разместить / зафиксировать перетаскивание.
        cell.addEventListener('pointerdown', e => onCellPointerDown(c, r, e));
        cells[r][c] = cell; row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  function drawBoard() {
    for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) {
      const v = board[r][c];
      if (v === 1) cells[r][c].className = cellBelongsTo(c, r, selectedId) ? 'cell ship-sel' : 'cell ship';
      else if (v === 2) cells[r][c].className = 'cell deadzone';
      else cells[r][c].className = 'cell';
    }
  }

  function redrawPreview() {
    drawBoard();
    if (floatingId === null || !hover) return;
    const [hc, hr] = hover;
    const ship = SHIP_LIST.find(s => s.id === floatingId);
    const co = coords4(hc, hr, ship.size, floatingDir);
    const ok = canPlace(co, null);
    co.forEach(([cc, rc]) => {
      if (rc >= 0 && rc < 10 && cc >= 0 && cc < 10)
        cells[rc][cc].className = 'cell ' + (ok ? 'preview' : 'preview-bad');
    });
  }

  // ── Координаты и проверки ──
  function coords4(c, r, size, d) {
    const res = []; for (let i = 0; i < size; i++) res.push(d === 'H' ? [c + i, r] : [c, r + i]); return res;
  }

  function nbrs(coords) {
    const set = new Set(coords.map(([c, r]) => c + ',' + r)); const res = [];
    coords.forEach(([c, r]) => { for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const nc = c + dc, nr = r + dr;
      if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && !set.has(nc + ',' + nr)) res.push([nc, nr]);
    }}); return res;
  }

  // Полностью пересобрать board из placed{} — проще и надёжнее точечных
  // правок матрицы, т.к. placed{} остаётся единственным источником правды.
  function rebuildBoard() {
    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    Object.values(placed).forEach(({ coords }) => {
      coords.forEach(([c, r]) => { board[r][c] = 1; });
    });
    Object.values(placed).forEach(({ coords }) => {
      nbrs(coords).forEach(([c, r]) => { if (board[r][c] === 0) board[r][c] = 2; });
    });
  }

  // Поле board, как если бы корабля ignoreId на нём не было — для проверки
  // "влезает ли корабль сюда", когда сам корабль ещё временно числится
  // в placed (например, при проверке поворота на месте).
  function boardExcluding(ignoreId) {
    const b = Array.from({ length: 10 }, () => Array(10).fill(0));
    Object.entries(placed).forEach(([sid, { coords }]) => {
      if (parseInt(sid) === ignoreId) return;
      coords.forEach(([c, r]) => { b[r][c] = 1; });
    });
    Object.entries(placed).forEach(([sid, { coords }]) => {
      if (parseInt(sid) === ignoreId) return;
      nbrs(coords).forEach(([c, r]) => { if (b[r][c] === 0) b[r][c] = 2; });
    });
    return b;
  }

  /**
   * Можно ли поставить корабль в клетки coords?
   * @param {Array} coords
   * @param {number|null} ignoreId - исключить этот корабль из проверки
   *   (он либо уже снят с поля — тогда обычно передают null, т.к. board
   *   и так не содержит его, либо ещё стоит на месте — тогда передают
   *   его id, чтобы не считать самого себя препятствием).
   */
  function canPlace(coords, ignoreId) {
    const b = (ignoreId !== null && ignoreId !== undefined) ? boardExcluding(ignoreId) : board;
    return coords.every(([c, r]) => c >= 0 && c < 10 && r >= 0 && r < 10 && b[r][c] === 0) &&
      coords.every(([c, r]) => {
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          if (!dr && !dc) continue;
          const nc = c + dc, nr = r + dr;
          if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && b[nr][nc] === 1) return false;
        } return true;
      });
  }

  function cellBelongsTo(c, r, id) {
    if (id === null || !placed[id]) return false;
    return placed[id].coords.some(([cc, rc]) => cc === c && rc === r);
  }

  function shipIdAt(c, r) {
    for (const [sid, { coords }] of Object.entries(placed))
      if (coords.some(([cc, rc]) => cc === c && rc === r)) return parseInt(sid);
    return null;
  }

  /**
   * Поставить плавающий корабль (floatingId) в клетку (c, r) с его
   * текущей ориентацией (floatingDir), если место позволяет.
   * @returns {boolean} удалось ли разместить
   */
  function attemptPlaceFloating(c, r) {
    if (floatingId === null) return false;
    const ship = SHIP_LIST.find(s => s.id === floatingId);
    const co = coords4(c, r, ship.size, floatingDir);
    if (!canPlace(co, null)) return false;

    placed[floatingId] = { coords: co, dir: floatingDir };
    floatingId = null;
    floatingOrigin = null;
    floatingDir = 'H';
    selectedId = null;

    rebuildBoard();
    refreshGroupUI(); refreshActionButtons(); drawBoard(); updateProgress(); updateHint();
    return true;
  }

  /**
   * Отменить текущее "подвешенное" состояние: если корабль был снят с
   * поля (floatingOrigin задан) — вернуть его обратно как было; если
   * это был новый корабль из списка (floatingOrigin === null) — просто
   * убрать выбор, на поле он не появлялся.
   */
  function cancelFloating() {
    if (floatingId !== null && floatingOrigin !== null) {
      placed[floatingId] = { coords: floatingOrigin.coords, dir: floatingOrigin.dir };
    }
    floatingId = null;
    floatingOrigin = null;
    floatingDir = 'H';
    rebuildBoard();
  }

  // ── Pointer down по клетке поля: решает, что это — выделение/клик-
  //    размещение/начало перетаскивания, единым кодом для мыши и тача ──
  function onCellPointerDown(c, r, e) {
    if (floatingId !== null) {
      // Корабль уже "в руке" (из списка, либо поднят поворотом) —
      // клик/тап по полю пытается его поставить именно сюда.
      attemptPlaceFloating(c, r);
      return;
    }

    const sid = shipIdAt(c, r);
    if (sid === null) {
      // Клик по воде без поднятого корабля — просто снять выделение.
      if (selectedId !== null) {
        selectedId = null;
        refreshActionButtons(); drawBoard(); updateHint();
      }
      return;
    }

    // Нажатие на стоящий корабль — пока не известно, клик это (выделить)
    // или начало перетаскивания: решается в onCellPointerMove по порогу
    // сдвига курсора/пальца.
    dragState = {
      id: sid,
      startX: e.clientX,
      startY: e.clientY,
      moved: false,
    };
    document.addEventListener('pointermove', onCellPointerMove);
    document.addEventListener('pointerup', onCellPointerUp, { once: true });
  }

  /**
   * Клетка под пальцем/курсором на мобиле физически закрыта самим пальцем.
   * Поэтому во время drag целевая клетка вычисляется не по тому, что
   * реально под указателем (elementFromPoint), а смещённой на 1 клетку
   * вверх-влево от него — так превью корабля не перекрывается пальцем.
   * Это смещение — не косметика поверх старой логики, а сама логика:
   * видимое (смещённое) превью и есть то место, куда встанет корабль.
   * Чтобы дотянуться до последней строки/столбца поля, палец должен
   * оказаться на 1 клетку правее/ниже физической границы сетки — расчёт
   * ведётся чистой арифметикой по координатам, поэтому это работает,
   * даже когда палец уже вне DOM-элементов сетки. Обрезка в границы
   * 0..9 происходит в самом конце, только чтобы не выйти за пределы
   * массива cells[][] при отрисовке — она не мешает достать до края.
   */
  function offsetCellFromPointer(clientX, clientY) {
    const ref = cells[0][0].getBoundingClientRect();
    const cellW = ref.width;
    const cellH = ref.height;

    const rawCol = Math.floor((clientX - ref.left) / cellW);
    const rawRow = Math.floor((clientY - ref.top) / cellH);

    let c = rawCol - 1;
    let r = rawRow - 1;

    c = Math.max(0, Math.min(9, c));
    r = Math.max(0, Math.min(9, r));

    return [c, r];
  }

  function onCellPointerMove(e) {
    if (!dragState) return;
    const dx = e.clientX - dragState.startX;
    const dy = e.clientY - dragState.startY;

    if (!dragState.moved) {
      if (Math.hypot(dx, dy) < DRAG_THRESHOLD_PX) return;
      // Порог пройден — это перетаскивание: снимаем корабль с поля и
      // переводим его в "плавающее" состояние с прежней ориентацией.
      dragState.moved = true;
      const ship = placed[dragState.id];
      floatingOrigin = { coords: ship.coords, dir: ship.dir };
      floatingDir = ship.dir;
      floatingId = dragState.id;
      selectedId = null;
      delete placed[dragState.id];
      rebuildBoard();
      refreshGroupUI(); refreshActionButtons();
    }

    hover = offsetCellFromPointer(e.clientX, e.clientY);
    redrawPreview();
  }

  function onCellPointerUp(e) {
    document.removeEventListener('pointermove', onCellPointerMove);
    if (!dragState) return;

    if (!dragState.moved) {
      // Сдвига не было — это просто клик/тап: выделить корабль.
      selectedId = dragState.id;
      dragState = null;
      refreshActionButtons(); drawBoard(); updateHint();
      return;
    }

    // Было перетаскивание — ставим в клетку, смещённую от пальца (см.
    // offsetCellFromPointer) — то же место, что и в превью при движении.
    const [c, r] = offsetCellFromPointer(e.clientX, e.clientY);
    const placedOk = attemptPlaceFloating(c, r);

    if (!placedOk) {
      // Бросили мимо валидного места — возвращаем корабль туда, откуда взяли.
      selectedId = floatingId;
      cancelFloating();
      refreshGroupUI(); refreshActionButtons(); drawBoard(); updateProgress(); updateHint();
    }

    dragState = null;
  }

  // ── Клик по кнопке группы кораблей (взять новый корабль из списка) ──
  function nextFreeId(gIdx) {
    return SHIP_TYPES[gIdx].ids.find(id => placed[id] === undefined) ?? null;
  }

  function onGroupClick(gIdx) {
    // Если в руках уже был поднятый с поля корабль (после неудачного
    // поворота) — выбор нового из списка его отменяет, с откатом на
    // прежнее место, чтобы не потерять корабль молча.
    if (floatingId !== null) cancelFloating();

    const free = nextFreeId(gIdx);
    if (free === null) return;
    floatingId = free;
    floatingDir = 'H';
    floatingOrigin = null;
    selectedId = null;
    refreshGroupUI(); refreshActionButtons(); drawBoard(); redrawPreview(); updateHint();
  }

  function refreshGroupUI() {
    SHIP_TYPES.forEach((g, gIdx) => {
      const remaining = g.ids.filter(id => placed[id] === undefined).length;
      const btn = document.getElementById('grp-btn-' + gIdx);
      const cnt = document.getElementById('grp-cnt-' + gIdx);
      if (!btn || !cnt) return;
      const isSelectedGroup = floatingId !== null && g.ids.includes(floatingId);
      btn.classList.toggle('sel', isSelectedGroup);
      btn.classList.toggle('empty', remaining === 0);
      cnt.textContent = remaining;
      cnt.className = 'ship-counter' + (remaining === 0 ? ' zero' : '');
    });
  }

  // ── Удаление ──
  function deleteSelected() {
    if (selectedId === null) return;
    delete placed[selectedId];
    selectedId = null;
    rebuildBoard();
    refreshGroupUI(); refreshActionButtons(); drawBoard(); updateProgress(); updateHint();
  }

  // ── Поворот выделенного корабля ──
  // Сначала пробуем повернуть на месте (вокруг его первой клетки). Если
  // не влезает — поднимаем корабль с поля уже в новой ориентации и ждём,
  // куда пользователь его поставит (клик или drag) — см. шапку файла.
  function onRotateClick() {
    if (selectedId === null) return;
    const id = selectedId;
    const ship = placed[id];
    const anchor = ship.coords[0];
    const newDir = ship.dir === 'H' ? 'V' : 'H';
    const newCoords = coords4(anchor[0], anchor[1], SHIP_LIST.find(s => s.id === id).size, newDir);

    if (canPlace(newCoords, id)) {
      placed[id] = { coords: newCoords, dir: newDir };
      rebuildBoard();
      drawBoard(); updateHint();
      positionContextPanel(); // геометрия корабля изменилась, панель должна сдвинуться вместе с ним
      return;
    }

    // Не влезает на месте — поднимаем с поля в новой ориентации.
    floatingOrigin = { coords: ship.coords, dir: ship.dir };
    floatingDir = newDir;
    floatingId = id;
    selectedId = null;
    hover = anchor; // чтобы корабль сразу было видно (пусть и красным) там же
    delete placed[id];
    rebuildBoard();

    UI.showToast('Здесь повернуть нельзя — выберите новое место для корабля', 2400);
    refreshGroupUI(); refreshActionButtons(); drawBoard(); redrawPreview(); updateHint();
  }

  function refreshActionButtons() {
    const delBtn = document.getElementById('btn-del');
    const rotBtn = document.getElementById('btn-rotate');
    if (delBtn) delBtn.disabled = selectedId === null;
    if (rotBtn) rotBtn.disabled = selectedId === null;
    positionContextPanel();
  }

  /* ════════════════════════════════════════════════════════
     Контекстная панель действий (⟳ Повернуть / ✕ Удалить) у
     выделенного корабля — показывается на любом экране. Изначально
     была нужна только на мобиле (<768px), чтобы не заставлять
     прокручивать экран до общего ряда кнопок внизу ради каждого
     поворота/удаления. На десктопе она дублирует тот же ряд кнопок
     внизу (он там тоже остаётся) — это сделано намеренно, как
     дополнительный быстрый способ управлять выделенным кораблём
     прямо на месте, без необходимости тянуться взглядом/курсором
     вниз экрана.
     ════════════════════════════════════════════════════════ */

  // Границы (в координатах viewport) всех клеток выделенного корабля.
  function getSelectedShipRect() {
    if (selectedId === null || !placed[selectedId]) return null;
    const rects = placed[selectedId].coords.map(([c, r]) => cells[r][c].getBoundingClientRect());
    return {
      left: Math.min(...rects.map(r => r.left)),
      right: Math.max(...rects.map(r => r.right)),
      top: Math.min(...rects.map(r => r.top)),
      bottom: Math.max(...rects.map(r => r.bottom)),
    };
  }

  function positionContextPanel() {
    const panel = document.getElementById('ship-context-panel');
    if (!panel) return;

    const shipRect = getSelectedShipRect();
    if (!shipRect) { panel.style.display = 'none'; return; }

    panel.style.display = 'flex';
    const panelRect = panel.getBoundingClientRect();
    const margin = 6;

    // По умолчанию — над кораблём; если места сверху не хватает
    // (корабль у верхнего края экрана) — переносим под него.
    let top = shipRect.top - panelRect.height - margin;
    if (top < 8) top = shipRect.bottom + margin;

    let left = shipRect.left + (shipRect.right - shipRect.left) / 2 - panelRect.width / 2;
    left = Math.max(8, Math.min(left, window.innerWidth - panelRect.width - 8));

    panel.style.top = top + 'px';
    panel.style.left = left + 'px';
  }

  // ── Авто / Сброс ──
  function autoPlace() {
    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {};
    selectedId = null; floatingId = null; floatingDir = 'H'; floatingOrigin = null;
    SHIP_LIST.forEach(ship => {
      let ok = false;
      for (let i = 0; i < 500 && !ok; i++) {
        const d = Math.random() < .5 ? 'H' : 'V';
        const c = Math.floor(Math.random() * 10), r = Math.floor(Math.random() * 10);
        const cs = coords4(c, r, ship.size, d);
        if (canPlace(cs, null)) {
          placed[ship.id] = { coords: cs, dir: d }; ok = true;
          // Пересобираем board сразу после каждого размещения, иначе
          // canPlace() на следующей итерации проверяет место против
          // пустого board и не видит корабли, поставленные в этом же
          // запуске autoPlace() — из-за этого они могли налезать друг
          // на друга или вставать вплотную.
          rebuildBoard();
        }
      }
    });
    refreshGroupUI(); refreshActionButtons(); drawBoard(); updateProgress(); updateHint();
  }

  function resetAll() {
    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {};
    selectedId = null; floatingId = null; floatingDir = 'H'; floatingOrigin = null;
    refreshGroupUI(); refreshActionButtons(); drawBoard(); updateProgress(); updateHint();
  }

  // ── Прогресс и подсказка ──
  function updateProgress() {
    const n = Object.keys(placed).length;
    document.getElementById('pb').style.width = (n / SHIP_LIST.length * 100) + '%';
    document.getElementById('pl').textContent = n + ' / ' + SHIP_LIST.length;
    document.getElementById('btn-ready').disabled = n < SHIP_LIST.length;
  }

  function updateHint() {
    const el = document.getElementById('hint');
    const n = Object.keys(placed).length;
    if (floatingId !== null) {
      const s = SHIP_LIST.find(s => s.id === floatingId);
      el.className = 'hint-box hint-blue flex-grow-1';
      el.innerHTML = `<b>${s.name} (${s.size} кл.)</b> — кликните или перетащите на поле, куда поставить`;
      return;
    }
    if (selectedId !== null) {
      el.className = 'hint-box hint-orange flex-grow-1';
      el.innerHTML = `<b>${SHIP_LIST.find(s => s.id === selectedId).name}</b> выделен · зажмите и перетащите для перемещения · «⟳ Повернуть» — развернуть`;
      return;
    }
    if (n === SHIP_LIST.length) {
      el.className = 'hint-box hint-green flex-grow-1';
      el.innerHTML = '<b>Все корабли расставлены!</b> Нажмите «Готово»';
      return;
    }
    el.className = 'hint-box flex-grow-1';
    el.innerHTML = '<b>Выберите корабль</b> из списка · или кликните по стоящему кораблю на поле';
  }

  // ── Список кораблей ──
  function buildShipGroups() {
    const wrap = document.getElementById('ship-groups');
    wrap.innerHTML = '';
    SHIP_TYPES.forEach((g, gIdx) => {
      const row = document.createElement('div'); row.className = 'ship-group-row';

      const btn = document.createElement('div');
      btn.className = 'ship-btn'; btn.id = 'grp-btn-' + gIdx;
      btn.addEventListener('click', () => onGroupClick(gIdx));
      const nm = document.createElement('span'); nm.textContent = g.name;
      const cs = document.createElement('div'); cs.className = 'ship-btn-cells';
      for (let i = 0; i < g.size; i++) { const c = document.createElement('div'); c.className = 'ship-btn-cell'; cs.appendChild(c); }
      btn.appendChild(nm); btn.appendChild(cs);

      const cnt = document.createElement('div');
      cnt.className = 'ship-counter'; cnt.id = 'grp-cnt-' + gIdx;
      cnt.textContent = g.ids.length;

      row.appendChild(btn); row.appendChild(cnt);
      wrap.appendChild(row);
    });
  }

  // ── Завершение расстановки игрока ──
  function onReadyClick() {
    // Преобразовать placed{} в массив для Game.placeShips()
    const ships = SHIP_LIST.map(s => ({
      id: s.id, name: s.name, size: s.size,
      coords: placed[s.id].coords, dir: placed[s.id].dir,
    }));

    if (typeof onReady === 'function') {
      // Онлайн/ИИ-режим (Этап 7.4/9.2): что делать после готовности решает
      // вызывающий код (lobby.js), а не board.js.
      onReady(ships);
      return;
    }

    Game.placeShips(currentPlayerIndex, ships);

    if (currentPlayerIndex === 0) {
      UI.showToast('Корабли расставлены. Очередь игрока 2.');
      initPlacing(1, onAllPlaced);
    } else {
      if (typeof onAllPlaced === 'function') onAllPlaced();
    }
  }

  document.addEventListener('keydown', e => {
    if (document.getElementById('screen-placing')?.classList.contains('d-none')) return;
    if (e.key === 'Escape') {
      cancelFloating();
      selectedId = null;
      refreshGroupUI(); refreshActionButtons(); drawBoard(); updateHint();
    }
  });

  /* ════════════════════════════════════════════════════════
     ИГРОВОЙ ЭКРАН — Этап 3
     Оба игрока играют на одном устройстве без паузы передачи:
     "моё поле" / "поле противника" всегда относится к тому,
     чья сейчас очередь (Game.state.currentPlayer).
     Десктоп-вёрстка переработана: центрированный блок (max-width:920px)
     вместо растяжки на всю ширину + колонка "Флот противника" (только
     для поля врага — свои корабли видны на своём поле и так).
     На мобиле тот же #g-fleet физически переезжает под сетку поля
     врага (внутри вкладки "Поле врага") — см. applyGameTabResponsive().
     ════════════════════════════════════════════════════════ */

  const COLS_GAME = COLS; // те же подписи столбцов А-К
  let gameFiring = false;       // блокировка повторного клика во время анимации
  let gameActiveTab = 'en';      // 'my' | 'en' — активная вкладка на мобиле
  let gameOnOver = null;         // callback(result) при завершении партии
  let gameOnlineAdapter = null;  // онлайн-адаптер (Этап 7.5) — см. JSDoc ниже

  /**
   * @param {Function} onOverCallback - callback(result) при завершении партии
   * @param {object} [onlineAdapter] - если передан, переключает экран в
   *   онлайн-режим (Этап 7.5):
   *   - onlineAdapter.attack(x, y): Promise<result> — заменяет прямой
   *     вызов Game.attack(x, y) на запрос к серверу. Должна вернуть тот
   *     же формат result, что и Game.attack() (hit/sunk/gameOver/...),
   *     и сама обновить Game.state соответствующим образом перед resolve.
   *   - onlineAdapter.isMyTurn(): boolean — можно ли сейчас стрелять
   *     (используется чтобы не показывать "стреляйте" в чужой ход)
   * Если onlineAdapter не передан — поведение полностью локальное,
   * как было до Этапа 7.5 (Game.attack вызывается напрямую и синхронно).
   */
  function initGame(onOverCallback, onlineAdapter) {
    gameOnOver = onOverCallback;
    gameOnlineAdapter = onlineAdapter || null;
    gameFiring = false;
    gameActiveTab = 'en';
    renderGameShell();
    refreshGameAll();
  }

  function renderGameShell() {
    const root = document.getElementById('screen-game');
    root.innerHTML = `
      <div class="container py-3 px-3" style="max-width:920px">

        <div class="card shadow-sm mb-3">
          <div class="card-body py-2 px-3 d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div class="d-flex align-items-center gap-2">
              <span class="chip" id="g-chip-0"></span>
              <span style="font-size:12px;color:#000;font-weight:500">vs</span>
              <span class="chip" id="g-chip-1"></span>
            </div>
            <div id="g-turn-banner" style="font-size:13px;font-weight:700;padding:5px 16px;border-radius:20px;white-space:nowrap"></div>
            <div class="d-flex gap-3">
              <div class="text-center"><div class="stat-val" id="g-shots">0</div><div class="stat-lbl">Выстрелов</div></div>
              <div class="text-center"><div class="stat-val" id="g-hits" style="color:#a32d2d">0</div><div class="stat-lbl">Попаданий</div></div>
              <div class="text-center"><div class="stat-val" id="g-sunk" style="color:#185FA5">0</div><div class="stat-lbl">Потоплено</div></div>
            </div>
          </div>
        </div>

        <div class="d-flex d-md-none mb-2 gap-2 field-tabs">
          <button class="nav-link" id="g-tab-my">Моё поле</button>
          <button class="nav-link active" id="g-tab-en">Поле врага</button>
        </div>

        <div class="d-flex flex-column flex-md-row gap-3 align-items-start mb-3" id="g-fields-row">
          <div class="card shadow-sm flex-grow-1 w-100" id="g-col-my">
            <div class="card-body p-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div style="font-size:12px;font-weight:600;color:#445566" id="g-my-title">Моё поле</div>
                <span class="badge text-bg-success" style="font-size:10px">Кораблей: <span id="g-my-cnt"></span>/${SHIP_LIST.length}</span>
              </div>
              <div class="grid-scroll">
                <div class="col-labels" id="g-my-col-lbl"></div>
                <div id="g-my-grid"></div>
              </div>
            </div>
          </div>

          <div class="card shadow-sm flex-grow-1 w-100" id="g-col-en">
            <div class="card-body p-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div style="font-size:12px;font-weight:600;color:#445566" id="g-en-title">Поле противника</div>
                <span class="badge text-bg-danger" style="font-size:10px">Потоплено: <span id="g-en-cnt"></span>/${SHIP_LIST.length}</span>
              </div>
              <div class="grid-scroll">
                <div class="col-labels" id="g-en-col-lbl"></div>
                <div id="g-en-grid"></div>
              </div>
            </div>
          </div>

          <div class="card shadow-sm flex-shrink-0 w-100" id="g-fleet-card" style="max-width:170px">
            <div class="card-body p-3">
              <div style="font-size:10px;font-weight:600;color:#000;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Флот противника</div>
              <div id="g-fleet"></div>
            </div>
          </div>
        </div>

        <div class="card shadow-sm">
          <div class="card-body py-2 px-3 d-flex align-items-center gap-2 flex-wrap">
            <span style="font-size:11px;color:#000000;font-weight:600;white-space:nowrap">Последние ходы:</span>
            <div class="d-flex gap-2 flex-wrap" id="g-log"></div>
          </div>
        </div>

      </div>`;

    buildLabelsInto(document.getElementById('g-my-col-lbl'));
    buildLabelsInto(document.getElementById('g-en-col-lbl'));

    document.getElementById('g-tab-my').addEventListener('click', () => switchGameTab('my'));
    document.getElementById('g-tab-en').addEventListener('click', () => switchGameTab('en'));

    window.addEventListener('resize', applyGameTabResponsive);
  }

  function buildLabelsInto(el) {
    COLS_GAME.forEach(c => { const d = document.createElement('div'); d.className = 'col-lbl'; d.textContent = c; el.appendChild(d); });
  }

  // ── Полная перерисовка под текущего игрока ──
  function refreshGameAll() {
    // В онлайне "моё поле" — это ВСЕГДА конкретный игрок за этим
    // устройством (gameOnlineAdapter.myIndex), а не тот, чья сейчас
    // очередь — иначе экран будет "перепрыгивать" на поле соперника
    // каждый раз, когда очередь переходит к нему. В локальном режиме
    // (адаптер не задан) оба игрока сидят за одним устройством по
    // очереди, поэтому "моё поле" исторически = currentPlayer.
    const me = gameOnlineAdapter ? gameOnlineAdapter.myIndex : Game.state.currentPlayer;
    const opp = 1 - me;
    const meP = Game.state.players[me];
    const oppP = Game.state.players[opp];
    const myTurn = Game.state.currentPlayer === me;

    document.getElementById('g-my-title').textContent = '⚓ ' + meP.name + ' — моё поле';
    document.getElementById('g-en-title').textContent = '🎯 поле противника';

    document.getElementById('g-chip-0').textContent = meP.name;
    document.getElementById('g-chip-0').className = 'chip' + (myTurn ? ' chip-active' : '');
    document.getElementById('g-chip-1').textContent = oppP.name;
    document.getElementById('g-chip-1').className = 'chip' + (!myTurn ? ' chip-active' : '');

    const banner = document.getElementById('g-turn-banner');
    if (banner) {
      if (myTurn) {
        banner.textContent = '🎯 Ваш ход — стреляйте!';
        banner.style.background = '#d4edda';
        banner.style.color = '#155724';
        banner.style.border = '1px solid #c3e6cb';
      } else {
        banner.textContent = '⏳ Ход противника — ждите';
        banner.style.background = '#fff3cd';
        banner.style.color = '#856404';
        banner.style.border = '1px solid #ffc107';
      }
    }

    const shipsAlive = SHIP_LIST.length - countSunkShips(me);
    document.getElementById('g-my-cnt').textContent = shipsAlive;
    document.getElementById('g-en-cnt').textContent = countSunkShips(opp);

    document.getElementById('g-shots').textContent = meP.shotsFired.length;
    document.getElementById('g-hits').textContent = meP.shotsFired.filter(s => s.hit).length;
    document.getElementById('g-sunk').textContent = countSunkShips(opp);

    buildMyFieldGrid(me);
    buildEnFieldGrid(me);
    buildFleetStatus(opp);
    renderGameLog(me);
    applyGameTabResponsive();
  }

  function countSunkShips(playerIndex) {
    const player = Game.state.players[playerIndex];
    if (player.ships.length > 0) {
      // локальный режим или конец онлайн-игры — корабли известны
      const hitSet = new Set(player.shotsReceived.filter(s => s.hit).map(s => s.x + ',' + s.y));
      return player.ships.filter(sh => sh.coords.every(([cx, cy]) => hitSet.has(cx + ',' + cy))).length;
    }
    // онлайн-режим: считаем потопленные по shotsFired атакующего (у него sunk=true)
    const attacker = Game.state.players[1 - playerIndex];
    return attacker.shotsFired.filter(s => s.sunk).length;
  }

  // ── Флот противника по типам: сколько кораблей каждого типа ещё не потоплено ──
  // Силуэт — простые квадратные клеточки в ряд (как ship-btn-cell на расстановке).
  // Тип с остатком 0 не выводится — строка исчезает полностью, не гаснет.
  function buildFleetStatus(oppIdx) {
    const el = document.getElementById('g-fleet');
    if (!el) return;
    const oppShips = Game.state.players[oppIdx].ships;
    const attacker = Game.state.players[1 - oppIdx];
    const shotMap = {};
    attacker.shotsFired.forEach(s => { shotMap[s.x + ',' + s.y] = s; });

    el.innerHTML = '';

    if (oppShips.length === 0) {
      // онлайн-режим: корабли противника неизвестны — показываем только
      // потопленные (их координаты пришли через shipCells) и суммарный остаток.
      const sunkCount = attacker.shotsFired.filter(s => s.sunk).length;
      const totalShips = SHIP_LIST.length;
      const aliveCount = totalShips - sunkCount;

      SHIP_TYPES.forEach(type => {
        // Сколько кораблей этого типа потоплено: ищем по размеру в sunk shotsFired.
        // Точного соответствия нет (id неизвестен), поэтому показываем просто
        // сколько кораблей каждого типа ещё «живо» по общему счёту.
        // Для упрощения показываем все типы с их полным числом, убирая потопленные по одному.
        const typeTotal = type.ids.length;
        // Число потопленных кораблей этого размера — берём из sunk shipCells по длине массива
        const sunkOfType = attacker.shotsFired.filter(s => s.sunk && Array.isArray(s.shipCells) && s.shipCells.length === type.size).length;
        const remaining = Math.max(0, typeTotal - sunkOfType);
        if (remaining === 0) return;

        const row = document.createElement('div');
        row.className = 'fleet-row';
        const cells = document.createElement('div');
        cells.className = 'fleet-cells';
        for (let i = 0; i < type.size; i++) {
          const c = document.createElement('div');
          c.className = 'fleet-cell';
          cells.appendChild(c);
        }
        const label = document.createElement('span');
        label.className = 'fleet-count';
        label.textContent = '×' + remaining;
        row.appendChild(cells);
        row.appendChild(label);
        el.appendChild(row);
      });
      return;
    }

    SHIP_TYPES.forEach(type => {
      const remaining = type.ids.filter(id => {
        const ship = oppShips.find(sh => sh.id === id);
        if (!ship) return false; // на случай неполных данных — не считаем
        const allHit = ship.coords.every(([cx, cy]) => shotMap[cx + ',' + cy]?.hit);
        return !allHit;
      }).length;

      if (remaining === 0) return; // тип полностью потоплен — прячем строку

      const row = document.createElement('div');
      row.className = 'fleet-row';
      const cells = document.createElement('div');
      cells.className = 'fleet-cells';
      for (let i = 0; i < type.size; i++) {
        const c = document.createElement('div');
        c.className = 'fleet-cell';
        cells.appendChild(c);
      }
      const label = document.createElement('span');
      label.className = 'fleet-count';
      label.textContent = '×' + remaining;
      row.appendChild(cells);
      row.appendChild(label);
      el.appendChild(row);
    });
  }

  // ── Моё поле: корабли + что по ним попало ──
  function buildMyFieldGrid(me, gridId) {
    const g = document.getElementById(gridId || 'g-my-grid');
    g.innerHTML = '';
    const player = Game.state.players[me];
    const shipCells = new Set();
    player.ships.forEach(sh => sh.coords.forEach(([cx, cy]) => shipCells.add(cx + ',' + cy)));
    const hitMap = {};
    player.shotsReceived.forEach(s => { hitMap[s.x + ',' + s.y] = s.hit; });

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const isShip = shipCells.has(k);
        const wasShot = k in hitMap;
        if (isShip && wasShot) { cell.className = 'cell my-hit'; const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d); }
        else if (isShip) { cell.className = 'cell ship'; }
        else if (wasShot) { cell.className = 'cell my-miss'; const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d); }
        else { cell.className = 'cell'; }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  // ── Поле атаки: что я уже выстрелил по противнику ──
  // revealUnsunkShips — показывать ли нераскрытые (непотопленные) корабли
  // противника синим. По умолчанию false — на игровом экране корабли
  // противника видны ТОЛЬКО там, где уже потоплены (sunkCells), иначе это
  // утечка информации игроку (баг, исправлен после жалобы пользователя:
  // на игровом экране против ИИ было видно всю расстановку ИИ с первой
  // секунды партии). На финальном экране (initOver) передаётся true явно —
  // там раскрытие кораблей корректно и ожидаемо.
  function buildEnFieldGrid(me, gridId, revealUnsunkShips) {
    const g = document.getElementById(gridId || 'g-en-grid');
    g.innerHTML = '';
    const player = Game.state.players[me];
    const oppIdx = 1 - me;
    const oppShips = Game.state.players[oppIdx].ships;

    const shotMap = {};
    player.shotsFired.forEach(s => { shotMap[s.x + ',' + s.y] = s; });

    // клетки потопленных кораблей противника — раскрыть полностью.
    // В онлайне oppShips пуст до конца игры, поэтому используем shipCells
    // из shotsFired (сервер возвращает координаты при потоплении).
    const sunkCells = new Set();
    if (oppShips.length > 0) {
      oppShips.forEach(sh => {
        const allHit = sh.coords.every(([cx, cy]) => shotMap[cx + ',' + cy]?.hit);
        if (allHit) sh.coords.forEach(([cx, cy]) => sunkCells.add(cx + ',' + cy));
      });
    } else {
      player.shotsFired.forEach(s => {
        if (s.sunk && Array.isArray(s.shipCells)) {
          s.shipCells.forEach(([cx, cy]) => sunkCells.add(cx + ',' + cy));
        }
      });
    }

    // все клетки кораблей противника — используется только если
    // revealUnsunkShips === true (финальный экран); на игровом экране
    // эта информация не должна попадать в разметку вообще.
    const allShipCells = new Set();
    if (revealUnsunkShips) {
      oppShips.forEach(sh => sh.coords.forEach(([cx, cy]) => allShipCells.add(cx + ',' + cy)));
    }

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const shot = shotMap[k];
        const isShip = allShipCells.has(k);
        if (sunkCells.has(k)) {
          cell.className = 'cell en-sunk';
          const d = document.createElement('div'); d.className = 'dot-sunk'; cell.appendChild(d);
        } else if (shot && shot.hit) {
          cell.className = 'cell en-hit';
          const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d);
        } else if (shot) {
          cell.className = 'cell en-miss';
          const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d);
        } else if (isShip) {
          cell.className = 'cell ship'; // нераскрытый корабль противника (только финальный экран)
        } else {
          cell.className = 'cell en-water';
          cell.addEventListener('click', () => fireAt(c, r, cell));
        }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  // ── Выстрел с анимацией ──
  function fireAt(c, r, cell) {
    if (gameFiring) return;
    if (gameOnlineAdapter && !gameOnlineAdapter.isMyTurn()) {
      UI.showToast('Сейчас не ваш ход — подождите соперника', 1500);
      return;
    }
    gameFiring = true;
    addAnim(cell, 'anim-shell');

    setTimeout(() => {
      const resultPromise = gameOnlineAdapter
        ? gameOnlineAdapter.attack(c, r)
        : Promise.resolve(Game.attack(c, r));

      resultPromise.then(result => {
        playShotAnimation(cell, result);
      }).catch(err => {
        gameFiring = false;
        UI.showToast('Не удалось сделать выстрел: ' + (err.message || 'ошибка сети'), 2500);
      });
    }, 210);
  }

  /**
   * Проиграть анимацию результата выстрела на указанной клетке и
   * обновить экран. Вынесено из fireAt(), чтобы тот же путь анимации
   * мог запускаться и асинхронно (после ответа сервера в онлайне), и
   * синхронно (локальный режим).
   * @param {HTMLElement} cell
   * @param {object} result - формат как у Game.attack(): {hit, sunk, gameOver, winner, ...}
   */
  function playShotAnimation(cell, result) {
    if (!result) { gameFiring = false; return; }

    if (result.hit) {
      cell.className = 'cell en-hit';
      addAnim(cell, 'anim-explode');
      addAnim(cell, 'anim-ripple');
      addLabel(cell, 'Попадание!', 'hit');
      setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-hit dot-bounce'; cell.appendChild(d); }, 150);
    } else {
      cell.className = 'cell en-miss';
      addAnim(cell, 'anim-splash');
      addAnim(cell, 'anim-ripple');
      addLabel(cell, 'Мимо', 'miss');
      cell.classList.add('shake');
      setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-miss dot-bounce'; cell.appendChild(d); }, 150);
    }

    // Даём анимации и подписи кратко проявиться перед перерисовкой
    // полей (раньше было 1000мс — слишком медленно для тестера).
    setTimeout(() => {
      if (result.gameOver) {
        UI.showToast('🏆 ' + Game.state.players[result.winner].name + ' победил!', 3000);
        setTimeout(() => {
          gameFiring = false;
          if (typeof gameOnOver === 'function') gameOnOver(result);
        }, 1200);
        return;
      }

      if (result.hit) {
        UI.showToast('Попадание! Внеочередной ход — стреляйте снова', 1800);
      } else {
        const nextName = Game.state.players[Game.state.currentPlayer].name;
        UI.showToast('Мимо! Ход переходит к игроку «' + nextName + '»', 2000);
      }

      gameFiring = false;
      refreshGameAll();
    }, 200);
  }

  /**
   * Проиграть ход соперника, пришедший через Online.poll (событие
   * enemy_attack), на СВОЁМ поле (g-my-grid), а не на поле противника.
   * Используется только онлайн-режимом (Этап 7.5). result уже должен
   * быть применён к Game.state до вызова этой функции — здесь только
   * визуальный эффект и финальная перерисовка/переход к результату.
   * @param {number} x
   * @param {number} y
   * @param {object} result - тот же формат, что у Game.attack()
   */
  function applyIncomingAttack(x, y, result) {
    const grid = document.getElementById('g-my-grid');
    if (!grid) return; // экран игры ещё не отрисован — пропускаем анимацию
    const row = grid.children[y];
    const cell = row ? row.children[x + 1] : null; // +1: первая ячейка — row-lbl
    if (!cell) { refreshGameAll(); return; }

    if (result.hit) {
      cell.className = 'cell my-hit';
      addAnim(cell, 'anim-explode');
      addAnim(cell, 'anim-ripple');
      addLabel(cell, 'Попадание!', 'hit');
      setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-hit dot-bounce'; cell.appendChild(d); }, 150);
    } else {
      cell.className = 'cell my-miss';
      addAnim(cell, 'anim-splash');
      addAnim(cell, 'anim-ripple');
      addLabel(cell, 'Мимо', 'miss');
      cell.classList.add('shake');
      setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-miss dot-bounce'; cell.appendChild(d); }, 150);
    }

    setTimeout(() => {
      if (result.gameOver) {
        UI.showToast('💥 ' + Game.state.players[result.winner].name + ' победил!', 3000);
        setTimeout(() => {
          if (typeof gameOnOver === 'function') gameOnOver(result);
        }, 1200);
        return;
      }

      if (result.hit) {
        UI.showToast('Соперник попал! У него внеочередной ход', 1800);
      } else {
        UI.showToast('Соперник промахнулся! Теперь ваш ход', 2000);
      }

      refreshGameAll();
    }, 200);
  }

  function addAnim(cell, cls) { const el = document.createElement('div'); el.className = cls; cell.appendChild(el); setTimeout(() => el.remove(), 700); }
  function addLabel(cell, text, cls) { const el = document.createElement('div'); el.className = 'anim-label ' + cls; el.textContent = text; cell.appendChild(el); setTimeout(() => el.remove(), 900); }

  // ── Журнал последних ходов ──
  function renderGameLog(me) {
    const el = document.getElementById('g-log');
    const player = Game.state.players[me];
    const last = player.shotsFired.slice(-7).reverse();
    el.innerHTML = last.map(s =>
      `<span class="log-item ${s.hit ? 'h' : 'm'}">${COLS_GAME[s.x]}${s.y + 1} — ${s.hit ? 'попадание' : 'мимо'}</span>`
    ).join('');
  }

  // ── Мобильные вкладки ──
  function switchGameTab(t) {
    gameActiveTab = t;
    applyGameTabResponsive();
  }

  function applyGameTabResponsive() {
    const tabMy = document.getElementById('g-tab-my');
    const tabEn = document.getElementById('g-tab-en');
    if (tabMy) tabMy.classList.toggle('active', gameActiveTab === 'my');
    if (tabEn) tabEn.classList.toggle('active', gameActiveTab === 'en');

    const isMobile = window.innerWidth < 768;
    const colMy = document.getElementById('g-col-my');
    const colEn = document.getElementById('g-col-en');
    if (!colMy || !colEn) return;
    if (isMobile) {
      colMy.classList.toggle('d-none', gameActiveTab !== 'my');
      colEn.classList.toggle('d-none', gameActiveTab !== 'en');
    } else {
      colMy.classList.remove('d-none');
      colEn.classList.remove('d-none');
    }

    placeFleetCard(isMobile);
  }

  // ── Флот противника: на десктопе — отдельная колонка справа от полей;
  //    на мобиле — переезжает под сетку поля врага внутри той же карточки. ──
  function placeFleetCard(isMobile) {
    const fleetCard = document.getElementById('g-fleet-card');
    const colEn = document.getElementById('g-col-en');
    const fieldsRow = document.getElementById('g-fields-row');
    if (!fleetCard || !colEn || !fieldsRow) return;

    if (isMobile) {
      if (fleetCard.parentElement !== colEn.querySelector('.card-body')) {
        fleetCard.classList.remove('w-100');
        fleetCard.classList.add('mt-3');
        fleetCard.style.maxWidth = 'none';
        colEn.querySelector('.card-body').appendChild(fleetCard);
      }
    } else {
      if (fleetCard.parentElement !== fieldsRow) {
        fleetCard.classList.remove('mt-3');
        fleetCard.classList.add('w-100');
        fleetCard.style.maxWidth = '170px';
        fieldsRow.appendChild(fleetCard);
      }
    }
  }

  /* ════════════════════════════════════════════════════════
     ЭКРАН РЕЗУЛЬТАТА — Этап 4
     Источник данных: Game.state.winner + players[i].ships /
     shotsFired / shotsReceived. Перенесено из prototypes/game_over.html,
     поля строятся из реального состояния, а не из мок-данных.
     ════════════════════════════════════════════════════════ */

  const COLS_OVER = COLS; // те же подписи столбцов А-К

  /**
   * Запустить экран результата.
   * @param {Function} onPlayAgain - callback() — вызывается по клику "Играть снова"
   * @param {Function} onToLobby   - callback() — вызывается по клику "В лобби"
   */
  function initOver(onPlayAgain, onToLobby) {
    renderOverShell();

    const winnerIdx = Game.state.winner;
    const loserIdx = 1 - winnerIdx;
    const winner = Game.state.players[winnerIdx];

    const banner = document.getElementById('o-banner');
    banner.className = 'result-banner win mb-3';
    document.getElementById('o-icon').textContent = '🏆';
    document.getElementById('o-title').textContent = winner.name + ' победил!';
    document.getElementById('o-sub').textContent = 'Все корабли противника потоплены';

    // Сводная статистика — суммарно по обоим игрокам
    const allShots = Game.state.players[0].shotsFired.length + Game.state.players[1].shotsFired.length;
    const allHits = Game.state.players[0].shotsFired.filter(s => s.hit).length +
                     Game.state.players[1].shotsFired.filter(s => s.hit).length;
    const acc = allShots > 0 ? Math.round(allHits / allShots * 100) : 0;

    document.getElementById('o-shots').textContent = allShots;
    document.getElementById('o-hits').textContent = allHits;
    document.getElementById('o-acc').textContent = acc + '%';
    document.getElementById('o-time').textContent = formatBattleTime();

    document.getElementById('o-p0-title').textContent = '⚓ ' + Game.state.players[0].name + ' — расположение кораблей';
    document.getElementById('o-p1-title').textContent = '⚓ ' + Game.state.players[1].name + ' — расположение кораблей';
    const me = gameOnlineAdapter ? gameOnlineAdapter.myIndex : Game.state.currentPlayer;
    buildMyFieldGrid(me, 'o-p0-grid');
    buildEnFieldGrid(me, 'o-p1-grid', true);

    document.getElementById('btn-over-lobby').onclick = () => { if (typeof onToLobby === 'function') onToLobby(); };
    document.getElementById('btn-over-replay').onclick = () => { if (typeof onPlayAgain === 'function') onPlayAgain(); };
  }

  function formatBattleTime() {
    if (!Game.state.battleStartedAt) return '—:—';
    const totalSec = Math.max(0, Math.round((Date.now() - Game.state.battleStartedAt) / 1000));
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  function renderOverShell() {
    const root = document.getElementById('screen-over');
    root.innerHTML = `
      <div class="container py-4" style="max-width:760px">

        <div class="result-banner win mb-3" id="o-banner">
          <div class="result-icon" id="o-icon">🏆</div>
          <div class="result-title win" id="o-title"></div>
          <div class="result-sub" id="o-sub"></div>
        </div>

        <div class="row g-2 mb-3">
          <div class="col-3"><div class="stat-card"><div class="v" id="o-shots">0</div><div class="l">Выстрелов</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-hits">0</div><div class="l">Попаданий</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-acc">0%</div><div class="l">Точность</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-time">00:00</div><div class="l">Время боя</div></div></div>
        </div>

        <div class="card shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="row g-3">
              <div class="col-12 col-md-6">
                <div class="field-title" id="o-p0-title"></div>
                <div class="grid-scroll">
                  <div class="col-labels" id="o-p0-col-lbl"></div>
                  <div id="o-p0-grid"></div>
                </div>
              </div>
              <div class="col-12 col-md-6">
                <div class="field-title" id="o-p1-title"></div>
                <div class="grid-scroll">
                  <div class="col-labels" id="o-p1-col-lbl"></div>
                  <div id="o-p1-grid"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-lobby flex-fill" id="btn-over-lobby">← В лобби</button>
          <button class="btn btn-replay flex-fill" id="btn-over-replay">↻ Играть снова</button>
        </div>

      </div>`;

    buildLabelsInto(document.getElementById('o-p0-col-lbl'));
    buildLabelsInto(document.getElementById('o-p1-col-lbl'));
  }

  // ── Итоговое поле игрока: все его корабли раскрыты, с отметками боя ──
  function buildOverFieldGrid(gridId, playerIndex) {
    const g = document.getElementById(gridId);
    g.innerHTML = '';
    const player = Game.state.players[playerIndex];

    const shipCells = new Set();
    player.ships.forEach(sh => sh.coords.forEach(([cx, cy]) => shipCells.add(cx + ',' + cy)));

    const hitMap = {};
    player.shotsReceived.forEach(s => { hitMap[s.x + ',' + s.y] = s.hit; });

    // клетки потопленных кораблей — выделить отдельным цветом
    const sunkCells = new Set();
    player.ships.forEach(sh => {
      const allHit = sh.coords.every(([cx, cy]) => hitMap[cx + ',' + cy] === true);
      if (allHit) sh.coords.forEach(([cx, cy]) => sunkCells.add(cx + ',' + cy));
    });

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const isShip = shipCells.has(k);
        const wasShot = k in hitMap;

        if (sunkCells.has(k)) {
          cell.className = 'cell en-sunk';
          const d = document.createElement('div'); d.className = 'dot-sunk'; cell.appendChild(d);
        } else if (isShip && wasShot) {
          cell.className = 'cell my-hit';
          const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d);
        } else if (isShip) {
          cell.className = 'cell ship';
        } else if (wasShot) {
          cell.className = 'cell my-miss';
          const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d);
        } else {
          cell.className = 'cell';
        }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  return { initPlacing, initGame, initOver, applyIncomingAttack };

})();