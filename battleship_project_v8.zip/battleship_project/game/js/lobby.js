/* ════════════════════════════════════════════════════════
   lobby.js — сервис: экран лобби (режимы, имена, опции)
   Перенесено из prototypes/lobby.html, подключено к Game.state.
   ════════════════════════════════════════════════════════ */

window.Lobby = (() => {

  const STORAGE_KEY = 'bs_names';
  let names = [];
  let mode = 'local';     // local | ai | online
  let diff = 'mid';        // easy | mid | hard
  let onStart = null;      // callback() — запуск партии в режиме local

  function loadNames() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) { names = JSON.parse(raw); return; }
    } catch (e) { /* localStorage недоступен — работаем без истории */ }
    names = [];
  }

  function saveNames() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(names)); } catch (e) { /* ignore */ }
  }

  /**
   * Построить экран лобби и подготовить обработчики.
   * @param {Function} startLocalGameCallback - вызывается, когда игрок
   *   нажал "В бой" в режиме "Локально" с введёнными именами
   */
  function init(startLocalGameCallback) {
    onStart = startLocalGameCallback;
    loadNames();
    mode = 'local';
    diff = 'mid';
    render();
  }

  function render() {
    const root = document.getElementById('screen-lobby');
    root.innerHTML = `
      <div class="container py-4" style="max-width:480px">
        <div class="card shadow-sm">
          <div class="card-header px-3 py-2">Новый бой</div>
          <div class="card-body p-3">

            <label class="form-label">Ваш позывной</label>
            <div class="name-wrap mb-3">
              <input type="text" class="form-control pe-4" id="lb-inp1" placeholder="Введите имя..." maxlength="20" autocomplete="off">
              <button class="input-clear" id="lb-clr1">×</button>
              <div class="name-dropdown" id="lb-dd1">
                <div class="dd-header"><span>История</span><button class="dd-clear" id="lb-clear-history-1">Очистить</button></div>
                <div id="lb-dd1-list"></div>
              </div>
            </div>

            <hr class="my-3">

            <div class="form-label mb-2">Режим игры</div>
            <div class="row g-2 mb-3">
              <div class="col-4">
                <div class="mode-btn active-blue" id="lb-m-local">
                  <div class="mode-icon">💻</div>
                  <span class="mode-name">Локально</span>
                  <span class="mode-desc">Два игрока</span>
                </div>
              </div>
              <div class="col-4 position-relative">
                <span class="badge-ai">ИИ</span>
                <div class="mode-btn mode-disabled" id="lb-m-ai">
                  <div class="mode-icon">🤖</div>
                  <span class="mode-name">Против ИИ</span>
                  <span class="mode-desc">Один игрок</span>
                </div>
              </div>
              <div class="col-4 position-relative">
                <span class="badge-soon">Скоро</span>
                <div class="mode-btn mode-disabled" id="lb-m-online">
                  <div class="mode-icon">🌐</div>
                  <span class="mode-name">Онлайн</span>
                  <span class="mode-desc">Через сеть</span>
                </div>
              </div>
            </div>

            <div id="lb-block-p2" class="mb-3">
              <label class="form-label">Позывной игрока 2</label>
              <div class="name-wrap">
                <input type="text" class="form-control pe-4" id="lb-inp2" placeholder="Введите имя..." maxlength="20" autocomplete="off">
                <button class="input-clear" id="lb-clr2">×</button>
                <div class="name-dropdown" id="lb-dd2">
                  <div class="dd-header"><span>История</span><button class="dd-clear" id="lb-clear-history-2">Очистить</button></div>
                  <div id="lb-dd2-list"></div>
                </div>
              </div>
            </div>

            <div id="lb-block-ai" class="mb-3" style="display:none">
              <label class="form-label">Сложность</label>
              <div class="row g-2">
                <div class="col-4"><div class="diff-btn" id="lb-d-easy">Юнга</div></div>
                <div class="col-4"><div class="diff-btn d-mid" id="lb-d-mid">Капитан</div></div>
                <div class="col-4"><div class="diff-btn" id="lb-d-hard">Адмирал</div></div>
              </div>
            </div>

            <hr class="my-3">

            <div class="form-check mb-1">
              <input class="form-check-input" type="checkbox" id="lb-chk-deadzone">
              <label class="form-check-label" for="lb-chk-deadzone" style="font-size:13px">Показывать мёртвую зону</label>
            </div>
            <div class="text-muted mb-3" style="font-size:11px;padding-left:24px">После потопления корабля автоматически отмечать клетки вокруг него</div>

            <button class="btn btn-start btn-blue w-100" id="lb-start-btn" style="font-size:13px;font-weight:600;padding:10px">В бой →</button>
          </div>
        </div>

        <div class="card mt-3 shadow-sm">
          <div class="card-body py-2 px-3">
            <div class="row text-center">
              <div class="col-3"><div class="stat-val">10×10</div><div class="stat-lbl">Поле</div></div>
              <div class="col-3"><div class="stat-val">10</div><div class="stat-lbl">Кораблей</div></div>
              <div class="col-3"><div class="stat-val">20</div><div class="stat-lbl">Клеток</div></div>
              <div class="col-3"><div class="stat-val">100</div><div class="stat-lbl">Ударов</div></div>
            </div>
          </div>
        </div>
      </div>`;

    wireEvents();
    renderDropdown(1, '');
    renderDropdown(2, '');
  }

  function wireEvents() {
    document.getElementById('lb-m-local').addEventListener('click', () => setMode('local'));
    document.getElementById('lb-m-ai').addEventListener('click', () => setMode('ai'));
    document.getElementById('lb-m-online').addEventListener('click', () => setMode('online'));

    document.getElementById('lb-d-easy').addEventListener('click', () => setDiff('easy'));
    document.getElementById('lb-d-mid').addEventListener('click', () => setDiff('mid'));
    document.getElementById('lb-d-hard').addEventListener('click', () => setDiff('hard'));

    document.getElementById('lb-start-btn').addEventListener('click', onStartClick);

    [1, 2].forEach(id => {
      const inp = document.getElementById('lb-inp' + id);
      const clr = document.getElementById('lb-clr' + id);
      if (!inp) return;
      inp.addEventListener('focus', () => openDropdown(id));
      inp.addEventListener('input', () => {
        renderDropdown(id, inp.value);
        clr.style.display = inp.value ? 'block' : 'none';
      });
      inp.addEventListener('keydown', e => { if (e.key === 'Escape') closeDropdown(id); });
      clr.addEventListener('click', () => clearInput(id));
      document.getElementById('lb-clear-history-' + id).addEventListener('click', e => clearHistory(e));
    });

    document.addEventListener('click', outsideClickHandler);
  }

  function outsideClickHandler(e) {
    [1, 2].forEach(id => {
      const inp = document.getElementById('lb-inp' + id);
      if (!inp) return;
      const wrap = inp.closest('.name-wrap');
      if (wrap && !wrap.contains(e.target)) closeDropdown(id);
    });
  }

  // ── Режимы ──
  function setMode(m) {
    if (m === 'ai' || m === 'online') {
      UI.showToast(m === 'ai' ? 'Режим «Против ИИ» скоро будет доступен' : 'Онлайн-режим скоро будет доступен', 2200);
      return; // пока не реализовано — см. план, Этапы 5–8 (онлайн) / ИИ не входит в текущий план
    }
    mode = m;
    document.getElementById('lb-m-local').classList.add('active-blue');
    document.getElementById('lb-block-p2').style.display = 'block';
    document.getElementById('lb-block-ai').style.display = 'none';
  }

  function setDiff(d) {
    diff = d;
    ['easy', 'mid', 'hard'].forEach(x => { document.getElementById('lb-d-' + x).className = 'diff-btn'; });
    document.getElementById('lb-d-' + d).className = 'diff-btn d-' + d;
  }

  // ── История имён ──
  function renderDropdown(id, filter) {
    const list = document.getElementById('lb-dd' + id + '-list');
    if (!list) return;
    const filtered = filter ? names.filter(n => n.toLowerCase().includes(filter.toLowerCase())) : names;
    if (!filtered.length) {
      list.innerHTML = '<div class="dd-item text-muted" style="cursor:default">История пуста</div>';
      return;
    }
    list.innerHTML = filtered.map(n => `
      <div class="dd-item" data-name="${n}">
        <span>👤</span><span>${n}</span>
        <button class="dd-del" data-del="${n}">×</button>
      </div>`).join('');

    list.querySelectorAll('.dd-item').forEach(el => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.dd-del')) return;
        pickName(id, el.dataset.name);
      });
    });
    list.querySelectorAll('.dd-del').forEach(el => {
      el.addEventListener('click', (e) => { e.stopPropagation(); deleteName(id, el.dataset.del); });
    });
  }

  function openDropdown(id) { renderDropdown(id, document.getElementById('lb-inp' + id).value); document.getElementById('lb-dd' + id).classList.add('open'); }
  function closeDropdown(id) { document.getElementById('lb-dd' + id)?.classList.remove('open'); }
  function pickName(id, name) {
    document.getElementById('lb-inp' + id).value = name;
    document.getElementById('lb-clr' + id).style.display = 'block';
    closeDropdown(id);
  }
  function clearInput(id) {
    document.getElementById('lb-inp' + id).value = '';
    document.getElementById('lb-clr' + id).style.display = 'none';
    document.getElementById('lb-inp' + id).focus();
  }
  function clearHistory(e) {
    e.stopPropagation();
    names = [];
    saveNames();
    renderDropdown(1, document.getElementById('lb-inp1')?.value || '');
    renderDropdown(2, document.getElementById('lb-inp2')?.value || '');
  }
  function deleteName(id, name) {
    names = names.filter(n => n !== name);
    saveNames();
    renderDropdown(1, document.getElementById('lb-inp1')?.value || '');
    renderDropdown(2, document.getElementById('lb-inp2')?.value || '');
  }
  function rememberName(name) {
    if (!name) return;
    names = names.filter(n => n !== name);
    names.unshift(name);
    if (names.length > 10) names.pop();
    saveNames();
  }

  // ── Старт партии ──
  function onStartClick() {
    const n1 = document.getElementById('lb-inp1').value.trim() || 'Игрок 1';
    const n2 = document.getElementById('lb-inp2').value.trim() || 'Игрок 2';
    const showDeadZone = document.getElementById('lb-chk-deadzone').checked;

    rememberName(document.getElementById('lb-inp1').value.trim());
    rememberName(document.getElementById('lb-inp2').value.trim());

    Game.state.players[0].name = n1;
    Game.state.players[1].name = n2;
    Game.state.options.showDeadZone = showDeadZone;
    Game.state.options.aiDifficulty = diff;
    Game.state.mode = mode;

    if (typeof onStart === 'function') onStart();
  }

  return { init };

})();
