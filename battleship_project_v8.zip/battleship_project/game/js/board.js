/* ════════════════════════════════════════════════════════
   board.js — сервис: отрисовка полей и расстановка кораблей
   Этап 2: интерактивная расстановка на сетке 10×10.
   Логика отрисовки боя (renderGameBoards) добавится на Этапе 3.
   ════════════════════════════════════════════════════════ */

window.Board = (() => {

  const COLS = 'АБВГДЕЖЗИК'.split('');
  const SHIP_LIST = Game.SHIP_LIST;
  const SHIP_TYPES = Game.SHIP_TYPES;

  // ── Локальное рабочее состояние текущей расстановки ──
  // (своё для каждого вызова initPlacing — два игрока расставляют
  // корабли по очереди на одном и том же экране)
  let board = [];        // 10×10: 0=пусто, 1=корабль, 2=мёртвая зона
  let placed = {};        // id -> {coords, dir}
  let newSel = null;       // id корабля из списка, выбранного для размещения
  let fieldSel = null;     // id корабля, выделенного на поле
  let dir = 'H';
  let hover = null;
  let cells = [];
  let currentPlayerIndex = 0;
  let onAllPlaced = null;  // callback() — вызывается когда оба игрока расставили корабли

  // ── Публичный запуск расстановки для игрока ──
  function initPlacing(playerIndex, doneCallback) {
    currentPlayerIndex = playerIndex;
    onAllPlaced = doneCallback;

    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {};
    newSel = null;
    fieldSel = null;
    dir = 'H';
    hover = null;

    renderShell();
    buildGrid();
    buildShipGroups();
    refreshDelBtn();
    updateProgress();
    updateHint();

    const player = Game.state.players[playerIndex];
    document.getElementById('placing-player-chip').textContent = '⚓ ' + (player.name || ('Игрок ' + (playerIndex + 1)));
  }

  // ── Разметка экрана (создаётся один раз за вызов initPlacing) ──
  function renderShell() {
    const root = document.getElementById('screen-placing');
    root.innerHTML = `
      <div class="container py-3 px-3" style="max-width:760px">
        <div class="card shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="d-flex align-items-center justify-content-between mb-2">
              <div class="fw-semibold" style="font-size:13px;color:#000000">Расставьте корабли на поле</div>
              <div class="d-flex align-items-center gap-2">
                <div class="prog-wrap" style="width:80px"><div class="prog-bar" id="pb" style="width:0%"></div></div>
                <span style="font-size:11px;color:#000;white-space:nowrap" id="pl">0 / ${SHIP_LIST.length}</span>
              </div>
            </div>
            <div class="d-flex flex-column flex-sm-row gap-4 align-items-start">
              <div class="grid-scroll flex-shrink-0">
                <div class="col-labels" id="col-lbl"></div>
                <div id="grid"></div>
              </div>
              <div class="flex-grow-1" style="min-width:180px">
                <div style="font-size:11px;font-weight:600;color:#000000;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Корабли</div>
                <div id="ship-groups"></div>
              </div>
            </div>
          </div>
        </div>
        <div class="card shadow-sm">
          <div class="card-body p-3">
            <div class="d-flex flex-wrap align-items-center gap-2">
              <div class="hint-box flex-grow-1" id="hint" style="min-width:140px"></div>
              <button class="btn btn-act" id="btn-del">✕ Удалить</button>
              <button class="btn btn-act" id="btn-auto">⚡ Авторасстановка</button>
              <button class="btn btn-act" id="btn-reset">↺ Сбросить</button>
              <button class="btn btn-primary" id="btn-ready" disabled>✓ Готово</button>
            </div>
          </div>
        </div>
      </div>`;

    document.getElementById('btn-del').addEventListener('click', deleteSelected);
    document.getElementById('btn-auto').addEventListener('click', autoPlace);
    document.getElementById('btn-reset').addEventListener('click', resetAll);
    document.getElementById('btn-ready').addEventListener('click', onReadyClick);
  }

  // ── Сетка ──
  function buildGrid() {
    const cl = document.getElementById('col-lbl');
    COLS.forEach(c => { const d = document.createElement('div'); d.className = 'col-lbl'; d.textContent = c; cl.appendChild(d); });
    const g = document.getElementById('grid');
    cells = [];
    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      cells[r] = [];
      for (let c = 0; c < 10; c++) {
        const cell = document.createElement('div'); cell.className = 'cell';
        cell.addEventListener('mouseenter', () => { hover = [c, r]; redrawPreview(); });
        cell.addEventListener('mouseleave', () => { hover = null; drawBoard(); });
        cell.addEventListener('click', () => onCellClick(c, r));
        cells[r][c] = cell; row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  function drawBoard() {
    for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) {
      const v = board[r][c];
      if (v === 1) cells[r][c].className = cellBelongsTo(c, r, fieldSel) ? 'cell ship-sel' : 'cell ship';
      else if (v === 2) cells[r][c].className = 'cell deadzone';
      else cells[r][c].className = 'cell';
    }
  }

  function redrawPreview() {
    drawBoard();
    const aid = fieldSel !== null ? fieldSel : newSel;
    if (aid === null || !hover) return;
    const [hc, hr] = hover;
    const ship = SHIP_LIST.find(s => s.id === aid);
    const co = coords4(hc, hr, ship.size, dir);
    const ok = canPlace(co, fieldSel !== null ? fieldSel : null);
    co.forEach(([cc, rc]) => {
      if (rc >= 0 && rc < 10 && cc >= 0 && cc < 10)
        cells[rc][cc].className = 'cell ' + (ok ? 'preview' : 'preview-bad');
    });
  }

  // ── Координаты и проверки ──
  function coords4(c, r, size, d) {
    const res = []; for (let i = 0; i < size; i++) res.push(d === 'H' ? [c + i, r] : [c, r + i]); return res;
  }

  function nbrs(coords) {
    const set = new Set(coords.map(([c, r]) => c + ',' + r)); const res = [];
    coords.forEach(([c, r]) => { for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
      const nc = c + dc, nr = r + dr;
      if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && !set.has(nc + ',' + nr)) res.push([nc, nr]);
    }}); return res;
  }

  function mkTmp(ignoreId) {
    const tmp = board.map(r => [...r]);
    if (ignoreId !== null && placed[ignoreId]) {
      placed[ignoreId].coords.forEach(([c, r]) => tmp[r][c] = 0);
      for (let r = 0; r < 10; r++) for (let c = 0; c < 10; c++) if (tmp[r][c] === 2) tmp[r][c] = 0;
      Object.entries(placed).forEach(([sid, { coords: sc }]) => {
        if (parseInt(sid) === ignoreId) return;
        nbrs(sc).forEach(([c, r]) => { if (tmp[r][c] === 0) tmp[r][c] = 2; });
      });
    }
    return tmp;
  }

  function canPlace(coords, ignoreId) {
    const tmp = mkTmp(ignoreId);
    return coords.every(([c, r]) => c >= 0 && c < 10 && r >= 0 && r < 10 && tmp[r][c] === 0) &&
      coords.every(([c, r]) => {
        for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
          if (!dr && !dc) continue;
          const nc = c + dc, nr = r + dr;
          if (nc >= 0 && nc < 10 && nr >= 0 && nr < 10 && tmp[nr][nc] === 1) return false;
        } return true;
      });
  }

  function cellBelongsTo(c, r, id) {
    if (id === null || !placed[id]) return false;
    return placed[id].coords.some(([cc, rc]) => cc === c && rc === r);
  }

  function shipIdAt(c, r) {
    for (const [sid, { coords }] of Object.entries(placed))
      if (coords.some(([cc, rc]) => cc === c && rc === r)) return parseInt(sid);
    return null;
  }

  // ── Клик по клетке поля ──
  function onCellClick(c, r) {
    if (fieldSel !== null) {
      if (cellBelongsTo(c, r, fieldSel)) {
        dir = dir === 'H' ? 'V' : 'H'; hover = [c, r]; redrawPreview(); updateHint(); return;
      }
      const co = coords4(c, r, SHIP_LIST.find(s => s.id === fieldSel).size, dir);
      if (!canPlace(co, fieldSel)) return;
      board = mkTmp(fieldSel);
      co.forEach(([cc, rc]) => board[rc][cc] = 1);
      nbrs(co).forEach(([cc, rc]) => { if (board[rc][cc] === 0) board[rc][cc] = 2; });
      placed[fieldSel] = { coords: co, dir };
      fieldSel = null;
      refreshDelBtn(); drawBoard(); updateProgress(); updateHint(); return;
    }
    if (newSel !== null) {
      const co = coords4(c, r, SHIP_LIST.find(s => s.id === newSel).size, dir);
      if (!canPlace(co, null)) return;
      co.forEach(([cc, rc]) => board[rc][cc] = 1);
      nbrs(co).forEach(([cc, rc]) => { if (board[rc][cc] === 0) board[rc][cc] = 2; });
      placed[newSel] = { coords: co, dir };
      newSel = null; dir = 'H';
      refreshGroupUI(); refreshDelBtn(); drawBoard(); updateProgress(); updateHint(); return;
    }
    const sid = shipIdAt(c, r);
    if (sid !== null) { fieldSel = sid; dir = placed[sid].dir; refreshDelBtn(); drawBoard(); updateHint(); }
  }

  // ── Клик по кнопке группы кораблей ──
  function nextFreeId(gIdx) {
    return SHIP_TYPES[gIdx].ids.find(id => placed[id] === undefined) ?? null;
  }

  function onGroupClick(gIdx) {
    fieldSel = null;
    const free = nextFreeId(gIdx);
    if (free === null) return;
    newSel = free; dir = 'H';
    refreshGroupUI(); refreshDelBtn(); drawBoard(); redrawPreview(); updateHint();
  }

  function refreshGroupUI() {
    SHIP_TYPES.forEach((g, gIdx) => {
      const remaining = g.ids.filter(id => placed[id] === undefined).length;
      const btn = document.getElementById('grp-btn-' + gIdx);
      const cnt = document.getElementById('grp-cnt-' + gIdx);
      if (!btn || !cnt) return;
      const isSelectedGroup = newSel !== null && g.ids.includes(newSel);
      btn.classList.toggle('sel', isSelectedGroup);
      btn.classList.toggle('empty', remaining === 0);
      cnt.textContent = remaining;
      cnt.className = 'ship-counter' + (remaining === 0 ? ' zero' : '');
    });
  }

  // ── Удаление ──
  function deleteSelected() {
    if (fieldSel === null) return;
    board = mkTmp(fieldSel);
    delete placed[fieldSel];
    fieldSel = null;
    refreshGroupUI(); refreshDelBtn(); drawBoard(); updateProgress(); updateHint();
  }

  function refreshDelBtn() {
    const btn = document.getElementById('btn-del');
    if (btn) btn.disabled = fieldSel === null;
  }

  // ── Авто / Сброс ──
  function autoPlace() {
    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {}; newSel = null; fieldSel = null; dir = 'H';
    SHIP_LIST.forEach(ship => {
      let ok = false;
      for (let i = 0; i < 500 && !ok; i++) {
        const d = Math.random() < .5 ? 'H' : 'V';
        const c = Math.floor(Math.random() * 10), r = Math.floor(Math.random() * 10);
        const cs = coords4(c, r, ship.size, d);
        if (canPlace(cs, null)) {
          cs.forEach(([cc, rc]) => board[rc][cc] = 1);
          nbrs(cs).forEach(([cc, rc]) => { if (board[rc][cc] === 0) board[rc][cc] = 2; });
          placed[ship.id] = { coords: cs, dir: d }; ok = true;
        }
      }
    });
    refreshGroupUI(); refreshDelBtn(); drawBoard(); updateProgress(); updateHint();
  }

  function resetAll() {
    board = Array.from({ length: 10 }, () => Array(10).fill(0));
    placed = {}; newSel = null; fieldSel = null; dir = 'H';
    refreshGroupUI(); refreshDelBtn(); drawBoard(); updateProgress(); updateHint();
  }

  // ── Прогресс и подсказка ──
  function updateProgress() {
    const n = Object.keys(placed).length;
    document.getElementById('pb').style.width = (n / SHIP_LIST.length * 100) + '%';
    document.getElementById('pl').textContent = n + ' / ' + SHIP_LIST.length;
    document.getElementById('btn-ready').disabled = n < SHIP_LIST.length;
  }

  function updateHint() {
    const el = document.getElementById('hint');
    const n = Object.keys(placed).length;
    if (fieldSel !== null) {
      el.className = 'hint-box hint-orange flex-grow-1';
      el.innerHTML = `<b>${SHIP_LIST.find(s => s.id === fieldSel).name}</b> выделен · клик на поле = переместить · клик по нему = повернуть`;
      return;
    }
    if (newSel !== null) {
      const s = SHIP_LIST.find(s => s.id === newSel);
      el.className = 'hint-box hint-blue flex-grow-1';
      el.innerHTML = `<b>${s.name} (${s.size} кл.)</b> — кликните на поле для размещения`;
      return;
    }
    if (n === SHIP_LIST.length) {
      el.className = 'hint-box hint-green flex-grow-1';
      el.innerHTML = '<b>Все корабли расставлены!</b> Нажмите «Готово»';
      return;
    }
    el.className = 'hint-box flex-grow-1';
    el.innerHTML = '<b>Выберите корабль</b> из списка · или кликните на стоящий корабль на поле';
  }

  // ── Список кораблей ──
  function buildShipGroups() {
    const wrap = document.getElementById('ship-groups');
    wrap.innerHTML = '';
    SHIP_TYPES.forEach((g, gIdx) => {
      const row = document.createElement('div'); row.className = 'ship-group-row';

      const btn = document.createElement('div');
      btn.className = 'ship-btn'; btn.id = 'grp-btn-' + gIdx;
      btn.addEventListener('click', () => onGroupClick(gIdx));
      const nm = document.createElement('span'); nm.textContent = g.name;
      const cs = document.createElement('div'); cs.className = 'ship-btn-cells';
      for (let i = 0; i < g.size; i++) { const c = document.createElement('div'); c.className = 'ship-btn-cell'; cs.appendChild(c); }
      btn.appendChild(nm); btn.appendChild(cs);

      const cnt = document.createElement('div');
      cnt.className = 'ship-counter'; cnt.id = 'grp-cnt-' + gIdx;
      cnt.textContent = g.ids.length;

      row.appendChild(btn); row.appendChild(cnt);
      wrap.appendChild(row);
    });
  }

  // ── Завершение расстановки игрока ──
  function onReadyClick() {
    // Преобразовать placed{} в массив для Game.placeShips()
    const ships = SHIP_LIST.map(s => ({
      id: s.id, name: s.name, size: s.size,
      coords: placed[s.id].coords, dir: placed[s.id].dir,
    }));
    Game.placeShips(currentPlayerIndex, ships);

    if (currentPlayerIndex === 0) {
      UI.showToast('Корабли расставлены. Очередь игрока 2.');
      initPlacing(1, onAllPlaced);
    } else {
      if (typeof onAllPlaced === 'function') onAllPlaced();
    }
  }

  document.addEventListener('keydown', e => {
    if (document.getElementById('screen-placing')?.classList.contains('d-none')) return;
    if (e.key === 'Escape') {
      newSel = null; fieldSel = null; dir = 'H';
      refreshGroupUI(); refreshDelBtn(); drawBoard(); updateHint();
    }
  });

  /* ════════════════════════════════════════════════════════
     ИГРОВОЙ ЭКРАН — Этап 3
     Оба игрока играют на одном устройстве без паузы передачи:
     "моё поле" / "поле противника" всегда относится к тому,
     чья сейчас очередь (Game.state.currentPlayer).
     Десктоп-вёрстка переработана: центрированный блок (max-width:920px)
     вместо растяжки на всю ширину + колонка "Флот противника" (только
     для поля врага — свои корабли видны на своём поле и так).
     На мобиле тот же #g-fleet физически переезжает под сетку поля
     врага (внутри вкладки "Поле врага") — см. applyGameTabResponsive().
     ════════════════════════════════════════════════════════ */

  const COLS_GAME = COLS; // те же подписи столбцов А-К
  let gameFiring = false;       // блокировка повторного клика во время анимации
  let gameActiveTab = 'my';      // 'my' | 'en' — активная вкладка на мобиле
  let gameOnOver = null;         // callback(result) при завершении партии

  function initGame(onOverCallback) {
    gameOnOver = onOverCallback;
    gameFiring = false;
    gameActiveTab = 'my';
    renderGameShell();
    refreshGameAll();
  }

  function renderGameShell() {
    const root = document.getElementById('screen-game');
    root.innerHTML = `
      <div class="container py-3 px-3" style="max-width:920px">

        <div class="card shadow-sm mb-3">
          <div class="card-body py-2 px-3 d-flex flex-wrap align-items-center justify-content-between gap-2">
            <div class="d-flex align-items-center gap-2">
              <span class="chip" id="g-chip-0"></span>
              <span style="font-size:12px;color:#000;font-weight:500">vs</span>
              <span class="chip" id="g-chip-1"></span>
            </div>
            <div class="d-flex gap-3">
              <div class="text-center"><div class="stat-val" id="g-shots">0</div><div class="stat-lbl">Выстрелов</div></div>
              <div class="text-center"><div class="stat-val" id="g-hits" style="color:#a32d2d">0</div><div class="stat-lbl">Попаданий</div></div>
              <div class="text-center"><div class="stat-val" id="g-sunk" style="color:#185FA5">0</div><div class="stat-lbl">Потоплено</div></div>
            </div>
          </div>
        </div>

        <div class="d-flex d-md-none mb-2 gap-2 field-tabs">
          <button class="nav-link active" id="g-tab-my">Моё поле</button>
          <button class="nav-link" id="g-tab-en">Поле врага</button>
        </div>

        <div class="d-flex flex-column flex-md-row gap-3 align-items-start mb-3" id="g-fields-row">
          <div class="card shadow-sm flex-grow-1 w-100" id="g-col-my">
            <div class="card-body p-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div style="font-size:12px;font-weight:600;color:#445566" id="g-my-title">Моё поле</div>
                <span class="badge text-bg-success" style="font-size:10px">Кораблей: <span id="g-my-cnt"></span>/${SHIP_LIST.length}</span>
              </div>
              <div class="grid-scroll">
                <div class="col-labels" id="g-my-col-lbl"></div>
                <div id="g-my-grid"></div>
              </div>
            </div>
          </div>

          <div class="card shadow-sm flex-grow-1 w-100" id="g-col-en">
            <div class="card-body p-3">
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div style="font-size:12px;font-weight:600;color:#445566" id="g-en-title">Поле противника</div>
                <span class="badge text-bg-danger" style="font-size:10px">Потоплено: <span id="g-en-cnt"></span>/${SHIP_LIST.length}</span>
              </div>
              <div class="grid-scroll">
                <div class="col-labels" id="g-en-col-lbl"></div>
                <div id="g-en-grid"></div>
              </div>
            </div>
          </div>

          <div class="card shadow-sm flex-shrink-0 w-100" id="g-fleet-card" style="max-width:170px">
            <div class="card-body p-3">
              <div style="font-size:10px;font-weight:600;color:#000;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px">Флот противника</div>
              <div id="g-fleet"></div>
            </div>
          </div>
        </div>

        <div class="card shadow-sm">
          <div class="card-body py-2 px-3 d-flex align-items-center gap-2 flex-wrap">
            <span style="font-size:11px;color:#000000;font-weight:600;white-space:nowrap">Последние ходы:</span>
            <div class="d-flex gap-2 flex-wrap" id="g-log"></div>
          </div>
        </div>

      </div>`;

    buildLabelsInto(document.getElementById('g-my-col-lbl'));
    buildLabelsInto(document.getElementById('g-en-col-lbl'));

    document.getElementById('g-tab-my').addEventListener('click', () => switchGameTab('my'));
    document.getElementById('g-tab-en').addEventListener('click', () => switchGameTab('en'));

    window.addEventListener('resize', applyGameTabResponsive);
  }

  function buildLabelsInto(el) {
    COLS_GAME.forEach(c => { const d = document.createElement('div'); d.className = 'col-lbl'; d.textContent = c; el.appendChild(d); });
  }

  // ── Полная перерисовка под текущего игрока ──
  function refreshGameAll() {
    const me = Game.state.currentPlayer;
    const opp = 1 - me;
    const meP = Game.state.players[me];
    const oppP = Game.state.players[opp];

    document.getElementById('g-my-title').textContent = '⚓ ' + meP.name + ' — моё поле';
    document.getElementById('g-en-title').textContent = '🎯 поле противника';

    document.getElementById('g-chip-0').textContent = meP.name + ' — ваш ход';
    document.getElementById('g-chip-0').className = 'chip chip-active';
    document.getElementById('g-chip-1').textContent = oppP.name;
    document.getElementById('g-chip-1').className = 'chip';

    const shipsAlive = SHIP_LIST.length - countSunkShips(me);
    document.getElementById('g-my-cnt').textContent = shipsAlive;
    document.getElementById('g-en-cnt').textContent = countSunkShips(opp);

    document.getElementById('g-shots').textContent = meP.shotsFired.length;
    document.getElementById('g-hits').textContent = meP.shotsFired.filter(s => s.hit).length;
    document.getElementById('g-sunk').textContent = countSunkShips(opp);

    buildMyFieldGrid(me);
    buildEnFieldGrid(me);
    buildFleetStatus(opp);
    renderGameLog(me);
    applyGameTabResponsive();
  }

  function countSunkShips(playerIndex) {
    const player = Game.state.players[playerIndex];
    // потопленные корабли этого игрока = корабли, по всем клеткам которых есть hit в shotsReceived
    const hitSet = new Set(player.shotsReceived.filter(s => s.hit).map(s => s.x + ',' + s.y));
    return player.ships.filter(sh => sh.coords.every(([cx, cy]) => hitSet.has(cx + ',' + cy))).length;
  }

  // ── Флот противника по типам: сколько кораблей каждого типа ещё не потоплено ──
  // Силуэт — простые квадратные клеточки в ряд (как ship-btn-cell на расстановке).
  // Тип с остатком 0 не выводится — строка исчезает полностью, не гаснет.
  function buildFleetStatus(oppIdx) {
    const el = document.getElementById('g-fleet');
    if (!el) return;
    const oppShips = Game.state.players[oppIdx].ships;
    const shotMap = {};
    Game.state.players[1 - oppIdx].shotsFired.forEach(s => { shotMap[s.x + ',' + s.y] = s; });

    el.innerHTML = '';
    SHIP_TYPES.forEach(type => {
      const remaining = type.ids.filter(id => {
        const ship = oppShips.find(sh => sh.id === id);
        if (!ship) return false; // на случай неполных данных — не считаем
        const allHit = ship.coords.every(([cx, cy]) => shotMap[cx + ',' + cy]?.hit);
        return !allHit;
      }).length;

      if (remaining === 0) return; // тип полностью потоплен — прячем строку

      const row = document.createElement('div');
      row.className = 'fleet-row';
      const cells = document.createElement('div');
      cells.className = 'fleet-cells';
      for (let i = 0; i < type.size; i++) {
        const c = document.createElement('div');
        c.className = 'fleet-cell';
        cells.appendChild(c);
      }
      const label = document.createElement('span');
      label.className = 'fleet-count';
      label.textContent = '×' + remaining;
      row.appendChild(cells);
      row.appendChild(label);
      el.appendChild(row);
    });
  }

  // ── Моё поле: корабли + что по ним попало ──
  function buildMyFieldGrid(me) {
    const g = document.getElementById('g-my-grid');
    g.innerHTML = '';
    const player = Game.state.players[me];
    const shipCells = new Set();
    player.ships.forEach(sh => sh.coords.forEach(([cx, cy]) => shipCells.add(cx + ',' + cy)));
    const hitMap = {};
    player.shotsReceived.forEach(s => { hitMap[s.x + ',' + s.y] = s.hit; });

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const isShip = shipCells.has(k);
        const wasShot = k in hitMap;
        if (isShip && wasShot) { cell.className = 'cell my-hit'; const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d); }
        else if (isShip) { cell.className = 'cell ship'; }
        else if (wasShot) { cell.className = 'cell my-miss'; const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d); }
        else { cell.className = 'cell'; }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  // ── Поле атаки: что я уже выстрелил по противнику ──
  function buildEnFieldGrid(me) {
    const g = document.getElementById('g-en-grid');
    g.innerHTML = '';
    const player = Game.state.players[me];
    const oppIdx = 1 - me;
    const oppShips = Game.state.players[oppIdx].ships;

    const shotMap = {};
    player.shotsFired.forEach(s => { shotMap[s.x + ',' + s.y] = s; });

    // клетки потопленных кораблей противника — раскрыть полностью
    const sunkCells = new Set();
    oppShips.forEach(sh => {
      const allHit = sh.coords.every(([cx, cy]) => shotMap[cx + ',' + cy]?.hit);
      if (allHit) sh.coords.forEach(([cx, cy]) => sunkCells.add(cx + ',' + cy));
    });

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const shot = shotMap[k];
        if (sunkCells.has(k)) {
          cell.className = 'cell en-sunk';
          const d = document.createElement('div'); d.className = 'dot-sunk'; cell.appendChild(d);
        } else if (shot && shot.hit) {
          cell.className = 'cell en-hit';
          const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d);
        } else if (shot) {
          cell.className = 'cell en-miss';
          const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d);
        } else {
          cell.className = 'cell en-water';
          cell.addEventListener('click', () => fireAt(c, r, cell));
        }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  // ── Выстрел с анимацией ──
  function fireAt(c, r, cell) {
    if (gameFiring) return;
    gameFiring = true;
    addAnim(cell, 'anim-shell');

    setTimeout(() => {
      const result = Game.attack(c, r);
      if (!result) { gameFiring = false; return; }

      if (result.hit) {
        cell.className = 'cell en-hit';
        addAnim(cell, 'anim-explode');
        addAnim(cell, 'anim-ripple');
        addLabel(cell, 'Попадание!', 'hit');
        setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-hit dot-bounce'; cell.appendChild(d); }, 150);
      } else {
        cell.className = 'cell en-miss';
        addAnim(cell, 'anim-splash');
        addAnim(cell, 'anim-ripple');
        addLabel(cell, 'Мимо', 'miss');
        cell.classList.add('shake');
        setTimeout(() => { const d = document.createElement('div'); d.className = 'dot-miss dot-bounce'; cell.appendChild(d); }, 150);
      }

      // Даём анимации и подписи полностью доиграть (label фейдит ~900мс,
      // dot-bounce стартует на 150мс) прежде чем перерисовывать поля —
      // иначе игрок не успевает увидеть результат выстрела.
      setTimeout(() => {
        if (result.gameOver) {
          UI.showToast('🏆 ' + Game.state.players[result.winner].name + ' победил!', 3000);
          setTimeout(() => {
            gameFiring = false;
            if (typeof gameOnOver === 'function') gameOnOver(result);
          }, 1200);
          return;
        }

        if (result.hit) {
          UI.showToast('Попадание! Внеочередной ход — стреляйте снова', 1800);
        } else {
          const nextName = Game.state.players[Game.state.currentPlayer].name;
          UI.showToast('Мимо! Ход переходит к игроку «' + nextName + '»', 2000);
        }

        gameFiring = false;
        refreshGameAll();
      }, 1000);
    }, 210);
  }

  function addAnim(cell, cls) { const el = document.createElement('div'); el.className = cls; cell.appendChild(el); setTimeout(() => el.remove(), 700); }
  function addLabel(cell, text, cls) { const el = document.createElement('div'); el.className = 'anim-label ' + cls; el.textContent = text; cell.appendChild(el); setTimeout(() => el.remove(), 900); }

  // ── Журнал последних ходов ──
  function renderGameLog(me) {
    const el = document.getElementById('g-log');
    const player = Game.state.players[me];
    const last = player.shotsFired.slice(-7).reverse();
    el.innerHTML = last.map(s =>
      `<span class="log-item ${s.hit ? 'h' : 'm'}">${COLS_GAME[s.x]}${s.y + 1} — ${s.hit ? 'попадание' : 'мимо'}</span>`
    ).join('');
  }

  // ── Мобильные вкладки ──
  function switchGameTab(t) {
    gameActiveTab = t;
    applyGameTabResponsive();
  }

  function applyGameTabResponsive() {
    const tabMy = document.getElementById('g-tab-my');
    const tabEn = document.getElementById('g-tab-en');
    if (tabMy) tabMy.classList.toggle('active', gameActiveTab === 'my');
    if (tabEn) tabEn.classList.toggle('active', gameActiveTab === 'en');

    const isMobile = window.innerWidth < 768;
    const colMy = document.getElementById('g-col-my');
    const colEn = document.getElementById('g-col-en');
    if (!colMy || !colEn) return;
    if (isMobile) {
      colMy.classList.toggle('d-none', gameActiveTab !== 'my');
      colEn.classList.toggle('d-none', gameActiveTab !== 'en');
    } else {
      colMy.classList.remove('d-none');
      colEn.classList.remove('d-none');
    }

    placeFleetCard(isMobile);
  }

  // ── Флот противника: на десктопе — отдельная колонка справа от полей;
  //    на мобиле — переезжает под сетку поля врага внутри той же карточки. ──
  function placeFleetCard(isMobile) {
    const fleetCard = document.getElementById('g-fleet-card');
    const colEn = document.getElementById('g-col-en');
    const fieldsRow = document.getElementById('g-fields-row');
    if (!fleetCard || !colEn || !fieldsRow) return;

    if (isMobile) {
      if (fleetCard.parentElement !== colEn.querySelector('.card-body')) {
        fleetCard.classList.remove('w-100');
        fleetCard.classList.add('mt-3');
        fleetCard.style.maxWidth = 'none';
        colEn.querySelector('.card-body').appendChild(fleetCard);
      }
    } else {
      if (fleetCard.parentElement !== fieldsRow) {
        fleetCard.classList.remove('mt-3');
        fleetCard.classList.add('w-100');
        fleetCard.style.maxWidth = '170px';
        fieldsRow.appendChild(fleetCard);
      }
    }
  }

  /* ════════════════════════════════════════════════════════
     ЭКРАН РЕЗУЛЬТАТА — Этап 4
     Источник данных: Game.state.winner + players[i].ships /
     shotsFired / shotsReceived. Перенесено из prototypes/game_over.html,
     поля строятся из реального состояния, а не из мок-данных.
     ════════════════════════════════════════════════════════ */

  const COLS_OVER = COLS; // те же подписи столбцов А-К

  /**
   * Запустить экран результата.
   * @param {Function} onPlayAgain - callback() — вызывается по клику "Играть снова"
   * @param {Function} onToLobby   - callback() — вызывается по клику "В лобби"
   */
  function initOver(onPlayAgain, onToLobby) {
    renderOverShell();

    const winnerIdx = Game.state.winner;
    const loserIdx = 1 - winnerIdx;
    const winner = Game.state.players[winnerIdx];

    const banner = document.getElementById('o-banner');
    banner.className = 'result-banner win mb-3';
    document.getElementById('o-icon').textContent = '🏆';
    document.getElementById('o-title').textContent = winner.name + ' победил!';
    document.getElementById('o-sub').textContent = 'Все корабли противника потоплены';

    // Сводная статистика — суммарно по обоим игрокам
    const allShots = Game.state.players[0].shotsFired.length + Game.state.players[1].shotsFired.length;
    const allHits = Game.state.players[0].shotsFired.filter(s => s.hit).length +
                     Game.state.players[1].shotsFired.filter(s => s.hit).length;
    const acc = allShots > 0 ? Math.round(allHits / allShots * 100) : 0;

    document.getElementById('o-shots').textContent = allShots;
    document.getElementById('o-hits').textContent = allHits;
    document.getElementById('o-acc').textContent = acc + '%';
    document.getElementById('o-time').textContent = formatBattleTime();

    document.getElementById('o-p0-title').textContent = '⚓ ' + Game.state.players[0].name + ' — расположение кораблей';
    document.getElementById('o-p1-title').textContent = '⚓ ' + Game.state.players[1].name + ' — расположение кораблей';
    buildOverFieldGrid('o-p0-grid', 0);
    buildOverFieldGrid('o-p1-grid', 1);

    document.getElementById('btn-over-lobby').onclick = () => { if (typeof onToLobby === 'function') onToLobby(); };
    document.getElementById('btn-over-replay').onclick = () => { if (typeof onPlayAgain === 'function') onPlayAgain(); };
  }

  function formatBattleTime() {
    if (!Game.state.battleStartedAt) return '—:—';
    const totalSec = Math.max(0, Math.round((Date.now() - Game.state.battleStartedAt) / 1000));
    const m = Math.floor(totalSec / 60);
    const s = totalSec % 60;
    return String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  }

  function renderOverShell() {
    const root = document.getElementById('screen-over');
    root.innerHTML = `
      <div class="container py-4" style="max-width:760px">

        <div class="result-banner win mb-3" id="o-banner">
          <div class="result-icon" id="o-icon">🏆</div>
          <div class="result-title win" id="o-title"></div>
          <div class="result-sub" id="o-sub"></div>
        </div>

        <div class="row g-2 mb-3">
          <div class="col-3"><div class="stat-card"><div class="v" id="o-shots">0</div><div class="l">Выстрелов</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-hits">0</div><div class="l">Попаданий</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-acc">0%</div><div class="l">Точность</div></div></div>
          <div class="col-3"><div class="stat-card"><div class="v" id="o-time">00:00</div><div class="l">Время боя</div></div></div>
        </div>

        <div class="card shadow-sm mb-3">
          <div class="card-body p-3">
            <div class="row g-3">
              <div class="col-12 col-md-6">
                <div class="field-title" id="o-p0-title"></div>
                <div class="grid-scroll">
                  <div class="col-labels" id="o-p0-col-lbl"></div>
                  <div id="o-p0-grid"></div>
                </div>
              </div>
              <div class="col-12 col-md-6">
                <div class="field-title" id="o-p1-title"></div>
                <div class="grid-scroll">
                  <div class="col-labels" id="o-p1-col-lbl"></div>
                  <div id="o-p1-grid"></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-lobby flex-fill" id="btn-over-lobby">← В лобби</button>
          <button class="btn btn-replay flex-fill" id="btn-over-replay">↻ Играть снова</button>
        </div>

      </div>`;

    buildLabelsInto(document.getElementById('o-p0-col-lbl'));
    buildLabelsInto(document.getElementById('o-p1-col-lbl'));
  }

  // ── Итоговое поле игрока: все его корабли раскрыты, с отметками боя ──
  function buildOverFieldGrid(gridId, playerIndex) {
    const g = document.getElementById(gridId);
    g.innerHTML = '';
    const player = Game.state.players[playerIndex];

    const shipCells = new Set();
    player.ships.forEach(sh => sh.coords.forEach(([cx, cy]) => shipCells.add(cx + ',' + cy)));

    const hitMap = {};
    player.shotsReceived.forEach(s => { hitMap[s.x + ',' + s.y] = s.hit; });

    // клетки потопленных кораблей — выделить отдельным цветом
    const sunkCells = new Set();
    player.ships.forEach(sh => {
      const allHit = sh.coords.every(([cx, cy]) => hitMap[cx + ',' + cy] === true);
      if (allHit) sh.coords.forEach(([cx, cy]) => sunkCells.add(cx + ',' + cy));
    });

    for (let r = 0; r < 10; r++) {
      const row = document.createElement('div'); row.className = 'grid-row';
      const rl = document.createElement('div'); rl.className = 'row-lbl'; rl.textContent = r + 1; row.appendChild(rl);
      for (let c = 0; c < 10; c++) {
        const k = c + ',' + r;
        const cell = document.createElement('div');
        const isShip = shipCells.has(k);
        const wasShot = k in hitMap;

        if (sunkCells.has(k)) {
          cell.className = 'cell en-sunk';
          const d = document.createElement('div'); d.className = 'dot-sunk'; cell.appendChild(d);
        } else if (isShip && wasShot) {
          cell.className = 'cell my-hit';
          const d = document.createElement('div'); d.className = 'dot-hit'; cell.appendChild(d);
        } else if (isShip) {
          cell.className = 'cell ship';
        } else if (wasShot) {
          cell.className = 'cell my-miss';
          const d = document.createElement('div'); d.className = 'dot-miss'; cell.appendChild(d);
        } else {
          cell.className = 'cell';
        }
        row.appendChild(cell);
      }
      g.appendChild(row);
    }
  }

  return { initPlacing, initGame, initOver };

})();