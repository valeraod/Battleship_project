<?php
/**
 * db.php — подключение к БД через PDO.
 * Подключается во всех последующих PHP-скриптах Блока B:
 *   require __DIR__ . '/db.php';
 * После require доступна переменная $pdo (PDO-соединение).
 *
 * ВАЖНО: перед заливкой на сервер вручную замени DB_PASS на реальный
 * пароль пользователя valer186_battleship_user (созданный в cPanel).
 * Этот файл не должен попадать в публичный git-репозиторий с реальным
 * паролем — храните пароль только на сервере.
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'valer186_battleship');
define('DB_USER', 'valer186_battleship_user');
define('DB_PASS', 'lla1VY4AAZ1y');

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    // Не показываем реальный текст ошибки PDO пользователю (может содержать
    // детали о структуре БД) — только в лог сервера, а наружу — общий ответ.
    error_log('DB connection failed: ' . $e->getMessage());
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => 'db_connection_failed']);
    exit;
}

// При прямом обращении к db.php (без require из другого скрипта) —
// показать, что подключение работает, без раскрытия структуры БД.
if (basename($_SERVER['SCRIPT_NAME']) === 'db.php') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'ok', 'message' => 'Подключение к БД установлено']);
}
